//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by WindowsAPI.rc
//
#define IDC_MYICON                      2
#define IDD_WINDOWSAPI_DIALOG           102
#define IDS_APP_TITLE                   103
#define IDD_ABOUTBOX                    103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDI_WINDOWSAPI                  107
#define IDI_SMALL                       108
#define IDC_WINDOWSAPI                  109
#define IDR_MAINFRAME                   128
#define IDD_DIALOG2                     130
#define IDD_DIALOG3                     131
#define IDD_DIALOG4                     132
#define IDD_DIALOG5                     133
#define IDD_DIALOG1                     137
#define IDD_DIALOG6                     141
#define IDD_DIALOG7                     142
#define IDD_DIALOG8                     143
#define IDD_DIALOG9                     144
#define IDC_DATETIMEPICKER1             1001
#define IDC_EDIT1                       1002
#define IDC_LIST1                       1003
#define IDC_BUTTON1                     1004
#define IDC_BUTTON2                     1005
#define IDC_BUTTON3                     1006
#define IDC_COMBO1                      1007
#define IDC_BUTTON4                     1007
#define IDC_BUTTON5                     1008
#define IDC_RADIO1                      1009
#define IDC_BUTTON6                     1009
#define IDC_RADIO2                      1010
#define IDC_BUTTON7                     1010
#define IDC_RADIO3                      1011
#define IDC_BUTTON8                     1011
#define IDC_RADIO4                      1012
#define IDC_BUTTON9                     1012
#define IDC_RADIO5                      1013
#define IDC_BUTTON10                    1013
#define IDC_CHECK1                      1014
#define IDC_BUTTON11                    1014
#define IDC_CHECK2                      1015
#define IDC_BUTTON12                    1015
#define IDC_CHECK3                      1016
#define IDC_CHECK4                      1017
#define IDC_CHECK5                      1018
#define IDC_STATIC1                     1019
#define IDC_IMAGEN                      1020
#define IDC_IMAGEN2                     1021
#define IDC_EDIT2                       1022
#define IDC_EDIT3                       1023
#define IDC_BUTTON13                    1024
#define IDC_BUTTON14                    1025
#define IDC_BUTTON15                    1026
#define IDC_BUTTON16                    1027
#define IDC_BUTTON17                    1028
#define IDC_NOMBRE                      1029
#define IDC_EDAD                        1030
#define IDC_PESO                        1031
#define IDC_BTNAGREGAR                  1032
#define IDC_MFCMENUBUTTON1              1034
#define IDC_DATETIMEPICKER2             1038
#define ID_OPCIONNUEVA                  32771
#define ID_ASDASD_ASDASASD              32772
#define ID_ASDASD_ASDAS                 32773
#define ID_ASDASD_ASDAS32774            32774
#define ID_ASDAS_ASDASAASD              32775
#define ID_ASDAS_ASDAS                  32776
#define ID_OPCION2_HOLA                 32777
#define ID_OPCION2_COMOESTAS            32778
#define ID_PRUEBA1_TIPO1                32779
#define ID_PRUEBA1_ABRIRDIALOGO6        32780
#define ID_PRUEBA1_DIALOGO6             32781
#define ID_PRUEBA1_TEST1                32782
#define ID_PRUEBA2_TEST2                32783
#define ID_PRUEBA1_ABRIRDIALOG7         32784
#define ID_PRUEBA1_TEST2                32785
#define ID_PRUEBA2_TEST3                32786
#define ID_PRUEBA3                      32787
#define ID_PRUEBA1_ABRIRDIALOG8         32788
#define ID_PRUEBA1_ABRIRDIALOGO7        32789
#define ID_PRUEBA1_ABRIRDIALOG9         32790
#define ID_PRUEBA1_CALCULADORA          32791
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        145
#define _APS_NEXT_COMMAND_VALUE         32792
#define _APS_NEXT_CONTROL_VALUE         1039
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif

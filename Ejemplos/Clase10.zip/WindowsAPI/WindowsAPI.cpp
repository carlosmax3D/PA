#include "framework.h"
#include "WindowsAPI.h"
#include <string>
#include <oleauto.h>
#include <commdlg.h>
#include <commctrl.h>
#include <iostream>
#include <sstream>
#include <fstream>

#define MAX_LOADSTRING 100
#if defined _WIN32 || defined __CYGWIN__
#define PATH_SEPARATOR '\\'
#else
#define PATH_SEPARATOR "/"
#endif

using namespace std;

struct ALUMNOS {
    char nombre[255];
    //	string nombre;
    int edad;
    float peso;
    ALUMNOS* anterior;
    ALUMNOS* siguiente;
}*ORIGEN, *AUX;

// Global Variables:
HINSTANCE hInst;                                // ID de programa (instancia)
WCHAR szTitle[MAX_LOADSTRING];                  // Titulo del programa
WCHAR szWindowClass[MAX_LOADSTRING];            // Nombre de la clase de la ventana principal
HWND hWndEdit;
HWND modal;
HWND ventanaPrincipal;
WCHAR fileName[1000] = { 0 };
#define IDT_TIMER1 2021

// Forward declarations of functions included in this code module:
ALUMNOS* crearAlumno(string nombre, int edad, float peso);
void agregarAlumnoAlInicio(ALUMNOS* alumno);
void agregarAlumnoAlFinal(ALUMNOS* alumno);
void agregarAlumnoEnMedio(ALUMNOS* alumno, string nombreBuscar);
ALUMNOS* buscarAlumno(string nombreBuscar);
void borrarListaAlumnos();
void modificarAlumno(string nombreABuscar, int edad, float peso);
void borrarAlumnoAlInicio();
void borrarAlumnoAlFinal();
void borrarAlumnoEnMedio(string nombreABorrar);
void guardarArchivoAlumnos();
void leerArchivoAlumnos();
void modificarAlumno(ALUMNOS* indice, int edad, float peso);

ATOM                MyRegisterClass(HINSTANCE hInstance);
BOOL                InitInstance(HINSTANCE, int);
LRESULT CALLBACK    WndProc(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK    About(HWND, UINT, WPARAM, LPARAM);
std::wstring s2ws(const std::string& s);
LONG_PTR CALLBACK Dialog6_callback(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
LONG_PTR CALLBACK Dialog7_callback(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
LONG_PTR CALLBACK Dialog8_callback(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
LONG_PTR CALLBACK Dialog9_callback(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
LONG_PTR CALLBACK Dialog9_callback(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
bool MenuOpciones(HWND ventanaId, long opcion);
LONG_PTR CALLBACK Dialog12_callback(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
LONG_PTR CALLBACK Dialog11_callback(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);

//LONG_PTR = long *

int APIENTRY wWinMain(_In_ HINSTANCE hInstance, _In_opt_ HINSTANCE hPrevInstance,
    _In_ LPWSTR lpCmdLine, _In_ int nCmdShow) { //LPWSTR = WCHAR * = WSTRING
    UNREFERENCED_PARAMETER(hPrevInstance);
    UNREFERENCED_PARAMETER(lpCmdLine);

    ORIGEN = NULL;
    AUX = NULL;

    // Carga los titulos con los string en resource
    LoadStringW(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
    LoadStringW(hInstance, IDC_WINDOWSAPI, szWindowClass, MAX_LOADSTRING);
    // Se asignan propiedades a la pantalla principal
    MyRegisterClass(hInstance);

    // Se despliega la ventana principal
    if (!InitInstance(hInstance, nCmdShow)) {
        return FALSE;
    }

    // Se toma la lista de accesos directos creada en resource.h
    HACCEL hAccelTable = LoadAccelerators(hInstance, MAKEINTRESOURCE(IDC_WINDOWSAPI));
    // Variable para capturar mensajes
    MSG msg;
    leerArchivoAlumnos();

    // Bucle principal para leer mensajes de pantalla
    while (GetMessage(&msg, nullptr, 0, 0)) {
        // Verifica si el mensaje es un acceso directo, si lo es lo traduce y ejecuta
        if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg)) {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
    }
    guardarArchivoAlumnos();
    borrarListaAlumnos();

    return (int)msg.wParam;
}

//
//  FUNCTION: MyRegisterClass()
//
//  PURPOSE: Registers the window class.
//
ATOM MyRegisterClass(HINSTANCE hInstance) {
    WNDCLASSEXW wcex;
    wcex.cbSize = sizeof(WNDCLASSEX);

    wcex.style = CS_HREDRAW | CS_VREDRAW;
    wcex.lpfnWndProc = WndProc;  // Funcion de callback para la ventana
    wcex.cbClsExtra = 0;
    wcex.cbWndExtra = 0;
    wcex.hInstance = hInstance;
    wcex.hIcon = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_WINDOWSAPI));
    wcex.hCursor = LoadCursor(nullptr, IDC_ARROW);
    wcex.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
    wcex.lpszMenuName = MAKEINTRESOURCEW(IDC_WINDOWSAPI);
    wcex.lpszClassName = szWindowClass;
    wcex.hIconSm = LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_SMALL));

    return RegisterClassExW(&wcex);
}

//
//   FUNCTION: InitInstance(HINSTANCE, int)
//
//   PURPOSE: Saves instance handle and creates main window
//
//   COMMENTS:
//
//        In this function, we save the instance handle in a global variable and
//        create and display the main program window.
//
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow) {
    hInst = hInstance; // Store instance handle in our global variable

    ventanaPrincipal = CreateWindowW(
        szWindowClass,
        szTitle,
        WS_OVERLAPPEDWINDOW,
        CW_USEDEFAULT, // Position X
        0,             // Position Y
        CW_USEDEFAULT,
        0,
        nullptr,
        nullptr,
        hInstance,
        nullptr);

    if (!ventanaPrincipal) {
        return FALSE;
    }
    /*
        HWND hwndButton = CreateWindowW(
            L"BUTTON",  // Predefined class; Unicode assumed
            L"OK JEJE",      // Button text
            WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON,  // Styles
            10,         // x position
            10,         // y position
            100,        // Button width
            100,        // Button height
            ventanaPrincipal,       // Parent window
            (HMENU)1002,       // No menu. NULL
            (HINSTANCE)GetWindowLongPtr(ventanaPrincipal, GWLP_HINSTANCE),
            NULL);      // Pointer not needed.

        HWND hwndButton2 = CreateWindowW(
            L"BUTTON",  // Predefined class; Unicode assumed
            L"Nuevo Dialog",      // Button text
            WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON,  // Styles
            150,         // x position
            150,         // y position
            100,        // Button width
            100,        // Button height
            ventanaPrincipal,       // Parent window
            (HMENU)1004,       // No menu. NULL
            (HINSTANCE)GetWindowLongPtr(ventanaPrincipal, GWLP_HINSTANCE),
            NULL);      // Pointer not needed.

        HWND hwndButton3 = CreateWindowW(
            L"BUTTON",  // Predefined class; Unicode assumed
            L"Calculadora",      // Button text
            WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON,  // Styles
            300,         // x position
            300,         // y position
            100,        // Button width
            50,        // Button height
            ventanaPrincipal,       // Parent window
            (HMENU)1005,       // No menu. NULL
            (HINSTANCE)GetWindowLongPtr(ventanaPrincipal, GWLP_HINSTANCE),
            NULL);      // Pointer not needed.
        HWND hwndButton4 = CreateWindowW(
            L"BUTTON",  // Predefined class; Unicode assumed
            L"UnionAvances",      // Button text
            WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON,  // Styles
            500,         // x position
            300,         // y position
            100,        // Button width
            50,        // Button height
            ventanaPrincipal,       // Parent window
            (HMENU)1006,       // No menu. NULL
            (HINSTANCE)GetWindowLongPtr(ventanaPrincipal, GWLP_HINSTANCE),
            NULL);      // Pointer not needed.
        HWND hwndButton5 = CreateWindowW(
            L"BUTTON",  // Predefined class; Unicode assumed
            L"Mostrar Nodos",      // Button text
            WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON,  // Styles
            500,         // x position
            150,         // y position
            100,        // Button width
            50,        // Button height
            ventanaPrincipal,       // Parent window
            (HMENU)1007,       // No menu. NULL
            (HINSTANCE)GetWindowLongPtr(ventanaPrincipal, GWLP_HINSTANCE),
            NULL);      // Pointer not needed.

        // Creamos un textbox para capturar texto
        hWndEdit = CreateWindowEx(
            WS_EX_CLIENTEDGE,
            TEXT("Edit"),
            TEXT("test asdas as"),
            WS_CHILD | WS_VISIBLE,
            200, 20,
            255,
            20, ventanaPrincipal, (HMENU)1003, NULL, NULL);*/
    ShowWindow(ventanaPrincipal, SW_HIDE);
    UpdateWindow(ventanaPrincipal);

    HWND modal = CreateDialog(hInst, MAKEINTRESOURCE(IDD_DIALOG6), NULL, Dialog6_callback);
    ShowWindow(modal, SW_SHOW);
    // HMENU hMenuOpciones = LoadMenu(hInst, MAKEINTRESOURCE(IDC_WINDOWSAPI));
    // SetMenu(modal, hMenuOpciones);
    UpdateWindow(modal);

    return TRUE;
}

bool MenuOpciones(HWND ventanaId, long opcion) {
    switch (opcion) {
        case ID_PRUEBA1_VERALUMNOS: {
            HWND noModal = CreateDialog(hInst, MAKEINTRESOURCE(IDD_DIALOG12), NULL, Dialog12_callback);
            ShowWindow(noModal, SW_SHOW);
            UpdateWindow(noModal);
            EndDialog(ventanaId, opcion);
        } break;
        case ID_PRUEBA1_ALTAALUMNO: {
            HWND noModal = CreateDialog(hInst, MAKEINTRESOURCE(IDD_DIALOG11), NULL, Dialog11_callback);
            ShowWindow(noModal, SW_SHOW);
            UpdateWindow(noModal);
            EndDialog(ventanaId, opcion);
        } break;
    case ID_PRUEBA1_ABRIRDIALOG9: {
        HWND noModal = CreateDialog(hInst, MAKEINTRESOURCE(IDD_DIALOG9), NULL, Dialog9_callback);
        ShowWindow(noModal, SW_SHOW);
        UpdateWindow(noModal);
        EndDialog(ventanaId, opcion);
    } break;
    case ID_PRUEBA1_ABRIRDIALOG8: {
        HWND noModal = CreateDialog(hInst, MAKEINTRESOURCE(IDD_DIALOG8), NULL, Dialog8_callback);
        ShowWindow(noModal, SW_SHOW);
        UpdateWindow(noModal);
        EndDialog(ventanaId, opcion);
    } break;
    case ID_PRUEBA1_ABRIRDIALOGO7: {
        HWND noModal = CreateDialog(hInst, MAKEINTRESOURCE(IDD_DIALOG7), NULL, Dialog7_callback);
        ShowWindow(noModal, SW_SHOW);
        UpdateWindow(noModal);
        EndDialog(ventanaId, opcion);
    }break;
    case ID_PRUEBA2_TEST3: {
        MessageBox(ventanaId, L"Trigger Test3", TEXT("Trigger Prueba2"), 1);
    }break;
    case ID_PRUEBA1_TEST2: {
        MessageBox(ventanaId, L"Trigger Test2", TEXT("Trigger Prueba1"), 1);
    } break;
    case IDM_ABOUT: {
        DialogBox(hInst, MAKEINTRESOURCE(IDD_ABOUTBOX), ventanaId, About);
    } break;
    case IDM_EXIT:
    case WM_DESTROY:
        DestroyWindow(ventanaId);
        break;
    default: return false;
    }
    return true;
}

LONG_PTR CALLBACK Dialog12_callback(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam) {
    switch (message) {
        case WM_INITDIALOG: {
            SendMessage(GetDlgItem(hWnd, IDC_LIST1), LB_RESETCONTENT, 0, 0);
            ALUMNOS* indice = ORIGEN;
            while (indice != NULL) {
                wstring wnombre = s2ws(indice->nombre).append(L" - ").append(s2ws(to_string(indice->edad)));
                int posicion = SendMessage(GetDlgItem(hWnd, IDC_LIST1), LB_INSERTSTRING, 0, (LPARAM)wnombre.c_str());
                SendMessage(GetDlgItem(hWnd, IDC_LIST1), LB_SETITEMDATA, posicion, (LPARAM)indice);
                indice = indice->siguiente;
            }
            return (LONG_PTR)TRUE;
        } break;
        case WM_COMMAND: {
            long wmId = LOWORD(wParam);
            if (MenuOpciones(hWnd, wmId)) {
                return (LONG_PTR)FALSE;
            }
            switch (wmId) {
                case IDOK: {
                    TCHAR buffer[255];
                    GetDlgItemText(hWnd, IDC_EDIT1, buffer, 255);
                    wstring wnombre(buffer);
                    GetDlgItemText(hWnd, IDC_EDIT2, buffer, 255);
                    int edad = _wtoi(buffer);
                    GetDlgItemText(hWnd, IDC_EDIT3, buffer, 255);
                    float peso = _wtof(buffer);
                    string nombre(wnombre.begin(), wnombre.end());
                    int seleccion = SendMessage(GetDlgItem(hWnd, IDC_LIST1), LB_GETCURSEL, 0, 0);
                    if (seleccion >= 0) {
                        ALUMNOS* seleccionado = (ALUMNOS*)SendMessage(GetDlgItem(hWnd, IDC_LIST1), LB_GETITEMDATA, seleccion, 0);
                        modificarAlumno(seleccionado, edad, peso);
                        MessageBox(hWnd, L"Modificado", L"Modificado", 0);
                        /*SendMessage(GetDlgItem(hWnd, IDC_LIST1), LB_RESETCONTENT, 0, 0);
                        ALUMNOS* indice = ORIGEN;
                        while (indice != NULL) {
                            wstring wnombre = s2ws(indice->nombre).append(L" - ").append(s2ws(to_string(indice->edad)));
                            int posicion = SendMessage(GetDlgItem(hWnd, IDC_LIST1), LB_INSERTSTRING, 0, (LPARAM)wnombre.c_str());
                            SendMessage(GetDlgItem(hWnd, IDC_LIST1), LB_SETITEMDATA, posicion, (LPARAM)indice);
                            indice = indice->siguiente;
                        }*/
                        SendMessage(GetDlgItem(hWnd, IDC_LIST1), LB_DELETESTRING, seleccion, 0);
                        wstring wnombre = s2ws(seleccionado->nombre).append(L" - ").append(s2ws(to_string(seleccionado->edad)));
                        int posicion = SendMessage(GetDlgItem(hWnd, IDC_LIST1), LB_INSERTSTRING, 0, (LPARAM)wnombre.c_str());
                        SendMessage(GetDlgItem(hWnd, IDC_LIST1), LB_SETITEMDATA, posicion, (LPARAM)seleccionado);
                        SendMessage(GetDlgItem(hWnd, IDC_LIST1), LB_SETCURSEL, posicion, 0);
                    }
                } break;
                case IDC_LIST1: {
                    int notificacion = HIWORD(wParam);
                    switch (notificacion) {
                        case LBN_SELCHANGE: {
                            int seleccion = SendMessage(GetDlgItem(hWnd, IDC_LIST1), LB_GETCURSEL, 0, 0);
                            if (seleccion >= 0) {
                                ALUMNOS *seleccionado = (ALUMNOS *)SendMessage(GetDlgItem(hWnd, IDC_LIST1), LB_GETITEMDATA, seleccion, 0);
                                SetDlgItemText(hWnd, IDC_EDIT1, s2ws(seleccionado->nombre).c_str());
                                SetDlgItemText(hWnd, IDC_EDIT2, s2ws(to_string(seleccionado->edad)).c_str());
                                SetDlgItemText(hWnd, IDC_EDIT3, s2ws(to_string(seleccionado->peso)).c_str());
                                AUX = seleccionado;
                            }
                        } break;
                        default: return DefWindowProc(hWnd, message, wParam, lParam);
                    }
                } break;
                default: return DefWindowProc(hWnd, message, wParam, lParam);
            }
        }break;
        case WM_PAINT: {
            PAINTSTRUCT ps;
            HDC hdc = BeginPaint(hWnd, &ps);
            FillRect(hdc, &ps.rcPaint, (HBRUSH)(COLOR_WINDOW));
            EndPaint(hWnd, &ps);
        }break;
        case WM_DESTROY: {
            PostQuitMessage(0);
        }break;
        default: return (LONG_PTR)FALSE;
    }
    return (LONG_PTR)FALSE;
}

LONG_PTR CALLBACK Dialog11_callback(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam) {
    switch (message) {
        case WM_INITDIALOG: {
            return (LONG_PTR)TRUE;
        } break;
        case WM_COMMAND: {
            long wmId = LOWORD(wParam);
            if (MenuOpciones(hWnd, wmId)) {
                return (LONG_PTR)FALSE;
            }
            switch (wmId) {
                case IDOK: { 
                    TCHAR buffer[255];
                    GetDlgItemText(hWnd, IDC_EDIT1, buffer, 255);
                    wstring wnombre(buffer);
                    GetDlgItemText(hWnd, IDC_EDIT2, buffer, 255);
                    int edad = _wtoi(buffer);
                    GetDlgItemText(hWnd, IDC_EDIT3, buffer, 255);
                    float peso = _wtof(buffer);
                    string nombre(wnombre.begin(), wnombre.end());
                    ALUMNOS* nuevo = crearAlumno(nombre, edad, peso);
                    agregarAlumnoAlFinal(nuevo);
                    MessageBox(hWnd, L"Alumno Agregado", L"Registro", 0);
                } break;
                default: return DefWindowProc(hWnd, message, wParam, lParam);
            }
        }break;
        case WM_PAINT: {
            PAINTSTRUCT ps;
            HDC hdc = BeginPaint(hWnd, &ps);
            FillRect(hdc, &ps.rcPaint, (HBRUSH)(COLOR_WINDOW));
            EndPaint(hWnd, &ps);
        }break;
        case WM_DESTROY: {
            PostQuitMessage(0);
        }break;
        default: return (LONG_PTR)FALSE;
    }
    return (LONG_PTR)FALSE;
}

LONG_PTR CALLBACK Dialog9_callback(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam) {
    SYSTEMTIME hora;
    WCHAR texto[255];
    switch (message) {
    case WM_INITDIALOG: {
        CheckDlgButton(hWnd, IDC_RADIO1, BST_CHECKED);
        CheckDlgButton(hWnd, IDC_RADIO7, BST_CHECKED);
        CheckDlgButton(hWnd, IDC_CHECK1, BST_CHECKED);
        CheckDlgButton(hWnd, IDC_CHECK6, BST_CHECKED);
        CheckDlgButton(hWnd, IDC_CHECK8, BST_CHECKED);
        GetLocalTime(&hora);
        GetTimeFormat(LOCALE_USER_DEFAULT, TIME_FORCE24HOURFORMAT, &hora, NULL, texto, 255);
        SetDlgItemText(hWnd, IDC_HORA, texto);
        SetTimer(hWnd, IDT_TIMER1, 1000, (TIMERPROC)Dialog9_callback);

        HBITMAP imagen;
        imagen = (HBITMAP)LoadImage(hInst, L"C:\\Users\\User\\source\\repos\\WindowsAPI\\Images\\pez.bmp", IMAGE_BITMAP, 100, 100, LR_LOADFROMFILE | LR_DEFAULTCOLOR | LR_DEFAULTSIZE);
        if (imagen == NULL) {
            MessageBox(hWnd, L"No se pudo abrir la imagen", L"Image error", 0);
        }
        else {
            SendDlgItemMessage(hWnd, IDC_IMAGEN1, STM_SETIMAGE, IMAGE_BITMAP, (LPARAM)imagen);
        }
        return (LONG_PTR)TRUE;
    } break;
    case WM_COMMAND: {
        long wmId = LOWORD(wParam);
        if (MenuOpciones(hWnd, wmId)) {
            return (LONG_PTR)FALSE;
        }
        switch (wmId) {
        case IDC_RADIO1: {
            SetDlgItemText(hWnd, IDC_RADIO6, L"LM");
        } break;
        case IDC_RADIO2: {
            SetDlgItemText(hWnd, IDC_RADIO6, L"MeCA");
        } break;
        case IDC_RADIO7: {
            CheckDlgButton(hWnd, IDC_CHECK1, BST_CHECKED);
            CheckDlgButton(hWnd, IDC_CHECK6, BST_CHECKED);
            CheckDlgButton(hWnd, IDC_CHECK8, BST_CHECKED);
            CheckDlgButton(hWnd, IDC_CHECK7, BST_UNCHECKED);
            CheckDlgButton(hWnd, IDC_CHECK9, BST_UNCHECKED);
        } break;
        case IDC_RADIO6: {
            CheckDlgButton(hWnd, IDC_CHECK6, BST_UNCHECKED);
            CheckDlgButton(hWnd, IDC_CHECK8, BST_UNCHECKED);
            CheckDlgButton(hWnd, IDC_CHECK1, BST_CHECKED);
            CheckDlgButton(hWnd, IDC_CHECK7, BST_CHECKED);
            CheckDlgButton(hWnd, IDC_CHECK9, BST_CHECKED);
        } break;
        case IDOK: {
            if (IsDlgButtonChecked(hWnd, IDC_RADIO1) == BST_CHECKED) {
                MessageBox(hWnd, L"Eres de FCFM", L"Facultad", 0);
            }
            if (IsDlgButtonChecked(hWnd, IDC_RADIO2) == BST_CHECKED) {
                MessageBox(hWnd, L"Eres de FIME", L"Facultad", 0);
            }
            if (IsDlgButtonChecked(hWnd, IDC_CHECK1) == BST_CHECKED) {
                MessageBox(hWnd, L"Te gusta la ciencia, pequenio Senku-kun", L"Intereses", 0);
            }

            OPENFILENAME ofn;
            ZeroMemory(&ofn, sizeof(ofn));
            ofn.lStructSize = sizeof(OPENFILENAME);
            ofn.hwndOwner = hWnd;
            ofn.lpstrFile = fileName;
            ofn.nMaxFile = 1000;
            ofn.lpstrFilter = L"Hola Bitmap\0*.bmp\0";
            ofn.nFilterIndex = 1;
            ofn.lpstrTitle = NULL;
            ofn.nMaxFileTitle = 0;
            ofn.lpstrInitialDir = NULL;
            ofn.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST;
            if (GetOpenFileName(&ofn) == TRUE) {
                HBITMAP imagen;
                imagen = (HBITMAP)LoadImage(hInst, fileName, IMAGE_BITMAP, 100, 100, LR_LOADFROMFILE | LR_DEFAULTCOLOR | LR_DEFAULTSIZE);
                if (imagen == NULL) {
                    MessageBox(hWnd, L"No se pudo abrir la imagen", L"Image error", 0);
                }
                else {
                    SendDlgItemMessage(hWnd, IDC_IMAGEN1, STM_SETIMAGE, IMAGE_BITMAP, (LPARAM)imagen);
                    SetDlgItemText(hWnd, IDC_EDIT1, fileName);
                }
            }
            MessageBox(hWnd, fileName, L"Archivo?", 0);

        } break;
        default: return DefWindowProc(hWnd, message, wParam, lParam);
        }
    }break;
    case WM_TIMER: {
        int timerId = LOWORD(wParam);
        switch (timerId) {
        case IDT_TIMER1: {
            //MessageBox(hWnd, L"It's me", L"Timer", 0);
            GetLocalTime(&hora);
            GetTimeFormat(LOCALE_USER_DEFAULT, TIME_FORCE24HOURFORMAT, &hora, NULL, texto, 255);
            SetDlgItemText(hWnd, IDC_HORA, texto);
        } break;
        default: return DefWindowProc(hWnd, message, wParam, lParam);
        }
    } break;
    case WM_PAINT: {
        PAINTSTRUCT ps;
        HDC hdc = BeginPaint(hWnd, &ps);
        FillRect(hdc, &ps.rcPaint, (HBRUSH)(COLOR_WINDOW));
        EndPaint(hWnd, &ps);
    }break;
    case WM_DESTROY: {
        KillTimer(hWnd, IDT_TIMER1);
        PostQuitMessage(0);
    }break;
    default: return (LONG_PTR)FALSE;
    }
    return (LONG_PTR)FALSE;
}

LONG_PTR CALLBACK Dialog8_callback(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam) {
    WCHAR buffer[255];
    switch (message) {
    case WM_INITDIALOG: {
        SendMessage(GetDlgItem(hWnd, IDC_COMBO1), CB_ADDSTRING, 0, (LPARAM)L"MEXICO");
        SendMessage(GetDlgItem(hWnd, IDC_COMBO1), CB_ADDSTRING, 0, (LPARAM)L"USA");
        SendMessage(GetDlgItem(hWnd, IDC_COMBO1), CB_ADDSTRING, 0, (LPARAM)L"RUSIA");
        SendMessage(GetDlgItem(hWnd, IDC_COMBO1), CB_ADDSTRING, 0, (LPARAM)L"JAPON");
        SendMessage(GetDlgItem(hWnd, IDC_COMBO1), CB_ADDSTRING, 0, (LPARAM)L"CHINA");
        return (LONG_PTR)TRUE;
    } break;
    case WM_COMMAND: {
        long wmId = LOWORD(wParam);
        if (MenuOpciones(hWnd, wmId)) {
            return (LONG_PTR)FALSE;
        }
        switch (wmId) {
        case IDC_BUTTON5: {
            SendMessage(GetDlgItem(hWnd, IDC_COMBO1), CB_RESETCONTENT, 0, 0);
        } break;
        case IDC_BUTTON3: {
            int seleccion = SendMessage(GetDlgItem(hWnd, IDC_COMBO1), CB_GETCURSEL, 0, 0);
            if (seleccion >= 0) {
                SendMessage(GetDlgItem(hWnd, IDC_COMBO1), CB_DELETESTRING, seleccion, 0);
            }
        } break;
        case IDC_BUTTON2: {
            SendMessage(GetDlgItem(hWnd, IDC_LIST1), LB_RESETCONTENT, 0, 0);
        } break;
        case IDC_BUTTON1: {
            int seleccion = SendMessage(GetDlgItem(hWnd, IDC_LIST1), LB_GETCURSEL, 0, 0);
            if (seleccion >= 0) {
                SendMessage(GetDlgItem(hWnd, IDC_LIST1), LB_DELETESTRING, seleccion, 0);
            }
        } break;
        case IDOK: {
            int seleccion = SendMessage(GetDlgItem(hWnd, IDC_LIST1), LB_GETCURSEL, 0, 0);
            if (seleccion >= 0) {
                SendMessage(GetDlgItem(hWnd, IDC_LIST1), LB_GETTEXT, seleccion, (LPARAM)buffer);
                MessageBox(hWnd, buffer, L"List Box Boton OK", 0);
            }
            seleccion = SendMessage(GetDlgItem(hWnd, IDC_COMBO1), CB_GETCURSEL, 0, 0);
            if (seleccion >= 0) {
                SendMessage(GetDlgItem(hWnd, IDC_COMBO1), CB_GETLBTEXT, seleccion, (LPARAM)buffer);
                MessageBox(hWnd, buffer, L"Combo Box Boton OK", 0);
            }
            GetDlgItemText(hWnd, IDC_EDIT1, buffer, 255);
            wstring prueba(buffer);
            prueba.append(L" Lo Logre");
            SetDlgItemText(hWnd, IDC_EDIT1, prueba.c_str());
            SendMessage(GetDlgItem(hWnd, IDC_LIST1), LB_ADDSTRING, 0, (LPARAM)prueba.c_str());
        } break;
        case IDC_COMBO1: {
            long notificacion = HIWORD(wParam);
            switch (notificacion) {
            case CBN_SELENDOK: {
                int seleccion = SendMessage(GetDlgItem(hWnd, IDC_COMBO1), CB_GETCURSEL, 0, 0);
                if (seleccion >= 0) {
                    SendMessage(GetDlgItem(hWnd, IDC_COMBO1), CB_GETLBTEXT, seleccion, (LPARAM)buffer);
                    MessageBox(hWnd, buffer, L"Combo Box Notificacion", 0);
                }
            } break;
            default: return DefWindowProc(hWnd, message, wParam, lParam);
            }
        }
        case IDC_LIST1: {
            long notificacion = HIWORD(wParam);
            switch (notificacion) {
            case LBN_SELCHANGE: {
                int seleccion = SendMessage(GetDlgItem(hWnd, IDC_LIST1), LB_GETCURSEL, 0, 0);
                if (seleccion >= 0) {
                    SendMessage(GetDlgItem(hWnd, IDC_LIST1), LB_GETTEXT, seleccion, (LPARAM)buffer);
                    MessageBox(hWnd, buffer, L"List Box Notificacion", 0);
                }
            } break;
            default: return DefWindowProc(hWnd, message, wParam, lParam);
            }
        }
        case IDC_EDIT1: {
            long notificacion = HIWORD(wParam);
            switch (notificacion) {
            case EN_CHANGE: {
                GetDlgItemText(hWnd, IDC_EDIT1, buffer, 255);
                wstring prueba(buffer);
                prueba.append(L" notificacion");
                // MessageBox(hWnd, prueba.c_str(), L"Edit Control Text Notificacion", 0);
            } break;
            default: return DefWindowProc(hWnd, message, wParam, lParam);
            }
        } break;
        default: return DefWindowProc(hWnd, message, wParam, lParam);
        }
    }break;
    case WM_PAINT: {
        PAINTSTRUCT ps;
        HDC hdc = BeginPaint(hWnd, &ps);
        FillRect(hdc, &ps.rcPaint, (HBRUSH)(COLOR_WINDOW));
        EndPaint(hWnd, &ps);
    }break;
    case WM_DESTROY: {
        PostQuitMessage(0);
    }break;
    default: return (LONG_PTR)FALSE;
    }
    return (LONG_PTR)FALSE;
}

LONG_PTR CALLBACK Dialog7_callback(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam) {
    SYSTEMTIME date;
    TCHAR buffer[200];
    switch (message) {
    case WM_INITDIALOG: {
        date.wYear = 2021;
        date.wMonth = 06;
        date.wDay = 20;
        date.wHour = 0;
        date.wMinute = 0;
        date.wSecond = 0;
        date.wMilliseconds = 0;
        DateTime_SetSystemtime(GetDlgItem(hWnd, IDC_DATETIMEPICKER1), GDT_VALID, &date);
        date.wDay = 30;
        DateTime_SetSystemtime(GetDlgItem(hWnd, IDC_DATETIMEPICKER2), GDT_VALID, &date);
        return (LONG_PTR)TRUE;
    } break;
    case WM_COMMAND: {
        long wmId = LOWORD(wParam);
        if (MenuOpciones(hWnd, wmId)) {
            return (LONG_PTR)FALSE;
        }
        switch (wmId) {
        case IDOK: {
            double fecha1, fecha2;
            DateTime_GetSystemtime(GetDlgItem(hWnd, IDC_DATETIMEPICKER1), &date);
            //                GetDateFormat(LOCALE_USER_DEFAULT, DATE_LONGDATE, &date, NULL, buffer, 200);
            //                MessageBox(hWnd, buffer, L"Espera 1", 0);
            if (!SystemTimeToVariantTime(&date, &fecha1)) {
                fecha1 = 0;
            }
            DateTime_GetSystemtime(GetDlgItem(hWnd, IDC_DATETIMEPICKER2), &date);
            if (!SystemTimeToVariantTime(&date, &fecha2)) {
                fecha2 = 0;
            }
            if ((int)fecha1 > (int)fecha2) {
                MessageBox(hWnd, L"Fecha 1 es mayor a Fecha 2", L"Espera 1", 0);
            }
            else if ((int)fecha1 < (int)fecha2) {
                MessageBox(hWnd, L"Fecha 1 es menor a Fecha 2", L"Espera 1", 0);
            }
            else MessageBox(hWnd, L"Fecha 1 es igual a Fecha 2", L"Espera 1", 0);
            fecha1 = fecha1 + 20;
            if (!VariantTimeToSystemTime(fecha1, &date)) {
            }
            GetDateFormat(LOCALE_USER_DEFAULT, DATE_SHORTDATE, &date, NULL, buffer, 200);
            MessageBox(hWnd, buffer, L"Espera 1", 0);
            DateTime_SetSystemtime(GetDlgItem(hWnd, IDC_DATETIMEPICKER2), GDT_VALID, &date);

        } break;
        default: return DefWindowProc(hWnd, message, wParam, lParam);
        }
    }break;
    case WM_PAINT: {
        PAINTSTRUCT ps;
        HDC hdc = BeginPaint(hWnd, &ps);
        FillRect(hdc, &ps.rcPaint, (HBRUSH)(COLOR_WINDOW));
        EndPaint(hWnd, &ps);
    }break;
    case WM_DESTROY: {
        PostQuitMessage(0);
    }break;
    default: return (LONG_PTR)FALSE;
    }
    return (LONG_PTR)FALSE;
}

LONG_PTR CALLBACK Dialog6_callback(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam) {
    switch (message) {
    case WM_INITDIALOG: {
        return (LONG_PTR)TRUE;
    } break;
    case WM_COMMAND: {
        long wmId = LOWORD(wParam);
        if (MenuOpciones(hWnd, wmId)) {
            return (LONG_PTR)FALSE;
        }
        switch (wmId) {
        default: return DefWindowProc(hWnd, message, wParam, lParam);
        }
    }break;
    case WM_PAINT: {
        PAINTSTRUCT ps;
        HDC hdc = BeginPaint(hWnd, &ps);
        FillRect(hdc, &ps.rcPaint, (HBRUSH)(COLOR_WINDOW));
        EndPaint(hWnd, &ps);
    }break;
    case WM_DESTROY: {
        PostQuitMessage(0);
    }break;
    default: return (LONG_PTR)FALSE;
    }
    return (LONG_PTR)FALSE;
}

//
//  FUNCTION: WndProc(HWND, UINT, WPARAM, LPARAM)
//
//  PURPOSE: Processes messages for the main window.
//
//  WM_COMMAND  - process the application menu
//  WM_PAINT    - Paint the main window
//  WM_DESTROY  - post a quit message and return
//
//
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam) {
    switch (message) {
    case WM_COMMAND: {
        return DefWindowProc(hWnd, message, wParam, lParam);
    }break;
    case WM_PAINT: {
        PAINTSTRUCT ps;
        HDC hdc = BeginPaint(hWnd, &ps);
        // TODO: Add any drawing code that uses hdc here...
        FillRect(hdc, &ps.rcPaint, (HBRUSH)(COLOR_WINDOW + 1));
        EndPaint(hWnd, &ps);
    } break;
    case WM_DESTROY: {
        PostQuitMessage(0);
    } break;
    default:
        return DefWindowProc(hWnd, message, wParam, lParam);
    }
    return 0;
}

// Message handler for about box.
LONG_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam) {
    UNREFERENCED_PARAMETER(lParam);
    switch (message) {
    case WM_INITDIALOG:
        return (INT_PTR)TRUE;

    case WM_COMMAND:
        if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL) {
            EndDialog(hDlg, LOWORD(wParam));
            return (INT_PTR)TRUE;
        }
        break;
    }
    return (INT_PTR)FALSE;
}

std::wstring s2ws(const std::string& s) {
    int len;
    int slength = (int)s.length() + 1;
    len = MultiByteToWideChar(CP_ACP, 0, s.c_str(), slength, 0, 0);
    wchar_t* buf = new wchar_t[len];
    MultiByteToWideChar(CP_ACP, 0, s.c_str(), slength, buf, len);
    std::wstring r(buf);
    delete[] buf;
    return r;
}

bool isFloat(std::wstring str) {
    std::wistringstream iss(str);
    float f;
    wchar_t wc;
    if (!(iss >> f) || iss.get(wc))
        return false;
    return true;
}

bool isInt(std::wstring str) {
    std::wistringstream iss(str);
    int f;
    wchar_t wc;
    if (!(iss >> f) || iss.get(wc))
        return false;
    return true;
}

int onEditChange(HWND hDlg, int ctrlID, int type) {
    HWND hEdit = GetDlgItem(hDlg, ctrlID);
    size_t len = GetWindowTextLength(hEdit) + 1;
    wchar_t* cstr = new wchar_t[len];
    GetWindowText(hEdit, cstr, len);

    std::wstring wstr(cstr);
    bool condicion = type == 0 ? isInt(wstr) : isFloat(wstr);
    int result = 0;
    if (!(condicion)) {
        result = -1;
    }
    result = result == -1 ? -1 : wstr.length();
    delete[] cstr;
    return result;
}

void leerArchivoAlumnos() {
    ifstream variableArchivo; // Input File Stream
    variableArchivo.open("C:\\Users\\User\\source\\repos\\ConsoleApplication9\\alumnos.bin", ios::in | ios::binary);
    if (variableArchivo.is_open()) {
        variableArchivo.seekg(0, variableArchivo.end);
        int bytesLeido = variableArchivo.tellg();
        variableArchivo.seekg(0, variableArchivo.beg);
        int bytes = 0;
        while (bytes < bytesLeido) {
            ALUMNOS* alumnoLeido = new ALUMNOS;
            variableArchivo.read(reinterpret_cast<char*>(alumnoLeido), sizeof(ALUMNOS));
            alumnoLeido->anterior = NULL;
            alumnoLeido->siguiente = NULL;
            agregarAlumnoAlFinal(alumnoLeido);
            bytes = bytes + sizeof(ALUMNOS);
        }
        variableArchivo.close();
    }
}

void guardarArchivoAlumnos() {
    ofstream variableArchivo; // Output File Stream
    variableArchivo.open("C:\\Users\\User\\source\\repos\\ConsoleApplication9\\alumnos.bin", ios::binary | ios::trunc);
    if (variableArchivo.is_open()) {
        ALUMNOS* indice = ORIGEN;
        while (indice != NULL) {
            variableArchivo.write((char*)indice, sizeof(ALUMNOS));
            indice = indice->siguiente;
        }
        variableArchivo.close();
    }
}

void borrarAlumnoEnMedio(string nombreABorrar) {
    if (ORIGEN == NULL) {
        return;
    }
    ALUMNOS* indice = buscarAlumno(nombreABorrar);
    if (indice != NULL) {
        ALUMNOS* anterior = indice->anterior;
        ALUMNOS* siguiente = indice->siguiente;
        if (anterior == NULL) {
            borrarAlumnoAlInicio();
        }
        else if (siguiente == NULL) {
            borrarAlumnoAlFinal();
        }
        else {
            anterior->siguiente = siguiente;
            siguiente->anterior = anterior;
            delete indice;
        }
    }
}

void borrarAlumnoAlFinal() {
    if (ORIGEN == NULL) {
        return;
    }
    ALUMNOS* indice = ORIGEN;
    while (indice->siguiente != NULL) {
        indice = indice->siguiente;
    }
    ALUMNOS* anterior = indice->anterior;
    if (anterior != NULL)
        anterior->siguiente = NULL;
    delete indice;
}

void borrarAlumnoAlInicio() {
    if (ORIGEN == NULL) {
        return;
    }
    ALUMNOS* indice = ORIGEN;
    ORIGEN = ORIGEN->siguiente;
    if (ORIGEN != NULL)
        ORIGEN->anterior = NULL;
    delete indice;
}

void modificarAlumno(ALUMNOS *indice, int edad, float peso) {
    if (ORIGEN == NULL) {
        return;
    }
    if (indice != NULL) {
        indice->edad = edad;
        indice->peso = peso;
    }
}

void modificarAlumno(string nombreABuscar, int edad, float peso) {
    if (ORIGEN == NULL) {
        return;
    }
    ALUMNOS* indice = buscarAlumno(nombreABuscar);
    modificarAlumno(indice, edad, peso);
}

void borrarListaAlumnos() {
    ALUMNOS* indice = ORIGEN;
    while (indice != NULL) {
        ALUMNOS* borrar = indice;
        indice = indice->siguiente;
        delete borrar;
    }
    ORIGEN = NULL;
}

ALUMNOS* buscarAlumno(string nombreBuscar) {
    if (ORIGEN == NULL) {
        return NULL;
    }
    ALUMNOS* indice = ORIGEN;
    bool encontrado = false;
    while (indice != NULL) {
        //		if (indice->nombre.compare(nombreBuscar) == 0){
        if (_strcmpi(indice->nombre, nombreBuscar.c_str()) == 0) {
            encontrado = true;
            break;
        }
        indice = indice->siguiente;
    }
    return indice;
}

void agregarAlumnoEnMedio(ALUMNOS* alumno, string nombreBuscar) {
    if (ORIGEN == NULL) {
        ORIGEN = alumno;
    }
    else {
        ALUMNOS* indice = buscarAlumno(nombreBuscar);
        if (indice != NULL) {
            ALUMNOS* anterior = indice->anterior;
            if (anterior == NULL) {
                agregarAlumnoAlInicio(alumno);
            }
            else {
                anterior->siguiente = alumno;
                alumno->anterior = anterior;
                alumno->siguiente = indice;
                indice->anterior = alumno;
            }
        }
    }
}

void agregarAlumnoAlFinal(ALUMNOS* alumno) {
    if (ORIGEN == NULL) {
        ORIGEN = alumno;
    }
    else {
        ALUMNOS* indice = ORIGEN;
        while (indice->siguiente != NULL) {
            indice = indice->siguiente;
        }
        indice->siguiente = alumno;
        alumno->anterior = indice;
    }
}

void agregarAlumnoAlInicio(ALUMNOS* alumno) {
    if (ORIGEN == NULL) {
        ORIGEN = alumno;
    }
    else {
        ALUMNOS* indice = ORIGEN;
        alumno->siguiente = indice;
        indice->anterior = alumno;
        ORIGEN = alumno;
    }
}

ALUMNOS* crearAlumno(string nombre, int edad, float peso) {
    ALUMNOS* persona = new ALUMNOS;
    //	persona->nombre = nombre;
    strcpy_s(persona->nombre, 255, nombre.c_str());
    persona->edad = edad;
    persona->peso = peso;
    persona->anterior = NULL;
    persona->siguiente = NULL;
    return persona;
}

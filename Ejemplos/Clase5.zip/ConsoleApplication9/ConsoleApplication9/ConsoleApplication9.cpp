#include <iostream>
#include <fstream>

using namespace std;

struct ALUMNOS{
	char nombre[255];
//	string nombre;
	int edad;
	float peso;
	ALUMNOS* anterior;
	ALUMNOS* siguiente;
}*ORIGEN;

ALUMNOS* crearAlumno(string nombre, int edad, float peso);
void agregarAlumnoAlInicio(ALUMNOS* alumno);
void agregarAlumnoAlFinal(ALUMNOS* alumno);
void agregarAlumnoEnMedio(ALUMNOS* alumno, string nombreBuscar);
ALUMNOS* buscarAlumno(string nombreBuscar);
void borrarListaAlumnos();
void modificarAlumno(string nombreABuscar, int edad, float peso);
void borrarAlumnoAlInicio();
void borrarAlumnoAlFinal();
void borrarAlumnoEnMedio(string nombreABorrar);
void guardarArchivoAlumnos();
void leerArchivoAlumnos();

int main(int numeroDeParametros, char** arregloDeParametros) { //char** -> string []
	ORIGEN = NULL;
	leerArchivoAlumnos();

	ALUMNOS* alumno = crearAlumno("Rafael", 18, 60);
	agregarAlumnoAlInicio(alumno);
	alumno = crearAlumno("Nicole", 18, 50);
	agregarAlumnoAlFinal(alumno);
	ALUMNOS* indice = ORIGEN;
	while (indice != NULL) {
		cout << indice->nombre << ", ";
		indice = indice->siguiente;
	}
	cout << endl;
	alumno = crearAlumno("Edgar", 18, 60);
	agregarAlumnoEnMedio(alumno,"Rafael");
	indice = ORIGEN;
	while (indice != NULL) {
		cout << indice->nombre << ", ";
		indice = indice->siguiente;
	}
	cout << endl;
	modificarAlumno("Rafael", 20, 65);
	indice = ORIGEN;
	while (indice != NULL) {
		cout << indice->nombre << ", ";
		indice = indice->siguiente;
	}
	guardarArchivoAlumnos();
	borrarListaAlumnos();
	return 0;
}

void leerArchivoAlumnos() {
	ifstream variableArchivo; // Input File Stream
	variableArchivo.open("C:\\Users\\User\\source\\repos\\ConsoleApplication9\\alumnos.bin", ios::in | ios::binary);
	if (variableArchivo.is_open()) {
		variableArchivo.seekg(0, variableArchivo.end);
		int bytesLeido = variableArchivo.tellg();
		variableArchivo.seekg(0, variableArchivo.beg);
		int bytes = 0;
		while (bytes < bytesLeido) {
			ALUMNOS* alumnoLeido = new ALUMNOS;
			variableArchivo.read(reinterpret_cast<char *>(alumnoLeido), sizeof(ALUMNOS));
			alumnoLeido->anterior = NULL;
			alumnoLeido->siguiente = NULL;
			agregarAlumnoAlFinal(alumnoLeido);
			bytes = bytes + sizeof(ALUMNOS);
		}
		variableArchivo.close();
	}
}

void guardarArchivoAlumnos() {
	ofstream variableArchivo; // Output File Stream
	variableArchivo.open("C:\\Users\\User\\source\\repos\\ConsoleApplication9\\alumnos.bin", ios::binary | ios::trunc);
	if (variableArchivo.is_open()) {
		ALUMNOS* indice = ORIGEN;
		while (indice != NULL) {
			variableArchivo.write((char*)indice, sizeof(ALUMNOS));
			indice = indice->siguiente;
		}
		variableArchivo.close();
	}
}

void borrarAlumnoEnMedio(string nombreABorrar) {
	if (ORIGEN == NULL) {
		return;
	}
	ALUMNOS* indice = buscarAlumno(nombreABorrar);
	if (indice != NULL) {
		ALUMNOS* anterior = indice->anterior;
		ALUMNOS* siguiente = indice->siguiente;
		if (anterior == NULL) {
			borrarAlumnoAlInicio();
		} else if (siguiente == NULL) {
			borrarAlumnoAlFinal();
		} else {
			anterior->siguiente = siguiente;
			siguiente->anterior = anterior;
			delete indice;
		}
	}
}

void borrarAlumnoAlFinal() {
	if (ORIGEN == NULL) {
		return;
	}
	ALUMNOS* indice = ORIGEN;
	while (indice->siguiente != NULL) {
		indice = indice->siguiente;
	}
	ALUMNOS* anterior = indice->anterior;
	if (anterior != NULL)
		anterior->siguiente = NULL;
	delete indice;
}

void borrarAlumnoAlInicio() {
	if (ORIGEN == NULL) {
		return;
	}
	ALUMNOS* indice = ORIGEN;
	ORIGEN = ORIGEN->siguiente;
	if (ORIGEN != NULL)
		ORIGEN->anterior = NULL;
	delete indice;
}

void modificarAlumno(string nombreABuscar, int edad, float peso) {
	if (ORIGEN == NULL) {
		return;
	}
	ALUMNOS* indice = buscarAlumno(nombreABuscar);
	if (indice != NULL) {
		indice->edad = edad;
		indice->peso = peso;
	}
}

void borrarListaAlumnos() {
	ALUMNOS* indice = ORIGEN;
	while (indice != NULL) {
		ALUMNOS* borrar = indice;
		indice = indice->siguiente;
		delete borrar;
	}
	ORIGEN = NULL;
}

ALUMNOS* buscarAlumno(string nombreBuscar) {
	if (ORIGEN == NULL) {
		return NULL;
	}
	ALUMNOS* indice = ORIGEN;
	bool encontrado = false;
	while (indice != NULL) {
//		if (indice->nombre.compare(nombreBuscar) == 0){
		if (_strcmpi(indice->nombre, nombreBuscar.c_str()) == 0) {
			encontrado = true;
			break;
		}
		indice = indice->siguiente;
	}
	return indice;
}

void agregarAlumnoEnMedio(ALUMNOS* alumno, string nombreBuscar) {
	if (ORIGEN == NULL) {
		ORIGEN = alumno;
	} else {
		ALUMNOS* indice = buscarAlumno(nombreBuscar);
		if (indice != NULL) {
			ALUMNOS* anterior = indice->anterior;
			if (anterior == NULL) {
				agregarAlumnoAlInicio(alumno);
			} else {
				anterior->siguiente = alumno;
				alumno->anterior = anterior;
				alumno->siguiente = indice;
				indice->anterior = alumno;
			}
		}
	}
}

void agregarAlumnoAlFinal(ALUMNOS* alumno) {
	if (ORIGEN == NULL) {
		ORIGEN = alumno;
	} else {
		ALUMNOS* indice = ORIGEN;
		while (indice->siguiente != NULL) {
			indice = indice->siguiente;
		}
		indice->siguiente = alumno;
		alumno->anterior = indice;
	}
}

void agregarAlumnoAlInicio(ALUMNOS *alumno) {
	if (ORIGEN == NULL) {
		ORIGEN = alumno;
	}else{
		ALUMNOS* indice = ORIGEN;
		alumno->siguiente = indice;
		indice->anterior = alumno;
		ORIGEN = alumno;
	}
}

ALUMNOS* crearAlumno(string nombre, int edad, float peso) {
	ALUMNOS* persona = new ALUMNOS;
//	persona->nombre = nombre;
	strcpy_s(persona->nombre, 255, nombre.c_str());
	persona->edad = edad;
	persona->peso = peso;
	persona->anterior = NULL;
	persona->siguiente = NULL;
	return persona;
}
















void laboratorioOrigen(){
	int* variable[5];
	int arreglo1[5]{ 0,1,2,3,4 };
	int arreglo2[5]{ 5,6,7,8,9 };
	int arreglo3[5]{ 10,11,12,13,14 };
	int arreglo4[5]{ 15,16,17,18,19 };
	int arreglo5[5]{ 20,21,22,23,24 };
	variable[0] = &arreglo1[0];
	variable[1] = &arreglo2[0];
	variable[2] = &arreglo3[0];
	variable[3] = &arreglo4[0];
	variable[4] = &arreglo5[0];
	for (int i = 0; i < 5; i++) {
		cout << "Direccion: " << &variable[i] << endl;
		for (int j = 0; j < 5; j++) {
			cout << variable[i][j] << "( " << &variable[i][j] << "), ";
		}
		cout << endl;
	}
}
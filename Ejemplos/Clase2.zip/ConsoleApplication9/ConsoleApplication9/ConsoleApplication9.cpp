// ConsoleApplication9.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>

using namespace std;

void regresaADiezAnios(int** edad);
void veinteAniosDespues(int** edad);

struct ALUMNOS {
	string nombre;
	int edad;
};

int main(int cantidadDeParametros, char **textoDelParametro) { //textoDelParametro[][]

	ALUMNOS alumno;	
	alumno.nombre;
	ALUMNOS* alu; // int,CHAR,FLOAT -> ALUMNOS
	alu = &alumno;
	alu = new ALUMNOS;
	delete alu;

	bool llamaraVeinteA�os = true;
	if (cantidadDeParametros > 0) {
		for (int i = 0; i < cantidadDeParametros; i++) {
			if (textoDelParametro[i][0] == 'S')
				llamaraVeinteA�os = false;
			cout << "Parametro " << i << ": " << textoDelParametro[i] << endl;
		}
		cout << endl;
	}
	int* pointer = NULL;
	int edad = 10;
	pointer = &edad; 
	if (llamaraVeinteA�os)
		veinteAniosDespues(&pointer);
	cout << *pointer << " - " << edad << endl;
	regresaADiezAnios(&pointer);
	cout << *pointer << " - " << edad;
	//+&pointer	0x00000066096ff788 {0x00000228ca400850 {10}}	int**
	delete pointer;
	//+pointer	0x0000000000008123 { ? ? ? }	int*
	pointer = NULL;
	if (pointer != NULL) {
		*pointer = 10;
	}

	return 0;
}
void regresaADiezAnios(int** edad) {
	*edad = new int;
	//**edad = 0x000000aaf4aff7e8 {0x0000029b74ac0850 {-842150451}}
	**edad = 10;
	//**edad = 0x000000aaf4aff7e8 {0x0000029b74ac0850 {10}}
}
void veinteAniosDespues(int** edad) {
	// **edad = 0x0000009a6f4ff7f8 {0x0000009a6f4ff814 {10}}
	int* pointer = (*edad);//pointer	0x0000009a6f4ff814 {10}	int *
	*pointer = *pointer + 5;
	edad[0][0] = edad[0][0] + 5;
	*(*edad) = *(*edad) + 10;
}

#include "framework.h"
#include "WindowsAPI.h"
#include <string>
#include <oleauto.h>
#include <commdlg.h>
#include <commctrl.h>
#include <iostream>
#include <sstream>

#define MAX_LOADSTRING 100
#if defined _WIN32 || defined __CYGWIN__
#define PATH_SEPARATOR '\\'
#else
#define PATH_SEPARATOR "/"
#endif
// Global Variables:
HINSTANCE hInst;                                // ID de programa (instancia)
WCHAR szTitle[MAX_LOADSTRING];                  // Titulo del programa
WCHAR szWindowClass[MAX_LOADSTRING];            // Nombre de la clase de la ventana principal
HWND hWndEdit;
HWND modal;
HWND ventanaPrincipal;

// Forward declarations of functions included in this code module:
ATOM                MyRegisterClass(HINSTANCE hInstance);
BOOL                InitInstance(HINSTANCE, int);
LRESULT CALLBACK    WndProc(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK    About(HWND, UINT, WPARAM, LPARAM);
std::wstring s2ws(const std::string& s);
LONG_PTR CALLBACK Dialog6_callback(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
LONG_PTR CALLBACK Dialog7_callback(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
bool MenuOpciones(HWND ventanaId, long opcion);

int APIENTRY wWinMain(_In_ HINSTANCE hInstance, _In_opt_ HINSTANCE hPrevInstance,
    _In_ LPWSTR lpCmdLine, _In_ int nCmdShow) { //LPWSTR = WCHAR * = WSTRING
    UNREFERENCED_PARAMETER(hPrevInstance);
    UNREFERENCED_PARAMETER(lpCmdLine);

    // Carga los titulos con los string en resource
    LoadStringW(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
    LoadStringW(hInstance, IDC_WINDOWSAPI, szWindowClass, MAX_LOADSTRING);
    // Se asignan propiedades a la pantalla principal
    MyRegisterClass(hInstance);

    // Se despliega la ventana principal
    if (!InitInstance(hInstance, nCmdShow)) {
        return FALSE;
    }

    // Se toma la lista de accesos directos creada en resource.h
    HACCEL hAccelTable = LoadAccelerators(hInstance, MAKEINTRESOURCE(IDC_WINDOWSAPI));
    // Variable para capturar mensajes
    MSG msg;

    // Bucle principal para leer mensajes de pantalla
    while (GetMessage(&msg, nullptr, 0, 0)) {
        // Verifica si el mensaje es un acceso directo, si lo es lo traduce y ejecuta
        if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg)) {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
    }

    return (int)msg.wParam;
}



//
//  FUNCTION: MyRegisterClass()
//
//  PURPOSE: Registers the window class.
//
ATOM MyRegisterClass(HINSTANCE hInstance) {
    WNDCLASSEXW wcex;
    wcex.cbSize = sizeof(WNDCLASSEX);

    wcex.style = CS_HREDRAW | CS_VREDRAW;
    wcex.lpfnWndProc = WndProc;  // Funcion de callback para la ventana
    wcex.cbClsExtra = 0;
    wcex.cbWndExtra = 0;
    wcex.hInstance = hInstance;
    wcex.hIcon = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_WINDOWSAPI));
    wcex.hCursor = LoadCursor(nullptr, IDC_ARROW);
    wcex.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
    wcex.lpszMenuName = MAKEINTRESOURCEW(IDC_WINDOWSAPI);
    wcex.lpszClassName = szWindowClass;
    wcex.hIconSm = LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_SMALL));

    return RegisterClassExW(&wcex);
}

//
//   FUNCTION: InitInstance(HINSTANCE, int)
//
//   PURPOSE: Saves instance handle and creates main window
//
//   COMMENTS:
//
//        In this function, we save the instance handle in a global variable and
//        create and display the main program window.
//
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow) {
    hInst = hInstance; // Store instance handle in our global variable

    ventanaPrincipal = CreateWindowW(
        szWindowClass,
        szTitle,
        WS_OVERLAPPEDWINDOW,
        CW_USEDEFAULT, // Position X
        0,             // Position Y
        CW_USEDEFAULT,
        0,
        nullptr,
        nullptr,
        hInstance,
        nullptr);

    if (!ventanaPrincipal) {
        return FALSE;
    }
/*
    HWND hwndButton = CreateWindowW(
        L"BUTTON",  // Predefined class; Unicode assumed 
        L"OK JEJE",      // Button text 
        WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON,  // Styles 
        10,         // x position 
        10,         // y position 
        100,        // Button width
        100,        // Button height
        ventanaPrincipal,       // Parent window
        (HMENU)1002,       // No menu. NULL
        (HINSTANCE)GetWindowLongPtr(ventanaPrincipal, GWLP_HINSTANCE),
        NULL);      // Pointer not needed.

    HWND hwndButton2 = CreateWindowW(
        L"BUTTON",  // Predefined class; Unicode assumed 
        L"Nuevo Dialog",      // Button text 
        WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON,  // Styles 
        150,         // x position 
        150,         // y position 
        100,        // Button width
        100,        // Button height
        ventanaPrincipal,       // Parent window
        (HMENU)1004,       // No menu. NULL
        (HINSTANCE)GetWindowLongPtr(ventanaPrincipal, GWLP_HINSTANCE),
        NULL);      // Pointer not needed.

    HWND hwndButton3 = CreateWindowW(
        L"BUTTON",  // Predefined class; Unicode assumed 
        L"Calculadora",      // Button text 
        WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON,  // Styles 
        300,         // x position 
        300,         // y position 
        100,        // Button width
        50,        // Button height
        ventanaPrincipal,       // Parent window
        (HMENU)1005,       // No menu. NULL
        (HINSTANCE)GetWindowLongPtr(ventanaPrincipal, GWLP_HINSTANCE),
        NULL);      // Pointer not needed.
    HWND hwndButton4 = CreateWindowW(
        L"BUTTON",  // Predefined class; Unicode assumed 
        L"UnionAvances",      // Button text 
        WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON,  // Styles 
        500,         // x position 
        300,         // y position 
        100,        // Button width
        50,        // Button height
        ventanaPrincipal,       // Parent window
        (HMENU)1006,       // No menu. NULL
        (HINSTANCE)GetWindowLongPtr(ventanaPrincipal, GWLP_HINSTANCE),
        NULL);      // Pointer not needed.
    HWND hwndButton5 = CreateWindowW(
        L"BUTTON",  // Predefined class; Unicode assumed 
        L"Mostrar Nodos",      // Button text 
        WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON,  // Styles 
        500,         // x position 
        150,         // y position 
        100,        // Button width
        50,        // Button height
        ventanaPrincipal,       // Parent window
        (HMENU)1007,       // No menu. NULL
        (HINSTANCE)GetWindowLongPtr(ventanaPrincipal, GWLP_HINSTANCE),
        NULL);      // Pointer not needed.

    // Creamos un textbox para capturar texto
    hWndEdit = CreateWindowEx(
        WS_EX_CLIENTEDGE,
        TEXT("Edit"),
        TEXT("test asdas as"),
        WS_CHILD | WS_VISIBLE,
        200, 20,
        255,
        20, ventanaPrincipal, (HMENU)1003, NULL, NULL);*/
    ShowWindow(ventanaPrincipal, SW_HIDE);
    UpdateWindow(ventanaPrincipal);

    HWND modal = CreateDialog(hInst, MAKEINTRESOURCE(IDD_DIALOG6), NULL, Dialog6_callback);
    ShowWindow(modal, SW_SHOW);
    // HMENU hMenuOpciones = LoadMenu(hInst, MAKEINTRESOURCE(IDC_WINDOWSAPI));
    // SetMenu(modal, hMenuOpciones);
    UpdateWindow(modal);

    return TRUE;
}

bool MenuOpciones(HWND ventanaId, long opcion) {
    switch (opcion) {
        case ID_PRUEBA1_ABRIRDIALOGO7: {
            HWND noModal = CreateDialog(hInst, MAKEINTRESOURCE(IDD_DIALOG7), NULL, Dialog7_callback);
            ShowWindow(noModal, SW_SHOW);
            UpdateWindow(noModal);
            EndDialog(ventanaId, opcion);
        }break;
        case ID_PRUEBA2_TEST3: {
            MessageBox(ventanaId, L"Trigger Test3", TEXT("Trigger Prueba2"), 1);
        }break;
        case ID_PRUEBA1_TEST2: {
            MessageBox(ventanaId, L"Trigger Test2", TEXT("Trigger Prueba1"), 1);
        } break;
        case IDM_ABOUT: {
            DialogBox(hInst, MAKEINTRESOURCE(IDD_ABOUTBOX), ventanaId, About);
        } break;
        case IDM_EXIT:
        case WM_DESTROY:
            DestroyWindow(ventanaId);
            break;
        default: return false;
    }
    return true;
}

LONG_PTR CALLBACK Dialog7_callback(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam) {
    SYSTEMTIME date;
    TCHAR buffer[200];
    switch (message) {
        case WM_INITDIALOG: {
            date.wYear = 2021;
            date.wMonth = 06;
            date.wDay = 20;
            date.wHour = 0;
            date.wMinute = 0;
            date.wSecond = 0;
            date.wMilliseconds = 0;
            DateTime_SetSystemtime(GetDlgItem(hWnd, IDC_DATETIMEPICKER1), GDT_VALID, &date);
            date.wDay = 30;
            DateTime_SetSystemtime(GetDlgItem(hWnd, IDC_DATETIMEPICKER2), GDT_VALID, &date);
            return (LONG_PTR)TRUE;
        } break;
        case WM_COMMAND: {
            long wmId = LOWORD(wParam);
            if (MenuOpciones(hWnd, wmId)) {
                return (LONG_PTR)FALSE;
            }
            switch (wmId) {
                case IDOK: {
                    double fecha1, fecha2;
                    DateTime_GetSystemtime(GetDlgItem(hWnd, IDC_DATETIMEPICKER1), &date);
    //                GetDateFormat(LOCALE_USER_DEFAULT, DATE_LONGDATE, &date, NULL, buffer, 200);
    //                MessageBox(hWnd, buffer, L"Espera 1", 0);
                    if (!SystemTimeToVariantTime(&date, &fecha1)) {
                        fecha1 = 0;
                    }
                    DateTime_GetSystemtime(GetDlgItem(hWnd, IDC_DATETIMEPICKER2), &date);
                    if (!SystemTimeToVariantTime(&date, &fecha2)) {
                        fecha2 = 0;
                    }
                    if ((int)fecha1 > (int)fecha2) {
                        MessageBox(hWnd, L"Fecha 1 es mayor a Fecha 2", L"Espera 1", 0);
                    } else if ((int)fecha1 < (int)fecha2) {
                        MessageBox(hWnd, L"Fecha 1 es menor a Fecha 2", L"Espera 1", 0);
                    }else MessageBox(hWnd, L"Fecha 1 es igual a Fecha 2", L"Espera 1", 0);
                    fecha1 = fecha1 + 20;
                    if (!VariantTimeToSystemTime(fecha1, &date)) {
                    }
                    GetDateFormat(LOCALE_USER_DEFAULT, DATE_SHORTDATE, &date, NULL, buffer, 200);
                    MessageBox(hWnd, buffer, L"Espera 1", 0);
                    DateTime_SetSystemtime(GetDlgItem(hWnd, IDC_DATETIMEPICKER2), GDT_VALID, &date);

                } break;
                default: return DefWindowProc(hWnd, message, wParam, lParam);
            }
        }break;
        case WM_PAINT: {
            PAINTSTRUCT ps;
            HDC hdc = BeginPaint(hWnd, &ps);
            FillRect(hdc, &ps.rcPaint, (HBRUSH)(COLOR_WINDOW));
            EndPaint(hWnd, &ps);
        }break;
        case WM_DESTROY: {
            PostQuitMessage(0);
        }break;
        default: return (LONG_PTR)FALSE;
    }
    return (LONG_PTR)FALSE;
}

LONG_PTR CALLBACK Dialog6_callback(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam) {
    switch (message) {
        case WM_INITDIALOG: {
            return (LONG_PTR)TRUE;
        } break;
        case WM_COMMAND: {
            long wmId = LOWORD(wParam);
            if (MenuOpciones(hWnd, wmId)) {
                return (LONG_PTR)FALSE;
            }
            switch (wmId) {
                default: return DefWindowProc(hWnd, message, wParam, lParam);
            }
        }break;
        case WM_PAINT: {
            PAINTSTRUCT ps;
            HDC hdc = BeginPaint(hWnd, &ps);
            FillRect(hdc, &ps.rcPaint, (HBRUSH)(COLOR_WINDOW));
            EndPaint(hWnd, &ps);
        }break;
        case WM_DESTROY: {
            PostQuitMessage(0);
        }break;
        default: return (LONG_PTR)FALSE;
    }
    return (LONG_PTR)FALSE;
}

//
//  FUNCTION: WndProc(HWND, UINT, WPARAM, LPARAM)
//
//  PURPOSE: Processes messages for the main window.
//
//  WM_COMMAND  - process the application menu
//  WM_PAINT    - Paint the main window
//  WM_DESTROY  - post a quit message and return
//
//
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam) {
    switch (message) {
    case WM_COMMAND: {
        return DefWindowProc(hWnd, message, wParam, lParam);
    }break;
    case WM_PAINT: {
        PAINTSTRUCT ps;
        HDC hdc = BeginPaint(hWnd, &ps);
        // TODO: Add any drawing code that uses hdc here...
        FillRect(hdc, &ps.rcPaint, (HBRUSH)(COLOR_WINDOW + 1));
        EndPaint(hWnd, &ps);
    } break;
    case WM_DESTROY: {
        PostQuitMessage(0);
    } break;
    default:
        return DefWindowProc(hWnd, message, wParam, lParam);
    }
    return 0;
}

// Message handler for about box.
LONG_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam) {
    UNREFERENCED_PARAMETER(lParam);
    switch (message) {
    case WM_INITDIALOG:
        return (INT_PTR)TRUE;

    case WM_COMMAND:
        if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL) {
            EndDialog(hDlg, LOWORD(wParam));
            return (INT_PTR)TRUE;
        }
        break;
    }
    return (INT_PTR)FALSE;
}

std::wstring s2ws(const std::string& s) {
    int len;
    int slength = (int)s.length() + 1;
    len = MultiByteToWideChar(CP_ACP, 0, s.c_str(), slength, 0, 0);
    wchar_t* buf = new wchar_t[len];
    MultiByteToWideChar(CP_ACP, 0, s.c_str(), slength, buf, len);
    std::wstring r(buf);
    delete[] buf;
    return r;
}

bool isFloat(std::wstring str) {
    std::wistringstream iss(str);
    float f;
    wchar_t wc;
    if (!(iss >> f) || iss.get(wc))
        return false;
    return true;
}

bool isInt(std::wstring str) {
    std::wistringstream iss(str);
    int f;
    wchar_t wc;
    if (!(iss >> f) || iss.get(wc))
        return false;
    return true;
}

int onEditChange(HWND hDlg, int ctrlID, int type) {
    HWND hEdit = GetDlgItem(hDlg, ctrlID);
    size_t len = GetWindowTextLength(hEdit) + 1;
    wchar_t* cstr = new wchar_t[len];
    GetWindowText(hEdit, cstr, len);

    std::wstring wstr(cstr);
    bool condicion = type == 0 ? isInt(wstr) : isFloat(wstr);
    int result = 0;
    if (!(condicion)) {
        result = -1;
    }
    result = result == -1 ? -1 : wstr.length();
    delete[] cstr;
    return result;
}
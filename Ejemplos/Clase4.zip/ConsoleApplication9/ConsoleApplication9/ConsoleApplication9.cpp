#include <iostream>

using namespace std;

struct ALUMNOS{
	string nombre;
	int edad;
	float peso;
	ALUMNOS* anterior;
	ALUMNOS* siguiente;
	string foto1;
	char foto2[200];
	long segundos;
}*ORIGEN;

ALUMNOS* crearAlumno(string nombre, int edad, float peso);
void agregarAlumnoAlInicio(ALUMNOS* alumno);
void agregarAlumnoAlFinal(ALUMNOS* alumno);
void agregarAlumnoEnMedio(ALUMNOS* alumno, string nombreBuscar);
ALUMNOS* buscarAlumno(string nombreBuscar);
void borrarListaAlumnos();
void modificarAlumno(string nombreABuscar, int edad, float peso);
void borrarAlumnoAlInicio();
void borrarAlumnoAlFinal();
void borrarAlumnoEnMedio(string nombreABorrar);

int main(int numeroDeParametros, char** arregloDeParametros) { //char** -> string []


	float pi = 3.141516; // 3.1410000000
	int piI = (int)(pi * 1000); // 3141(.516)
	pi = (piI / 1000.0); // 3.141

	string piS = "3.141516";
	cout << piS.substr(0, 5);
	piS = piS.substr(0, 5);
	pi = atof(piS.c_str());




	ORIGEN = NULL;
	ALUMNOS* alumno = crearAlumno("Rafael", 18, 60);
	agregarAlumnoAlInicio(alumno);
//	alumno = crearAlumno("Nicole", 18, 50);
//	agregarAlumnoAlFinal(alumno);
	ALUMNOS* indice = ORIGEN;
	while (indice != NULL) {
		cout << indice->nombre << ", ";
		indice = indice->siguiente;
	}
	cout << endl;
	alumno = crearAlumno("Edgar", 18, 60);
	agregarAlumnoEnMedio(alumno,"Rafael");
	borrarAlumnoEnMedio("Rafael");
	indice = ORIGEN;
	while (indice != NULL) {
		cout << indice->nombre << ", ";
		indice = indice->siguiente;
	}
	cout << endl;
	modificarAlumno("Rafael", 20, 65);
	indice = ORIGEN;
	while (indice != NULL) {
		cout << indice->nombre << ", ";
		indice = indice->siguiente;
	}
	borrarListaAlumnos();
	return 0;
}

void borrarAlumnoEnMedio(string nombreABorrar) {
	if (ORIGEN == NULL) {
		return;
	}
	ALUMNOS* indice = buscarAlumno(nombreABorrar);
	if (indice != NULL) {
		ALUMNOS* anterior = indice->anterior;
		ALUMNOS* siguiente = indice->siguiente;
		if (anterior == NULL) {
			borrarAlumnoAlInicio();
		} else if (siguiente == NULL) {
			borrarAlumnoAlFinal();
		} else {
			anterior->siguiente = siguiente;
			siguiente->anterior = anterior;
			delete indice;
		}
	}
}

void borrarAlumnoAlFinal() {
	if (ORIGEN == NULL) {
		return;
	}
	ALUMNOS* indice = ORIGEN;
	while (indice->siguiente != NULL) {
		indice = indice->siguiente;
	}
	ALUMNOS* anterior = indice->anterior;
	if (anterior != NULL)
		anterior->siguiente = NULL;
	delete indice;
}

void borrarAlumnoAlInicio() {
	if (ORIGEN == NULL) {
		return;
	}
	ALUMNOS* indice = ORIGEN;
	ORIGEN = ORIGEN->siguiente;
	if (ORIGEN != NULL)
		ORIGEN->anterior = NULL;
	delete indice;
}

void modificarAlumno(string nombreABuscar, int edad, float peso) {
	if (ORIGEN == NULL) {
		return;
	}
	ALUMNOS* indice = buscarAlumno(nombreABuscar);
	if (indice != NULL) {
		indice->edad = edad;
		indice->peso = peso;
	}
}

void borrarListaAlumnos() {
	ALUMNOS* indice = ORIGEN;
	while (indice != NULL) {
		ALUMNOS* borrar = indice;
		indice = indice->siguiente;
		delete borrar;
	}
	ORIGEN = NULL;
}

ALUMNOS* buscarAlumno(string nombreBuscar) {
	if (ORIGEN == NULL) {
		return NULL;
	}
	ALUMNOS* indice = ORIGEN;
	bool encontrado = false;
	while (indice != NULL) {
		if (indice->nombre.compare(nombreBuscar) == 0) {
			encontrado = true;
			break;
		}
		indice = indice->siguiente;
	}
	return indice;
}

void agregarAlumnoEnMedio(ALUMNOS* alumno, string nombreBuscar) {
	if (ORIGEN == NULL) {
		ORIGEN = alumno;
	} else {
		ALUMNOS* indice = buscarAlumno(nombreBuscar);
		if (indice != NULL) {
			ALUMNOS* anterior = indice->anterior;
			if (anterior == NULL) {
				agregarAlumnoAlInicio(alumno);
			} else {
				anterior->siguiente = alumno;
				alumno->anterior = anterior;
				alumno->siguiente = indice;
				indice->anterior = alumno;
			}
		}
	}
}

void agregarAlumnoAlFinal(ALUMNOS* alumno) {
	if (ORIGEN == NULL) {
		ORIGEN = alumno;
	} else {
		ALUMNOS* indice = ORIGEN;
		while (indice->siguiente != NULL) {
			indice = indice->siguiente;
		}
		indice->siguiente = alumno;
		alumno->anterior = indice;
	}
}

void agregarAlumnoAlInicio(ALUMNOS *alumno) {
	if (ORIGEN == NULL) {
		ORIGEN = alumno;
	}else{
		ALUMNOS* indice = ORIGEN;
		alumno->siguiente = indice;
		indice->anterior = alumno;
		ORIGEN = alumno;
	}
}

ALUMNOS* crearAlumno(string nombre, int edad, float peso) {
	ALUMNOS* persona = new ALUMNOS;
	persona->nombre = nombre;
	persona->edad = edad;
	persona->peso = peso;
	persona->anterior = NULL;
	persona->siguiente = NULL;
	return persona;
}
















void laboratorioOrigen(){
	int* variable[5];
	int arreglo1[5]{ 0,1,2,3,4 };
	int arreglo2[5]{ 5,6,7,8,9 };
	int arreglo3[5]{ 10,11,12,13,14 };
	int arreglo4[5]{ 15,16,17,18,19 };
	int arreglo5[5]{ 20,21,22,23,24 };
	variable[0] = &arreglo1[0];
	variable[1] = &arreglo2[0];
	variable[2] = &arreglo3[0];
	variable[3] = &arreglo4[0];
	variable[4] = &arreglo5[0];
	for (int i = 0; i < 5; i++) {
		cout << "Direccion: " << &variable[i] << endl;
		for (int j = 0; j < 5; j++) {
			cout << variable[i][j] << "( " << &variable[i][j] << "), ";
		}
		cout << endl;
	}
}
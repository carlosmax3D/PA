#include <Windows.h>
#include <fstream>
#include <stdlib.h>
#include <string>
#include <ctype.h>
#include <sstream>
#include <ctime> 
#include "resource.h"

//Generar un ID para nuestro TIMER
#define MI_TIMER_GENERADO 117
//Se almacena en milisegundos la fecha actual desde la creacion de LINUX
time_t actualTime;
//Estructura dividida de Hora Min Segund, Dia mes a�o
tm* timeInfo;

using namespace std;


struct User {
	int IDUser;
	char username[50];
	char password[50];
	char personalName[50];
	char aliasEmpresa[50];
	char rutaImagenUser[MAX_PATH];
	User* next;
	User* prev;
}*oUser, * aUser, *userAccess;

struct Product {
	char nombre[50];
	char cantidad[10];
	//Agregar lo que usaremos para las fotos
	char codigo[10];
	char precio[10];
	char marca[50];
	char descripcion[100];
	char imaruta1[100];
	char imaruta2[100];
	char username[50];
	int IDUser; //para ligarla con el usuario
	Product* next;
	Product* prev;
}*oProduct, *aProduct;


struct Envios {
	char calle[20];
	char colonia[20];
	char ciudad[20];
	char estado[20];
	char producto[50];
	char cantidad[10];
	char monto[10];
	char mensaje[50];

	char fecha[15];
	char username[50];
	char resumen[15];
	

	int IDUser;
	Envios* next;
	Envios* prev;
	Envios* auxSEND;
	Envios* auxSENDp;
}*oEnvios, *aEnvios;


bool exitProgram = false;
bool exitProgramRegister = false;
HINSTANCE hGlobalInst;
HWND hTxtRegisterUserName;
HWND hTxtRegisterPassword;
HWND hTxtLoginUserName;
HWND hTxtLoginPassword;
HWND hTxtInfoVenPersonalName;
HWND hTxtInfoVenAliasEmpresa;
HWND hTxtInfoVenRutaImage;
HMENU hMenuOpciones;
fstream lectorEscritor;

HWND hTxtProductNombre;
HWND hTxtProductCantidad;
HWND hTxtProductMarca;
HWND hTxtProductCodigo;
HWND hTxtProductPrecio;
HWND hTxtProductDescripcion;
HWND hTxtProductIma1;
HWND hTxtProductIma2;

HWND hTxtEnviosCantidad;
HWND hTxtEnviosCalle;
HWND hTxtEnviosColonia;
HWND hTxtEnviosCiudad;
HWND hTxtEnviosEstado;
HWND hTxtEnviosMensaje;
HWND hTxtEnviosMonto;
HWND hTxtEnviosFecha;
HWND hTxtEnviosProducto;


bool pasa = true;

int GLOBAL_USER_ID = 1;
int opcion_list;
//int opcion_list_guardar = -1;
char edit[50];
bool cargaPro = true;

string aEnvioProducto = "";

string AFechaDTP = "";

int dayAux;

void freeMemoryUser();
void freeMemoryProduct();
void loadUser();
void loadProduct();
void loadSend();
void save(User*);
void saveProduct(Product*);
void saveSend(Envios*);
void getGlobalId();
void saveGlobalId();
string getText(HWND);
BOOL CALLBACK fLogin(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam);
BOOL CALLBACK fRegister(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam);
BOOL CALLBACK fInfoVendedor(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam);
BOOL CALLBACK fEnvios(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam);

BOOL CALLBACK fAltaEnvios(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam);
BOOL CALLBACK fModificarEnvios(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam);
BOOL CALLBACK fMostrarEnvios(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam);

BOOL CALLBACK fExit(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam);
BOOL CALLBACK fProductos(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam);
BOOL CALLBACK fAltaProductos(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam);
BOOL CALLBACK fModificarProductos(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam);
BOOL CALLBACK fMostrarProductos(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam);


int WINAPI WinMain(HINSTANCE hInst, HINSTANCE hPrev, PSTR cmdLine, int cShow) {
	getGlobalId();
	
	oUser = aUser = NULL;
	//oProduct = aProduct = NULL;
	hGlobalInst = hInst;
	HWND hLogin = CreateDialog(hInst, MAKEINTRESOURCE(DLG_LOGIN), NULL, (DLGPROC)(DLGPROC)fLogin);
	ShowWindow(hLogin, SW_SHOW);
	MSG msg;
	ZeroMemory(&msg, sizeof(MSG));
	while (GetMessage(&msg, NULL, 0, 0)) {
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
	return msg.wParam;
}
 
BOOL CALLBACK fLogin(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam) {
	switch (msg) {
	case WM_INITDIALOG: {
		loadUser();
		
		if (cargaPro) {
			loadProduct();
			loadSend();
		}

		hTxtLoginUserName = GetDlgItem(hwnd, TXT_LG_USER);
		hTxtLoginPassword = GetDlgItem(hwnd, TXT_LG_PASS);
	}break;
	case WM_COMMAND: {
		switch (LOWORD(wparam)) {
		case BTN_REGISTRO: {
			//Abre la ventana de registro
			HWND hRegister = CreateDialog(hGlobalInst, MAKEINTRESOURCE(DLG_REGISTRO), NULL, (DLGPROC)fRegister);
			ShowWindow(hRegister, SW_SHOW);
			exitProgram = false;
			DestroyWindow(hwnd);
		}break;
		case BTN_LG_EXIT: {
			HWND hExit = CreateDialog(hGlobalInst, MAKEINTRESOURCE(DLG_EXIT), NULL, (DLGPROC)(DLGPROC)fExit);
			ShowWindow(hExit, SW_SHOW);
			/*exitProgram = true;
			DestroyWindow(hwnd);*/
		}break;
		case BTN_LOGIN: {
			string userName = getText(hTxtLoginUserName);
			string password = getText(hTxtLoginPassword);
			if (userName.compare("") == 0) {
				MessageBox(NULL, "Introduzca un nombre de usuario para continuar", "NO LOGIN", MB_ICONASTERISK);
				break;
			}
			else if (password.compare("") == 0) {
				MessageBox(NULL, "Introduzca una contrase�a para continuar", "NO LOGIN", MB_ICONASTERISK);
				break;
			}
			if (oUser != NULL) {
				bool found = true;
				while (aUser != NULL) {
					if (strcmp(aUser->username, userName.c_str()) == 0 && strcmp(aUser->password, password.c_str()) == 0) {
						break;
					}
					if (aUser->next == NULL)
						found = false;
					aUser = aUser->next;
				}

				if (found == true) {
					userAccess = aUser;
					aUser = oUser;
					if (strcmp(userAccess->personalName, "") == 0 || strcmp(userAccess->aliasEmpresa, "") == 0) {
						HWND hInfoVen = CreateDialog(hGlobalInst, MAKEINTRESOURCE(DLG_INFO_VEN), NULL, (DLGPROC)(DLGPROC)fInfoVendedor);
						ShowWindow(hInfoVen, SW_SHOW);
						//hMenuOpciones = LoadMenu(hGlobalInst, MAKEINTRESOURCE(IDR_MENU1));
						//SetMenu(hInfoVen, hMenuOpciones);
						exitProgram = false;
						DestroyWindow(hwnd);
						break;
					}
					HWND hEnvios = CreateDialog(hGlobalInst, MAKEINTRESOURCE(DLG_ENVIOS), NULL, (DLGPROC)(DLGPROC)fEnvios);
					ShowWindow(hEnvios, SW_SHOW);
					exitProgram = false;
					DestroyWindow(hwnd);
					break;
				}
				else {
					MessageBox(NULL, "Ningun usuario coincide con tus credenciales", "NO LOGIN", MB_ICONASTERISK);
					aUser = oUser;
				}
			}
			else {
				MessageBox(NULL, "NO hay usuarios dados de alta", "NO LOGIN", MB_ICONASTERISK);
				break;
			}

		}break;
		}
	}break;
	case WM_CLOSE:
		exitProgram = true;
		DestroyWindow(hwnd);
		break;
	case WM_DESTROY:
		if (exitProgram) {
			freeMemoryUser();
			PostQuitMessage(117);
		}
		break;
	}
	return FALSE;
}

BOOL CALLBACK fRegister(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam) {
	switch (msg) {
	case WM_INITDIALOG: {
		cargaPro = false;
		hTxtRegisterUserName = GetDlgItem(hwnd, TXT_RG_USER);
		hTxtRegisterPassword = GetDlgItem(hwnd, TXT_RG_PASS);
	}break;
	case WM_COMMAND: {
		switch (LOWORD(wparam)) {
		case BTN_RG_REGISTRO: {
			string userName = getText(hTxtRegisterUserName);
			string password = getText(hTxtRegisterPassword);
			char userNameC[sizeof(userName)];
			strcpy_s(userNameC, userName.c_str());



			if (userName.compare("") == 0) {
				MessageBox(NULL, "Introduzca un nombre de usuario para continuar", "NO ALTA", MB_ICONASTERISK);
				break;
			}
			else {
				bool digito = false;
				int i = 0;
				while (userNameC[i]) {
					if (!isalpha(userNameC[i]) && !isspace(userNameC[i])) {
						MessageBox(NULL, "No introduzca numeros o simbolos en el usuario, cambie el nombre de usuario", "NO ALTA", MB_ICONASTERISK);
						digito = true;
						break;
					}
					i++;
				}
				if (digito)
					break;
			}

			if (password.compare("") == 0) {
				MessageBox(NULL, "Introduzca una contrase�a para continuar", "NO ALTA", MB_ICONASTERISK);
				break;
			}

			if (oUser != NULL) {
				bool found = true;
				while (strcmp(aUser->username, userName.c_str()) != 0) {
					if (aUser->next == NULL) {
						found = false;
						break;
					}
					aUser = aUser->next;
				}
				aUser = oUser;
				if (found == true) {
					MessageBox(NULL, "Nombre de usuario no disponible, cambielo", "NO ALTA", MB_ICONASTERISK);
					aUser = oUser;
					break;
				}
			}

			if (oUser == NULL) {
				oUser = new User;
				oUser->IDUser = GLOBAL_USER_ID;
				strcpy_s(oUser->username, userName.c_str());
				strcpy_s(oUser->password, password.c_str());
				strcpy_s(oUser->personalName, "");
				strcpy_s(oUser->aliasEmpresa, "");
				strcpy_s(oUser->rutaImagenUser, "");
				oUser->next = NULL;
				oUser->prev = NULL;
				aUser = oUser;
				GLOBAL_USER_ID++;
			}
			else {
				while (aUser->next != NULL)
					aUser = aUser->next;
				aUser->next = new User;
				aUser->next->prev = aUser;
				aUser = aUser->next;
				aUser->IDUser = GLOBAL_USER_ID;
				strcpy_s(aUser->username, userName.c_str());
				strcpy_s(aUser->password, password.c_str());
				strcpy_s(aUser->personalName, "");
				strcpy_s(aUser->aliasEmpresa, "");
				strcpy_s(aUser->rutaImagenUser, "");
				aUser->next = NULL;
				aUser = oUser;
				GLOBAL_USER_ID++;
			}
			save(aUser);
			saveGlobalId();
			aUser = oUser;
			freeMemoryUser();
			HWND hLogin = CreateDialog(hGlobalInst, MAKEINTRESOURCE(DLG_LOGIN), NULL, (DLGPROC)fLogin);
			ShowWindow(hLogin, SW_SHOW);
			exitProgramRegister = false;
			DestroyWindow(hwnd);
		}break;

		case BTN_RG_BACK: {
			HWND hLogin = CreateDialog(hGlobalInst, MAKEINTRESOURCE(DLG_LOGIN), NULL, (DLGPROC)fLogin);
			ShowWindow(hLogin, SW_SHOW);
			exitProgramRegister = false;
			DestroyWindow(hwnd);
		}
	}
	}break;
	case WM_CLOSE:
		exitProgramRegister = true;
		DestroyWindow(hwnd);
		break;
	case WM_DESTROY:
		if (exitProgramRegister) {
			freeMemoryUser();
			PostQuitMessage(117);
		}
		break;
	}
	return FALSE;
}

BOOL CALLBACK fInfoVendedor(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam) {
	string imagenUser = "";
	HWND btnMod = GetDlgItem(hwnd, BTN_INFOMODIFI);
	HWND btnAInfo = GetDlgItem(hwnd, BTN_INFOVEN_CONFIRMAR);
	HWND btnImagen = GetDlgItem(hwnd, BTN_INFOVEN_IMAGEN);
	HWND btnAMInfo = GetDlgItem(hwnd, BTN_MODGUARDAR);

	switch (msg) {
	case WM_INITDIALOG: {

		hTxtInfoVenPersonalName = GetDlgItem(hwnd, TXT_INFOVEN_NAME);
		hTxtInfoVenAliasEmpresa = GetDlgItem(hwnd, TXT_INFOVEN_ALIAS);
		hTxtInfoVenRutaImage = GetDlgItem(hwnd, TXT_INFOVEN_RUTAIMAGEN);

		EnableWindow(btnAMInfo, FALSE);

		if (strcmp(userAccess->personalName, "") != 0 || strcmp(userAccess->aliasEmpresa, "") != 0) {
			SendDlgItemMessage(hwnd, TXT_INFOVEN_NAME, WM_SETTEXT, sizeof(userAccess->personalName), (LPARAM)userAccess->personalName);
			SendDlgItemMessage(hwnd, TXT_INFOVEN_ALIAS, WM_SETTEXT, sizeof(userAccess->aliasEmpresa), (LPARAM)userAccess->aliasEmpresa);
			SendDlgItemMessage(hwnd, TXT_INFOVEN_RUTAIMAGEN, WM_SETTEXT, sizeof(userAccess->rutaImagenUser), (LPARAM)userAccess->rutaImagenUser);
			HBITMAP hbImagenUser = (HBITMAP)LoadImage(NULL, userAccess->rutaImagenUser, IMAGE_BITMAP, 100, 100, LR_LOADFROMFILE);
			HWND hPbImagen = GetDlgItem(hwnd, PB_INFO_IMAGEN);
			SendMessage(hPbImagen, STM_SETIMAGE, IMAGE_BITMAP, (LPARAM)hbImagenUser);
			EnableWindow(hTxtInfoVenPersonalName, FALSE);
			EnableWindow(hTxtInfoVenAliasEmpresa, FALSE);
			EnableWindow(btnMod, TRUE);
			EnableWindow(btnAInfo, FALSE);
			EnableWindow(btnImagen, FALSE);

			

		}



	}break;
	case WM_COMMAND: {
		switch (LOWORD(wparam)) {
		
		case ID_ACCIONES_INFOVEN: {
			HWND hInfoVen = CreateDialog(hGlobalInst, MAKEINTRESOURCE(DLG_INFO_VEN), NULL, (DLGPROC)(DLGPROC)fInfoVendedor);
			ShowWindow(hInfoVen, SW_SHOW);
			hMenuOpciones = LoadMenu(hGlobalInst, MAKEINTRESOURCE(IDR_MENU1));
			SetMenu(hInfoVen, hMenuOpciones);
			exitProgram = false;
			DestroyWindow(hwnd);
		}break;
		case ID_ACCIONES_PRD: {
			HWND hProductos = CreateDialog(hGlobalInst, MAKEINTRESOURCE(DLG_PRODUCTOS), NULL, (DLGPROC)fProductos);
			ShowWindow(hProductos, SW_SHOW);
			hMenuOpciones = LoadMenu(hGlobalInst, MAKEINTRESOURCE(IDR_MENU1));
			SetMenu(hProductos, hMenuOpciones);
			exitProgram = false;
			DestroyWindow(hwnd);
		}break;
		case ID_ACCION_ENVIOS: {
			HWND hEnvios = CreateDialog(hGlobalInst, MAKEINTRESOURCE(DLG_ENVIOS), NULL, (DLGPROC)fEnvios);
			ShowWindow(hEnvios, SW_SHOW);
			hMenuOpciones = LoadMenu(hGlobalInst, MAKEINTRESOURCE(IDR_MENU1));
			SetMenu(hEnvios, hMenuOpciones);
			exitProgram = false;
			DestroyWindow(hwnd);
		}break;
		case ID_ACCIONES_SALIR: {
			HWND hExit = CreateDialog(hGlobalInst, MAKEINTRESOURCE(DLG_EXIT), NULL, (DLGPROC)fExit);
			ShowWindow(hExit, SW_SHOW);
		}break;

		case BTN_INFOVEN_IMAGEN: {

			OPENFILENAME ofn; //Explorador de archivos
			ZeroMemory(&ofn, sizeof(OPENFILENAME));
			char rutaImagen[MAX_PATH] = ""; //Almacenara la ruta del archivo

			ofn.hwndOwner = hwnd; //Ventana padre del ofn
			ofn.lStructSize = sizeof(OPENFILENAME); // Tamanio total del ofn
			ofn.lpstrFile = rutaImagen; // DOnde almacenara la ruta del archivo
			ofn.nMaxFile = MAX_PATH; //Limite de caracteres en la ruta, en caso de exceder no abre el archivo
			ofn.lpstrDefExt = "txt"; //En caso de que el archivo no tenga extension, adjuntar esta
			ofn.Flags = OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_HIDEREADONLY;
			ofn.lpstrFilter = "Imagenes bmp\0*.bmp\0";

			if (GetOpenFileName(&ofn)) { //TRUE si selecciono un archivo, FALSE si le dio cancelar
				HBITMAP hbImagenUser = (HBITMAP)LoadImage(NULL, rutaImagen, IMAGE_BITMAP, 100, 100, LR_LOADFROMFILE);
				HWND hPbImagen = GetDlgItem(hwnd, PB_INFO_IMAGEN);
				for (int i = 0; i < sizeof(rutaImagen); i++) {
					imagenUser += rutaImagen[i];
				}
				SendMessage(hPbImagen, STM_SETIMAGE, IMAGE_BITMAP, (LPARAM)hbImagenUser);
				SendDlgItemMessage(hwnd, TXT_INFOVEN_RUTAIMAGEN, WM_SETTEXT, sizeof(imagenUser), (LPARAM)imagenUser.c_str());
				//MessageBox(NULL, rutaImagen, "NO REGISTRO INFORMACION", MB_ICONASTERISK);
			}
		}break;
		case BTN_INFOVEN_CONFIRMAR: {

			oUser = userAccess;
			if (oUser->IDUser == 1) {



				//MessageBox(hwnd, oUser->username, "texto", MB_ICONINFORMATION);
				string personalName = getText(hTxtInfoVenPersonalName);
				string aliasEmpresa = getText(hTxtInfoVenAliasEmpresa);
				string rutaImage = getText(hTxtInfoVenRutaImage);

				char userNameC[sizeof(personalName)];
				strcpy_s(userNameC, personalName.c_str());
				//validaciones
				if (personalName.compare("") == 0 || aliasEmpresa.compare("") == 0 || rutaImage.compare("") == 0) {
					MessageBox(NULL, "Falto llenar la informacion", "NO ALTA", MB_ICONASTERISK);
					break;
				}
				else {
					bool digito = false;
					int i = 0;
					while (userNameC[i]) {
						if (isdigit(userNameC[i])) {
							MessageBox(NULL, "No introduzca numeros en el nombre, cambie el nombre", "NO REGISTRO INFORMACION", MB_ICONASTERISK);
							digito = true;
							break;
						}
						i++;
					}
					if (digito)
						break;
				}
				for (int i = 0; i < aliasEmpresa.length(); i++) {
					// Y cambiar cada letra a may�scula
					aliasEmpresa[i] = toupper(aliasEmpresa[i]);
				}

				strcpy_s(userAccess->personalName, personalName.c_str());
				strcpy_s(userAccess->aliasEmpresa, aliasEmpresa.c_str());
				strcpy_s(userAccess->rutaImagenUser, rutaImage.c_str());
				oUser->next = NULL;
				oUser->prev = NULL;
				aUser = oUser;


			}
			else {
				aUser = userAccess;
				aUser->next = aUser;
				aUser = aUser->next;

				MessageBox(hwnd, oUser->username, "texto", MB_ICONINFORMATION);
				string personalName = getText(hTxtInfoVenPersonalName);
				string aliasEmpresa = getText(hTxtInfoVenAliasEmpresa);
				string rutaImage = getText(hTxtInfoVenRutaImage);

				char userNameC[sizeof(personalName)];
				strcpy_s(userNameC, personalName.c_str());
				//validaciones
				if (personalName.compare("") == 0 || aliasEmpresa.compare("") == 0 || rutaImage.compare("") == 0) {
					MessageBox(NULL, "Falto llenar la informacion", "NO ALTA", MB_ICONASTERISK);
					break;
				}
				else {
					bool digito = false;
					int i = 0;
					while (userNameC[i]) {
						if (isdigit(userNameC[i])) {
							MessageBox(NULL, "No introduzca numeros en el nombre, cambie el nombre", "NO REGISTRO INFORMACION", MB_ICONASTERISK);
							digito = true;
							break;
						}
						i++;
					}
					if (digito)
						break;
				}



				strcpy_s(userAccess->personalName, personalName.c_str());
				strcpy_s(userAccess->aliasEmpresa, aliasEmpresa.c_str());
				strcpy_s(userAccess->rutaImagenUser, rutaImage.c_str());
				aUser->next = NULL;
				userAccess = aUser;
				aUser = oUser;


			}

			while (oUser->prev != NULL) {
				oUser = oUser->prev;

			}



			save(oUser);
			aUser = oUser;
			HWND hEnvios = CreateDialog(hGlobalInst, MAKEINTRESOURCE(DLG_ENVIOS), NULL, (DLGPROC)fEnvios);
			ShowWindow(hEnvios, SW_SHOW);
			hMenuOpciones = LoadMenu(hGlobalInst, MAKEINTRESOURCE(IDR_MENU1));
			SetMenu(hEnvios, hMenuOpciones);
			exitProgram = false;
			DestroyWindow(hwnd);
		}break;
		
		case BTN_INFOMODIFI: {
			EnableWindow(hTxtInfoVenPersonalName, TRUE);
			EnableWindow(hTxtInfoVenAliasEmpresa, TRUE);
			EnableWindow(btnAInfo, FALSE);
			EnableWindow(btnImagen, TRUE);
			EnableWindow(btnMod, FALSE);
			EnableWindow(btnAMInfo, TRUE);



		}break;

		case  BTN_MODGUARDAR: {
			string personalName = getText(hTxtInfoVenPersonalName);
			string aliasEmpresa = getText(hTxtInfoVenAliasEmpresa);
			string rutaImage = getText(hTxtInfoVenRutaImage);
			char userNameC[sizeof(personalName)];
			strcpy_s(userNameC, personalName.c_str());

			if (personalName.compare("") == 0) {
				MessageBox(NULL, "Introduzca su nombre completo para continuar", "NO REGISTRO INFORMACION", MB_ICONERROR);
				break;
			}
			else {
				bool digito = false;
				int i = 0;
				while (userNameC[i]) {
					if (isdigit(userNameC[i])) {
						MessageBox(NULL, "No introduzca numeros en el nombre, cambie el nombre", "NO REGISTRO INFORMACION", MB_ICONASTERISK);
						digito = true;
						break;
					}
					i++;
				}
				if (digito)
					break;
			}

			if (aliasEmpresa.compare("") == 0) {
				MessageBox(NULL, "Introduzca su alias de empresa para continuar", "NO REGISTRO INFORMACION", MB_ICONERROR);
				break;

			}
			else if (rutaImage.compare("") == 0) {
				MessageBox(NULL, "Carge una imagen para continuar", "NO REGISTRO INFORMACION", MB_ICONERROR);
				break;

			}

			for (int i = 0; i < aliasEmpresa.length(); i++) {
				// Y cambiar cada letra por su representaci�n
				// may�scula
				aliasEmpresa[i] = toupper(aliasEmpresa[i]);
			}

			strcpy_s(userAccess->personalName, personalName.c_str());
			strcpy_s(userAccess->aliasEmpresa, aliasEmpresa.c_str());
			strcpy_s(userAccess->rutaImagenUser, rutaImage.c_str());


			save(oUser);

			EnableWindow(hTxtInfoVenPersonalName, FALSE);
			EnableWindow(hTxtInfoVenAliasEmpresa, FALSE);
			EnableWindow(btnAInfo, FALSE);
			EnableWindow(btnImagen, FALSE);
			EnableWindow(btnMod, TRUE);
			EnableWindow(btnAMInfo, FALSE);
		}break;

		}
	}break;
	case WM_DESTROY: {
		if (exitProgram) {
			freeMemoryUser();
			PostQuitMessage(117);
		}
	}break;
	}
	return FALSE;
}

BOOL CALLBACK fEnvios(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam) {
	switch (msg) {
	case WM_INITDIALOG: {
		hTxtInfoVenPersonalName = GetDlgItem(hwnd, TXT_INFOVEN_NAME);
		hTxtInfoVenAliasEmpresa = GetDlgItem(hwnd, TXT_INFOVEN_ALIAS);
		SendDlgItemMessage(hwnd, TXT_ENVIOS_VENDEDOR, WM_SETTEXT, sizeof(userAccess->personalName), (LPARAM)userAccess->personalName);
		//SendDlgItemMessage(hwnd, TXT_INFOVEN_ALIAS, WM_SETTEXT, sizeof(userAccess->aliasEmpresa), (LPARAM)userAccess->aliasEmpresa);
		//SendDlgItemMessage(hwnd, TXT_INFOVEN_RUTAIMAGEN, WM_SETTEXT, sizeof(userAccess->rutaImagenUser), (LPARAM)userAccess->rutaImagenUser);
		HBITMAP hbImagenUser = (HBITMAP)LoadImage(NULL, userAccess->rutaImagenUser, IMAGE_BITMAP, 100, 100, LR_LOADFROMFILE);
		HWND hPbImagen = GetDlgItem(hwnd, PB_ENVIOS_IMAGEN);
		SendMessage(hPbImagen, STM_SETIMAGE, IMAGE_BITMAP, (LPARAM)hbImagenUser);

		HWND hDtpTiempo = GetDlgItem(hwnd, DTP_ENVIOS_FECHA);
		int dtpSize = GetWindowTextLength(hDtpTiempo);
		char aCadenaDelDTP[80];
		GetWindowText(hDtpTiempo, aCadenaDelDTP, ++dtpSize);
		//Debuggear
		//MessageBox(NULL, cadenaDelDTP, "Fecha", MB_OK);
		string aFechaDTP(aCadenaDelDTP);
		AFechaDTP = aFechaDTP;



		if (oEnvios != NULL) {
			//bool found = true;
			//termina la burbuja

			while (aEnvios != NULL ) {//strcmp(aProduct->nombre, productName.c_str()) != 0) {

				if (strcmp(aEnvios->username, userAccess->username) == 0) {
				
					string fechaDTP(aEnvios->fecha);

					//strings para separar la fecha actual
					int del = AFechaDTP.find("/");
					string dayA = AFechaDTP.substr(0, del);
					int dayAn = stoi(dayA);
					int prev = del + 1;
					del = AFechaDTP.find("/", del+1);
					string monA = AFechaDTP.substr(prev, del-prev);
					int monAn = stoi(monA);
					prev = del + 1;
					del = AFechaDTP.find("/", del+1);
					string yearA = AFechaDTP.substr(prev);
					int yearAn = stoi(yearA);

					//strings para separar la fecha del envio
					del = fechaDTP.find("/");
					string dayE = fechaDTP.substr(0, del);
					int dayEn = stoi(dayE);
					prev = del + 1;
					del = fechaDTP.find("/", del + 1);
					string monE = fechaDTP.substr(prev, del-prev);
					int monEn = stoi(monE);
					prev = del + 1;
					del = fechaDTP.find("/", del + 1);
					string yearE = fechaDTP.substr(prev);
					int yearEn = stoi(yearE);

					string envioResumen = "Enviado";

					//saber si ya se ha enviado o no el producto
					if (yearEn < yearAn) {
				
						strcpy_s(aEnvios->resumen, envioResumen.c_str());
						

					}
					else if (yearEn > yearAn) {

					}
					else if (monEn < monAn) {
						strcpy_s(aEnvios->resumen, envioResumen.c_str());
						
					}
					else if (monEn > monAn) {

					}
					else if (dayEn < dayAn) {
						strcpy_s(aEnvios->resumen, envioResumen.c_str());
						
					}
					else if (dayEn >= dayAn) {

					
					}

					



				
					SendDlgItemMessage(hwnd, LISTA_E_ENVIOS, LB_ADDSTRING, 0, (LPARAM)aEnvios->mensaje);
					SendDlgItemMessage(hwnd, LISTA_E_ENVIOS2, LB_ADDSTRING, 0, (LPARAM)aEnvios->fecha);
					SendDlgItemMessage(hwnd, LISTA_E_ENVIOS3, LB_ADDSTRING, 0, (LPARAM)aEnvios->resumen);
				}




				if (aEnvios->next == NULL) {
					//found = false;
					break;
				}
				aEnvios = aEnvios->next;
			}
			aEnvios = oEnvios;
			/*if (found == true) {
				MessageBox(NULL, "Nombre de producto no disponible, cambielo", "NO ALTA", MB_ICONASTERISK);
				aProduct = oProduct;
				break;
			}*/
		}saveSend(aEnvios);

	}break;
	case WM_COMMAND: {
		switch (LOWORD(wparam)) {
		case ID_ACCIONES_INFOVEN: {
			HWND hInfoVen = CreateDialog(hGlobalInst, MAKEINTRESOURCE(DLG_INFO_VEN), NULL, (DLGPROC)fInfoVendedor);
			ShowWindow(hInfoVen, SW_SHOW);
			hMenuOpciones = LoadMenu(hGlobalInst, MAKEINTRESOURCE(IDR_MENU1));
			SetMenu(hInfoVen, hMenuOpciones);
			exitProgram = false;
			DestroyWindow(hwnd);
		}break;
		case ID_ACCIONES_PRD: {
			HWND hProductos = CreateDialog(hGlobalInst, MAKEINTRESOURCE(DLG_PRODUCTOS), NULL, (DLGPROC)fProductos);
			ShowWindow(hProductos, SW_SHOW);
			hMenuOpciones = LoadMenu(hGlobalInst, MAKEINTRESOURCE(IDR_MENU1));
			SetMenu(hProductos, hMenuOpciones);
			exitProgram = false;
			DestroyWindow(hwnd);
		}break;
		case ID_ACCION_ENVIOS: {
			HWND hEnvios = CreateDialog(hGlobalInst, MAKEINTRESOURCE(DLG_ENVIOS), NULL, (DLGPROC)fEnvios);
			ShowWindow(hEnvios, SW_SHOW);
			hMenuOpciones = LoadMenu(hGlobalInst, MAKEINTRESOURCE(IDR_MENU1));
			SetMenu(hEnvios, hMenuOpciones);
			exitProgram = false;
			DestroyWindow(hwnd);
		}break;
		case ID_ACCIONES_SALIR: {
			HWND hExit = CreateDialog(hGlobalInst, MAKEINTRESOURCE(DLG_EXIT), NULL, (DLGPROC)fExit);
			ShowWindow(hExit, SW_SHOW);
		}break;

		case BTN_E_NUEVO: {
			HWND hAltaEnvios = CreateDialog(hGlobalInst, MAKEINTRESOURCE(DLG_ALTA_ENVIO), NULL, (DLGPROC)fAltaEnvios);
			ShowWindow(hAltaEnvios, SW_SHOW);
			/*hMenuOpciones = LoadMenu(hGlobalInst, MAKEINTRESOURCE(IDR_MENU1));
			SetMenu(hProductos, hMenuOpciones);*/
			exitProgram = false;
			DestroyWindow(hwnd);
		}break;

		case BTN_E_MODIFICAR: { 
			opcion_list = SendDlgItemMessage(hwnd, LISTA_E_ENVIOS, LB_GETCURSEL, 0, 0);
			if (opcion_list != -1) {
				SendDlgItemMessage(hwnd, LISTA_E_ENVIOS, LB_GETTEXT, opcion_list, (LPARAM)edit);
				HWND hModificarEnvios = CreateDialog(hGlobalInst, MAKEINTRESOURCE(DLG_EDIT_ENVIO), NULL, (DLGPROC)fModificarEnvios);
				ShowWindow(hModificarEnvios, SW_SHOW);
				exitProgram = false;
				DestroyWindow(hwnd);
				//for (int i = 0; edit[i]; i++)
				//	edit[i] = toupper(edit[i]);
				////SendDlgItemMessage(hDlg, IDC_LIST1, LB_DELETESTRING, opcion_list, (LPARAM)opcion_list);
			}
			else {
				MessageBox(hwnd, "No seleccionaste nada, selecciona un envio para modicarlo", "No seleccionaste nada", MB_OK | MB_ICONERROR);
			}
		}break;

		case BTN_EMOSTRAR: {
			opcion_list = SendDlgItemMessage(hwnd, LISTA_E_ENVIOS, LB_GETCURSEL, 0, 0);
			if (opcion_list != -1) {
				SendDlgItemMessage(hwnd, LISTA_E_ENVIOS, LB_GETTEXT, opcion_list, (LPARAM)edit);
				HWND hMostrarEnvios = CreateDialog(hGlobalInst, MAKEINTRESOURCE(DLG_EDIT_ENVIO), NULL, (DLGPROC)fMostrarEnvios);
				ShowWindow(hMostrarEnvios, SW_SHOW);
				exitProgram = false;
				DestroyWindow(hwnd);
				//for (int i = 0; edit[i]; i++)
				//	edit[i] = toupper(edit[i]);
				////SendDlgItemMessage(hDlg, IDC_LIST1, LB_DELETESTRING, opcion_list, (LPARAM)opcion_list);
			}
			else {
				MessageBox(hwnd, "No seleccionaste nada, selecciona un envio para modicarlo", "No seleccionaste nada", MB_OK | MB_ICONERROR);
			}
		
		
		}break;

		case BTN_E_ELIMINAR: {

			opcion_list = SendDlgItemMessage(hwnd, LISTA_E_ENVIOS, LB_GETCURSEL, 0, 0);
			if (opcion_list != -1) {
				SendDlgItemMessage(hwnd, LISTA_E_ENVIOS, LB_GETTEXT, opcion_list, (LPARAM)edit); ///si no funciona lo tienes que poner como edit
				string abuscar = edit;

				if (oEnvios != NULL) {
					bool found = true;
					while (strcmp(aEnvios->mensaje, abuscar.c_str()) != 0) {
						if (aEnvios->next == NULL) {
							found = false;
							break;
						}
						aEnvios = aEnvios->next;
					}
					//aProduct = oProduct;
					if (found == true) {
						if (aEnvios->prev == NULL && aEnvios->next == NULL) { //El unico

							delete aEnvios; //Borramos el unico elemento
							aEnvios = oEnvios = NULL; //Regresamos todo a NULL para que se cumpla el primer if de ALTA

						}
						else if (aEnvios->prev == NULL) { //Primero
							oEnvios = oEnvios->next; //Movemos origen al siguiente elemento que ahora se convertira en el nuevo origen
							oEnvios->prev = NULL; //El previo de este nuevo origen es null para indicarnos que es el primer elemento
							delete aEnvios; //Borramos aux
							aEnvios = oEnvios; //Lo regresamos al nuevo origen
						}
						else if (aEnvios->next == NULL) { //Ultimo
							aEnvios->prev->next = NULL; // De aux (Ultimo) viajo a prev (Elemento anterior) y su sig lo apunto a NULL para indicar que ese es el nuevo ultimo elemento
							delete aEnvios; //Borro aux
							aEnvios = oEnvios; //Lo regresamos a origen
						}
						else { //Cualquier otro
							//Santiago->sig = Carlos ?
							aEnvios->prev->next = aEnvios->next;
							//Carlos->prev = Santiago ?
							aEnvios->next->prev = aEnvios->prev;
							delete aEnvios;
							aEnvios = oEnvios;
						}


						aEnvios = oEnvios;
						//encuentra el producto buscado y muestra los productos


						//break;
					}
					else {
						MessageBox(NULL, "Envio no encontrado, elija otro", "No existe el envio", MB_ICONASTERISK);
					}
				}
				saveSend(aEnvios);
				HWND hEnvios = CreateDialog(hGlobalInst, MAKEINTRESOURCE(DLG_ENVIOS), NULL, (DLGPROC)fEnvios);
				ShowWindow(hEnvios, SW_SHOW);
				/*hMenuOpciones = LoadMenu(hGlobalInst, MAKEINTRESOURCE(IDR_MENU1));
				SetMenu(hInfoVen, hMenuOpciones);*/
				exitProgram = false;
				DestroyWindow(hwnd);

			}
			else {
				MessageBox(hwnd, "No seleccionaste nada, selecciona un envio para eliminarlo", "No seleccionaste nada", MB_OK | MB_ICONERROR);
			}

		}break;

		}
	}break;
	case WM_DESTROY: {
		if (exitProgram) {
			freeMemoryUser();
			PostQuitMessage(117);
		}
	}break;
	}
	return FALSE;
}

BOOL CALLBACK fAltaEnvios(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam) {
	
	switch (msg) {
	case WM_INITDIALOG: {

		hTxtEnviosCantidad = GetDlgItem(hwnd, TXT_ENVIOS_CANTIDAD);
		hTxtEnviosCalle = GetDlgItem(hwnd, TXT_ENVIOS_CALLE);
		hTxtEnviosColonia= GetDlgItem(hwnd, TXT_ENVIOS_COLONIA);
		hTxtEnviosCiudad = GetDlgItem(hwnd, TXT_ENVIOS_CIUDAD);
		hTxtEnviosEstado = GetDlgItem(hwnd, TXT_ENVIOS_ESTADO);
		hTxtEnviosMensaje = GetDlgItem(hwnd, TXT_ENVIOS_MENSAJE);
		hTxtEnviosMonto = GetDlgItem(hwnd, TXT_ENVIOS_MONTO);

		hTxtInfoVenPersonalName = GetDlgItem(hwnd, TXT_INFOVEN_NAME);
		hTxtInfoVenAliasEmpresa = GetDlgItem(hwnd, TXT_INFOVEN_ALIAS);
		SendDlgItemMessage(hwnd, TXT_ENVIOS_VENDEDOR, WM_SETTEXT, sizeof(userAccess->personalName), (LPARAM)userAccess->personalName);
		//SendDlgItemMessage(hwnd, TXT_INFOVEN_ALIAS, WM_SETTEXT, sizeof(userAccess->aliasEmpresa), (LPARAM)userAccess->aliasEmpresa);
		//SendDlgItemMessage(hwnd, TXT_INFOVEN_RUTAIMAGEN, WM_SETTEXT, sizeof(userAccess->rutaImagenUser), (LPARAM)userAccess->rutaImagenUser);
		HBITMAP hbImagenUser = (HBITMAP)LoadImage(NULL, userAccess->rutaImagenUser, IMAGE_BITMAP, 100, 100, LR_LOADFROMFILE);
		HWND hPbImagen = GetDlgItem(hwnd, PB_ENVIOS_IMAGEN);
		SendMessage(hPbImagen, STM_SETIMAGE, IMAGE_BITMAP, (LPARAM)hbImagenUser);

		if (oProduct != NULL) {
			//bool found = true;
			while (aProduct != NULL) {//strcmp(aProduct->nombre, productName.c_str()) != 0) {
				if (strcmp(aProduct->username, userAccess->username) == 0) {
					SendDlgItemMessage(hwnd, LIST_PRODUCTOS, LB_ADDSTRING, 0, (LPARAM)aProduct->nombre);
				}
				if (aProduct->next == NULL) {
					//found = false;
					break;
				}
				aProduct = aProduct->next;
			}
			aProduct = oProduct;
			/*if (found == true) {
				MessageBox(NULL, "Nombre de producto no disponible, cambielo", "NO ALTA", MB_ICONASTERISK);
				aProduct = oProduct;
				break;
			}*/
		}

		HWND hDtpTiempo = GetDlgItem(hwnd, DTP_ENVIOS_FECHA);
		int dtpSize = GetWindowTextLength(hDtpTiempo);
		char aCadenaDelDTP[80];
		GetWindowText(hDtpTiempo, aCadenaDelDTP, ++dtpSize);
		//Debuggear
		//MessageBox(NULL, cadenaDelDTP, "Fecha", MB_OK);
		string aFechaDTP(aCadenaDelDTP);
		AFechaDTP = aFechaDTP;

	}break;
	case WM_COMMAND: {
		switch (LOWORD(wparam)) {
		case ID_ACCIONES_INFOVEN: {
			HWND hInfoVen = CreateDialog(hGlobalInst, MAKEINTRESOURCE(DLG_INFO_VEN), NULL, (DLGPROC)fInfoVendedor);
			ShowWindow(hInfoVen, SW_SHOW);
			hMenuOpciones = LoadMenu(hGlobalInst, MAKEINTRESOURCE(IDR_MENU1));
			SetMenu(hInfoVen, hMenuOpciones);
			exitProgram = false;
			DestroyWindow(hwnd);
		}break;
		case ID_ACCIONES_PRD: {
			HWND hProductos = CreateDialog(hGlobalInst, MAKEINTRESOURCE(DLG_PRODUCTOS), NULL, (DLGPROC)fProductos);
			ShowWindow(hProductos, SW_SHOW);
			hMenuOpciones = LoadMenu(hGlobalInst, MAKEINTRESOURCE(IDR_MENU1));
			SetMenu(hProductos, hMenuOpciones);
			exitProgram = false;
			DestroyWindow(hwnd);
		}break;
		case ID_ACCION_ENVIOS: {
			HWND hEnvios = CreateDialog(hGlobalInst, MAKEINTRESOURCE(DLG_ENVIOS), NULL, (DLGPROC)fEnvios);
			ShowWindow(hEnvios, SW_SHOW);
			hMenuOpciones = LoadMenu(hGlobalInst, MAKEINTRESOURCE(IDR_MENU1));
			SetMenu(hEnvios, hMenuOpciones);
			exitProgram = false;
			DestroyWindow(hwnd);
		}break;
		case ID_ACCIONES_SALIR: {
			HWND hExit = CreateDialog(hGlobalInst, MAKEINTRESOURCE(DLG_EXIT), NULL, (DLGPROC)fExit);
			ShowWindow(hExit, SW_SHOW);
		}break;
		

		//case BTN_ENVIOS_AGREGAR: {
		//	opcion_list = SendDlgItemMessage(hwnd, LIST_PRODUCTOS, LB_GETCURSEL, 0, 0);
		//	if (opcion_list != -1) {
		//		SendDlgItemMessage(hwnd, LIST_PRODUCTOS, LB_GETTEXT, opcion_list, (LPARAM)edit);
		//		/*for (int i = 0; edit[i]; i++)
		//			edit[i] = toupper(edit[i]);*/
		//		//SendDlgItemMessage(hwnd, LIST_PRODUCTOS_ENVIAR, LB_ADDSTRING, sizeof(edit), (LPARAM)edit);
		//		//SendDlgItemMessage(hwnd, LIST_PRODUCTOS, LB_DELETESTRING, opcion_list, (LPARAM)opcion_list);
		//		string enviosCantidad = getText(hTxtEnviosCantidad);
		//		//opcion_list_guardar++;
		//	}
		//	else {
		//		MessageBox(hwnd, "No seleccionaste nada", "Aviso", MB_OK | MB_ICONERROR);
		//	}
		//}break;

		//case BTN_ENVIOS_QUITAR: {
		//	opcion_list = SendDlgItemMessage(hwnd, LIST_PRODUCTOS_ENVIAR, LB_GETCURSEL, 0, 0);
		//	if (opcion_list != -1) {
		//		//SendDlgItemMessage(hwnd, LIST_PRODUCTOS_ENVIAR, LB_GETTEXT, opcion_list, (LPARAM)edit);

		//		//for (int i = 0; edit[i]; i++)
		//		//	edit[i] = toupper(edit[i]);
		//		//SendDlgItemMessage(hwnd, LIST_PRODUCTOS_ENVIAR, LB_ADDSTRING, sizeof(edit), (LPARAM)edit);
		//		SendDlgItemMessage(hwnd, LIST_PRODUCTOS_ENVIAR, LB_DELETESTRING, opcion_list, (LPARAM)opcion_list);
		//		//string enviosCantidad = getText(hTxtEnviosCantidad);
		//		//opcion_list_guardar--;
		//	}
		//	else {
		//		MessageBox(hwnd, "No seleccionaste nada", "Aviso", MB_OK | MB_ICONERROR);
		//	}
		//}break;

		case BTN_ENVIOS_CREAR: {
			//string envioCantidad = getText(hTxtEnviosCantidad);
			string envioCalle = getText(hTxtEnviosCalle);
			string envioColonia = getText(hTxtEnviosColonia);
			string envioCiudad = getText(hTxtEnviosCiudad);
			string envioEstado = getText(hTxtEnviosEstado);
			string envioMensaje = getText(hTxtEnviosMensaje);
			string envioMonto = getText(hTxtEnviosMonto);
			string enviosCantidad = getText(hTxtEnviosCantidad);
			string envioResumen = "Enviando";
			char envioCantidadC[sizeof(enviosCantidad)];
			strcpy_s(envioCantidadC, enviosCantidad.c_str());
			//string productImagen1 = getT
			/*char productCantidadC[sizeof(productCantidad)];
			strcpy_s(productCantidadC, productCantidad.c_str());
			char productCodigoC[sizeof(productCodigo)];
			strcpy_s(productCodigoC, productCodigo.c_str());
			char productPrecioC[sizeof(productPrecio)];
			strcpy_s(productPrecioC, productPrecio.c_str());*/

			opcion_list = SendDlgItemMessage(hwnd, LIST_PRODUCTOS, LB_GETCURSEL, 0, 0);
				if (opcion_list != -1) {
					SendDlgItemMessage(hwnd, LIST_PRODUCTOS, LB_GETTEXT, opcion_list, (LPARAM)edit);
					
					/*for (int i = 0; edit[i]; i++)
						edit[i] = toupper(edit[i]);*/
					//SendDlgItemMessage(hwnd, LIST_PRODUCTOS_ENVIAR, LB_ADDSTRING, sizeof(edit), (LPARAM)edit);
					//SendDlgItemMessage(hwnd, LIST_PRODUCTOS, LB_DELETESTRING, opcion_list, (LPARAM)opcion_list);
					

					//opcion_list_guardar++;
				}
				else {
					MessageBox(hwnd, "No seleccionaste ning�n producto, selecciona un producto para continuar", "NO ALTA", MB_OK | MB_ICONERROR);
					break;
				}
			string enviosProducto = edit;
			//calle
			if (envioCalle.compare("") == 0) {
				MessageBox(NULL, "Introduzca la calle del envio para continuar", "NO ALTA", MB_ICONASTERISK);
				break;
			}
			/*if (oProduct != NULL) {
				bool found = true;
				while (strcmp(aProduct->nombre, productName.c_str()) != 0) {
					if (aProduct->next == NULL) {
						found = false;
						break;
					}
					aProduct = aProduct->next;
				}
				aProduct = oProduct;
				if (found == true) {
					MessageBox(NULL, "Nombre de producto no disponible, cambielo", "NO ALTA", MB_ICONASTERISK);
					aProduct = oProduct;
					break;
				}*/

				//colonia
			if (envioColonia.compare("") == 0) {
				MessageBox(NULL, "Introduzca la colonia del envio para continuar", "NO ALTA", MB_ICONASTERISK);
				break;
			}
	
			//envio
			if (envioCiudad.compare("") == 0) {
				MessageBox(NULL, "Introduzca la ciudad del envio para continuar", "NO ALTA", MB_ICONASTERISK);
				break;
			}

			//estado
			if (envioEstado.compare("") == 0) {
				MessageBox(NULL, "Introduzca el estado del envio para continuar", "NO ALTA", MB_ICONASTERISK);
				break;
			}
	
			//mensaje
			if (envioMensaje.compare("") == 0) {
				MessageBox(NULL, "Introduzca el mensaje del envio para continuar", "NO ALTA", MB_ICONASTERISK);
				break;
			}

			//monto
			/*if (envioMonto.compare("") == 0) {
				MessageBox(NULL, "Agregue productos al envio para continuar", "NO ALTA", MB_ICONASTERISK);
				break;
			}*/

			//cantidad
			if (enviosCantidad.compare("") == 0) {
				MessageBox(NULL, "Agregue la cantidad para continuar", "NO ALTA", MB_ICONASTERISK);
				break;
			}else {
				bool digito = false;
				int i = 0;
				while (envioCantidadC[i]) {
					if (!isdigit(envioCantidadC[i]) && !isspace(envioCantidadC[i])) {
						MessageBox(NULL, "No introduzca letras o simbolos en la cantidad, cambie la cantidad", "NO ALTA", MB_ICONASTERISK);
						digito = true;
						break;
					}
					i++;
				}
				if (digito)
					break;
			}

			if (oEnvios != NULL) {
				bool found = true;
				while (strcmp(aEnvios->mensaje, envioMensaje.c_str()) != 0) {
					if (aEnvios->next == NULL) {
						found = false;
						break;
					}
					aEnvios = aEnvios->next;
				}
				aEnvios = oEnvios;
				if (found == true) {
					MessageBox(NULL, "Mensaje del envio no disponible, cambielo", "NO ALTA", MB_ICONASTERISK);
					aProduct = oProduct;
					break;
				}
			}

			//opcion_list = SendDlgItemMessage(hwnd, LIST_PRODUCTOS_ENVIAR, LB_GETCURSEL, 0, 0);
			//if (opcion_list != -1) {
			
			

			/*}
			else {
				MessageBox(hwnd, "No seleccionaste nada", "Aviso", MB_OK | MB_ICONERROR);
			}*/


			HWND hDtpTiempo = GetDlgItem(hwnd, DTP_ENVIOS_FECHA);
			int dtpSize = GetWindowTextLength(hDtpTiempo);
			char cadenaDelDTP[80];
			GetWindowText(hDtpTiempo, cadenaDelDTP, ++dtpSize);
			//Debuggear
			//MessageBox(NULL, cadenaDelDTP, "Fecha", MB_OK);
			string fechaDTP(cadenaDelDTP);
			//asigno la fecha al txt
			// 2 7 / 1 0 / 2 0 2 0
			// 0 1 2 3 4 5 6 7 8 9


			//strings para separar la fecha 
			/*string year = fechaDTP.substr(6, 4);
			string mon = fechaDTP.substr(3, 2);
			string day = fechaDTP.substr(0, 2);*/

			//Obtiene una seccion empezando de un indice de un string
			// 1. indice donde va a empezar el subtring
			// 2. Cantidad de caracteres a tomar en cuenta

			/*MessageBox(NULL, day.c_str(), "Day", MB_OK);
			MessageBox(NULL, mon.c_str(), "Month", MB_OK);
			MessageBox(NULL, year.c_str(), "Year", MB_OK);*/

			//strings para separar la fecha actual
/*			string yearA = AFechaDTP.substr(6, 4);
			int yearAn = stoi(yearA);
			string monA = AFechaDTP.substr(3, 2);
			int monAn = stoi(monA);
			string dayA = AFechaDTP.substr(0, 2);
			int dayAn = stoi(dayA);

			//strings para separar la fecha del envio
			string yearE = fechaDTP.substr(6, 4);
			int yearEn = stoi(yearE);
			string monE = fechaDTP.substr(3, 2);
			int monEn = stoi(monE);
			string dayE = fechaDTP.substr(0, 2);
			int dayEn = stoi(dayE);

			
			
			//while (aSend != NULL) {
			//	//empieza a ordenar
			//	string fechaDTP(aSend->fecha);
			//	//strings para separar la fecha actual
			//	string yearA = AFechaDTP.substr(6, 4);
			//	int yearAn = stoi(yearA);
			//	string monA = AFechaDTP.substr(3, 2);
			//	int monAn = stoi(monA);
			//	string dayA = AFechaDTP.substr(0, 2);
			//	int dayAn = stoi(dayA);
			//	//strings para separar la fecha del envio
			//	string yearE = fechaDTP.substr(6, 4);
			//	int yearEn = stoi(yearE);
			//	string monE = fechaDTP.substr(3, 2);
			//	int monEn = stoi(monE);
			//	string dayE = fechaDTP.substr(0, 2);
			//	int dayEn = stoi(dayE);
			//	string fechaAUX;
			//	int fechaAux;
			//	if (aSend->prev != NULL) {
			//		fechaAUX = aSend->prev->fecha;
			//		string yearAUX = fechaAUX.substr(6, 4);
			//		int yearAU = stoi(yearAUX);
			//		string monAUX = fechaAUX.substr(3, 2);
			//		int monAU = stoi(monAUX);
			//		string dayAUX = fechaAUX.substr(0, 2);
			//		int dayAU = stoi(dayAUX);
			//		if (dayAU > dayEn) {
			//		}
			//	}
			//	//permite avanzar en el while
			//	if (aSend->next == NULL) {
			//		//found = false;
			//		break;
			//	}
			//	aSend = aSend->next;
			//}
			//aSend = oSend;

			if (yearEn < yearAn) {
				MessageBox(NULL, "Introduzca una fecha posterior a hoy", "CAMBIE LA FECHA DE ENVIO", MB_ICONASTERISK | MB_TASKMODAL);
				break;
			}
			else if (yearEn > yearAn) {

			}
			else if (monEn < monAn) {
				MessageBox(NULL, "Introduzca una fecha posterior a hoy", "CAMBIE LA FECHA DE ENVIO", MB_ICONASTERISK | MB_TASKMODAL);
				break;
			}
			else if (monEn > monAn) {

			}
			else if (dayEn <= dayAn) {
				MessageBox(NULL, "Introduzca una fecha posterior a hoy", "CAMBIE LA FECHA DE ENVIO", MB_ICONASTERISK | MB_TASKMODAL);
				break;
			}
			*/
			int montoPrecio;
			if (oProduct != NULL) {
				bool found = true;
				while (strcmp(aProduct->nombre, enviosProducto.c_str()) != 0) {
					if (aProduct->next == NULL) {
						found = false;
						break;
					}
					aProduct = aProduct->next;
				}
				//aProduct = oProduct;
				if (found == true) {

					//SendDlgItemMessage(hwnd, TXT_PRODUCTO_NOMBRE_M, WM_SETTEXT, sizeof(aProduct->nombre), (LPARAM)aProduct->nombre);
					//strcpy_s(oSend->calle, aProduct->precio.c_str());
					//endDlgItemMessage(hwnd, LISTA_E_ENVIOS, LB_GETTEXT, opcion_list, (LPARAM)edit);
					
					string mm = (aProduct->precio);
					int mmm = stoi(mm);

					int mn = stoi(enviosCantidad);

					montoPrecio = mmm * mn;



					aProduct = oProduct;
					//encuentra el producto buscado y muestra los productos


					//break;
				}
				else {
					MessageBox(NULL, "Producto no encontrado, elija otro", "No existe el producto", MB_ICONASTERISK);
				}
			}
			envioMonto = to_string(montoPrecio);


			//ordena y guarda cronologicamente los envios

//			int FECHA_ENVIO = (yearEn * 10000) + (monEn * 100) + (dayEn * 1);
			/*int FECHA_ANTERIOR = 0;
			aEnvios = oEnvios;
			if (oEnvios !=NULL) {
				while (aEnvios->next != NULL) {
					aEnvios = aEnvios->next;
				}
			}
			 
			string fechaAUX;
			int fechaAux;
			if (oEnvios != NULL) {
				if (aEnvios->prev != NULL) {
					fechaAUX = aEnvios->fecha;
					string yearAUX = fechaAUX.substr(6, 4);
					int yearAU = stoi(yearAUX);
					string monAUX = fechaAUX.substr(3, 2);
					int monAU = stoi(monAUX);
					string dayAUX = fechaAUX.substr(0, 2);
					int dayAU = stoi(dayAUX);
					FECHA_ANTERIOR = (yearAU * 10000) + (monAU * 100) + (dayAU * 1);
					/*if (dayAU > dayEn) {
					}* /
				}
				else {
					fechaAUX = oEnvios->fecha;
					string yearAUX = fechaAUX.substr(6, 4);
					int yearAU = stoi(yearAUX);
					string monAUX = fechaAUX.substr(3, 2);
					int monAU = stoi(monAUX);
					string dayAUX = fechaAUX.substr(0, 2);
					int dayAU = stoi(dayAUX);
					FECHA_ANTERIOR = (yearAU * 10000) + (monAU * 100) + (dayAU * 1);
				}
			}
			aEnvios = oEnvios;

			if (FECHA_ENVIO>=FECHA_ANTERIOR) {
				//si la fecha del envio anterior es menor a la del actual haz esto*/
				if (oEnvios == NULL) {
					oEnvios = new Envios;
					//oProduct->IDUser = GLOBAL_USER_ID;
					strcpy_s(oEnvios->calle, envioCalle.c_str());
					strcpy_s(oEnvios->colonia, envioColonia.c_str());
					strcpy_s(oEnvios->ciudad, envioCiudad.c_str());
					strcpy_s(oEnvios->estado, envioEstado.c_str());
					strcpy_s(oEnvios->mensaje, envioMensaje.c_str());
					strcpy_s(oEnvios->monto, envioMonto.c_str());
					strcpy_s(oEnvios->fecha, fechaDTP.c_str());
					strcpy_s(oEnvios->producto, enviosProducto.c_str());
					strcpy_s(oEnvios->cantidad, enviosCantidad.c_str());
					strcpy_s(oEnvios->username, userAccess->username);
					strcpy_s(oEnvios->resumen, envioResumen.c_str());
					//if (opcion_list_guardar > -1) {
					//	for (int i = 0; i <= opcion_list_guardar; i++) {
					//		SendDlgItemMessage(hwnd, LIST_PRODUCTOS_ENVIAR, LB_GETTEXT, opcion_list_guardar, (LPARAM)edit);
					//		string editado = edit;
					//		oSend->producto[j][opcion_list_guardar], editado 

					//		/*for (int i = 0; edit[i]; i++)
					//			edit[i] = toupper(edit[i]);*/
					//			//SendDlgItemMessage(hwnd, LIST_PRODUCTOS_ENVIAR, LB_ADDSTRING, sizeof(edit), (LPARAM)edit);
					//			//SendDlgItemMessage(hwnd, LIST_PRODUCTOS, LB_DELETESTRING, opcion_list, (LPARAM)opcion_list);
					//		string enviosCantidad = getText(hTxtEnviosCantidad);
					//	}
					//}
					
					oEnvios->next = NULL;
					oEnvios->prev = NULL;
					aEnvios = oEnvios;
					//GLOBAL_USER_ID++;
				}
				else {
					while (aEnvios->next != NULL)
						aEnvios = aEnvios->next;
					aEnvios->next = new Envios;
					aEnvios->next->prev = aEnvios;
					aEnvios = aEnvios->next;
					//aProduct->IDUser = GLOBAL_USER_ID;
					strcpy_s(aEnvios->calle, envioCalle.c_str());
					strcpy_s(aEnvios->colonia, envioColonia.c_str());
					strcpy_s(aEnvios->ciudad, envioCiudad.c_str());
					strcpy_s(aEnvios->estado, envioEstado.c_str());
					strcpy_s(aEnvios->mensaje, envioMensaje.c_str());
					strcpy_s(aEnvios->monto, envioMonto.c_str());
					strcpy_s(aEnvios->fecha, fechaDTP.c_str());
					strcpy_s(aEnvios->producto, enviosProducto.c_str());
					strcpy_s(aEnvios->cantidad, enviosCantidad.c_str());
					strcpy_s(aEnvios->username, userAccess->username);
					strcpy_s(aEnvios->resumen, envioResumen.c_str());
					aEnvios->next = NULL;
					aEnvios = oEnvios;
					//GLOBAL_USER_ID++;
				}
			/*}
			else {
				//si la fecha del evio actual es menor a la del envio anterior haz esto
				if (oEnvios != NULL) {
					while (aEnvios->next != NULL) {
						aEnvios = aEnvios->next;
					}
					while (FECHA_ENVIO < FECHA_ANTERIOR) {
						if (aEnvios != NULL) {
							
							if (aEnvios != NULL) {
								if (aEnvios->prev != NULL) {
									fechaAUX = aEnvios->prev->fecha;
									string yearAUX = fechaAUX.substr(6, 4);
									int yearAU = stoi(yearAUX);
									string monAUX = fechaAUX.substr(3, 2);
									int monAU = stoi(monAUX);
									string dayAUX = fechaAUX.substr(0, 2);
									int dayAU = stoi(dayAUX);
									FECHA_ANTERIOR = (yearAU * 10000) + (monAU * 100) + (dayAU * 1);
									/*if (dayAU > dayEn) {
									}* /
								}
							}
							if (aEnvios->prev != NULL) {
								aEnvios = aEnvios->prev;
							}
						}
						if (aEnvios->prev==NULL) {
							break;
						}
					}
				}
				//guardar enmedio de dos envios TODO
				//aSend->auxSEND = NULL;
				if (FECHA_ENVIO>FECHA_ANTERIOR) {
					aEnvios->auxSEND = aEnvios->next;
					 
					aEnvios->next = new Envios;
					aEnvios->next->prev = aEnvios;
					aEnvios->next->auxSENDp = aEnvios->auxSEND;
					aEnvios = aEnvios->next;
					//aProduct->IDUser = GLOBAL_USER_ID;
					strcpy_s(aEnvios->calle, envioCalle.c_str());
					strcpy_s(aEnvios->colonia, envioColonia.c_str());
					strcpy_s(aEnvios->ciudad, envioCiudad.c_str());
					strcpy_s(aEnvios->estado, envioEstado.c_str());
					strcpy_s(aEnvios->mensaje, envioMensaje.c_str());
					strcpy_s(aEnvios->monto, envioMonto.c_str());
					strcpy_s(aEnvios->fecha, fechaDTP.c_str());
					strcpy_s(aEnvios->producto, enviosProducto.c_str());
					strcpy_s(aEnvios->cantidad, enviosCantidad.c_str());
					strcpy_s(aEnvios->username, userAccess->username);
					strcpy_s(aEnvios->resumen, envioResumen.c_str());
					aEnvios->next = aEnvios->prev->auxSEND;
					aEnvios->next->prev = aEnvios;
					aEnvios = oEnvios;
				}
				else if (FECHA_ENVIO < FECHA_ANTERIOR) {
					aEnvios->auxSEND = aEnvios->prev;

					aEnvios->prev = new Envios;
					aEnvios->prev->next = aEnvios;
					aEnvios->prev->auxSENDp = aEnvios->auxSEND;
					aEnvios = aEnvios->prev;
					//aProduct->IDUser = GLOBAL_USER_ID;
					strcpy_s(aEnvios->calle, envioCalle.c_str());
					strcpy_s(aEnvios->colonia, envioColonia.c_str());
					strcpy_s(aEnvios->ciudad, envioCiudad.c_str());
					strcpy_s(aEnvios->estado, envioEstado.c_str());
					strcpy_s(aEnvios->mensaje, envioMensaje.c_str());
					strcpy_s(aEnvios->monto, envioMonto.c_str());
					strcpy_s(aEnvios->fecha, fechaDTP.c_str());
					strcpy_s(aEnvios->producto, enviosProducto.c_str());
					strcpy_s(aEnvios->cantidad, enviosCantidad.c_str());
					strcpy_s(aEnvios->username, userAccess->username);
					strcpy_s(aEnvios->resumen, envioResumen.c_str());
					aEnvios->prev = aEnvios->next->auxSEND;
					oEnvios = aEnvios;
					//aSend->prev->next = aSend;
				}
				else {

					if (aEnvios->prev != NULL) {
						aEnvios = aEnvios->prev;
					}
					aEnvios->auxSEND = aEnvios->next;

					aEnvios->next = new Envios;
					aEnvios->next->prev = aEnvios;
					aEnvios->next->auxSENDp = aEnvios->auxSEND;
					aEnvios = aEnvios->next;
					//aProduct->IDUser = GLOBAL_USER_ID;
					strcpy_s(aEnvios->calle, envioCalle.c_str());
					strcpy_s(aEnvios->colonia, envioColonia.c_str());
					strcpy_s(aEnvios->ciudad, envioCiudad.c_str());
					strcpy_s(aEnvios->estado, envioEstado.c_str());
					strcpy_s(aEnvios->mensaje, envioMensaje.c_str());
					strcpy_s(aEnvios->monto, envioMonto.c_str());
					strcpy_s(aEnvios->fecha, fechaDTP.c_str());
					strcpy_s(aEnvios->producto, enviosProducto.c_str());
					strcpy_s(aEnvios->cantidad, enviosCantidad.c_str());
					strcpy_s(aEnvios->username, userAccess->username);
					strcpy_s(aEnvios->resumen, envioResumen.c_str());
					aEnvios->next = aEnvios->prev->auxSEND;
					aEnvios->next->prev = aEnvios;
					aEnvios = oEnvios;
				}

				

				//aSend = aSend->next;

				
				//MessageBox(NULL, "La fecha es menor a la del ulimo envio, cambiela a una posterior", "NO ALTA", MB_ICONASTERISK | MB_TASKMODAL);
				
				//break;

			}*/

			saveSend(aEnvios);
			//saveProduct(oProduct);
			//saveGlobalId();
			aEnvios = oEnvios;
			//freeMemoryProduct();
			HWND hEnvios = CreateDialog(hGlobalInst, MAKEINTRESOURCE(DLG_ENVIOS), NULL, (DLGPROC)fEnvios);
			ShowWindow(hEnvios, SW_SHOW);
			//hMenuOpciones = LoadMenu(hGlobalInst, MAKEINTRESOURCE(IDR_MENU1));
			//SetMenu(hProductos, hMenuOpciones);
			exitProgram = false;
			DestroyWindow(hwnd);

		}break;

		

		case BTN_ENVIOS_REGRESAR: {
			HWND hEnvios = CreateDialog(hGlobalInst, MAKEINTRESOURCE(DLG_ENVIOS), NULL, (DLGPROC)fEnvios);
			ShowWindow(hEnvios, SW_SHOW);
			/*hMenuOpciones = LoadMenu(hGlobalInst, MAKEINTRESOURCE(IDR_MENU1));
			SetMenu(hEnvios, hMenuOpciones);*/
			exitProgram = false;
			DestroyWindow(hwnd);
		}break;
		

		}
	}break;
	//case WM_TIMER: {
	//	//Funcion que nos regresa la fecha desde la generacion de LINUX
	//	time(&actualTime);
	//	//LocalTime divide en la estructura tm* una fecha que se encuentre en una variable time_t
	//	timeInfo = localtime(&actualTime);

	//	//_CRT_SECURE_NO_WARNINGS //poner en proyecto, propiedades-> c/c++ -> en el primero

	//	/*  CONVERTIR INT A CHAR
	//	char month[4];
	//	char year[4];
	//	_itoa(++timeInfo->tm_mon, month, 10);
	//	_itoa(timeInfo->tm_year, year, 10);
	//	//int To Ascii
	//	MessageBox(NULL, month, "Mes", MB_OK);
	//	MessageBox(NULL, year, "Anio", MB_OK);
	//	*/

	//	char cadenaDeFecha[80];
	//	/*
	//		1. Donde voy a depositar la fecha
	//		2. Que tanto espacio tiene la cadena de texto
	//		3. FORMATO
	//		4. De donde obtengo la fecha
	//	*/
	//	strftime(cadenaDeFecha, 80, "%d-%m-%Y     %I:%M:%S", timeInfo);
	//	HWND hlTiempo = GetDlgItem(hwnd, DTP_ENVIOS_FECHA);
	//	SetWindowText(hlTiempo, cadenaDeFecha);
	//	//String Format Time
	//	//    27 / 10 / 2020
	//	//timeInfo->tm_mon++;
	//	//timeInfo->tm_year += 1900; // 120
	//	// _CRT_SECURE_NO_WARNINGS
	//}break;
	case WM_DESTROY: {
		if (exitProgram) {
			freeMemoryUser();
			PostQuitMessage(117);
		}
	}break;
	}
	return FALSE;
}

BOOL CALLBACK fModificarEnvios(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam) {
	//strcpy(edit, aSend->mensaje);
	string abuscar = edit;
	char productABuscarC[sizeof(abuscar)];
	strcpy_s(productABuscarC, abuscar.c_str());
	switch (msg) {
	case WM_INITDIALOG: {
		
		 
		hTxtEnviosCantidad = GetDlgItem(hwnd, TXT_ENVIOS_CANTIDAD);
		hTxtEnviosCalle = GetDlgItem(hwnd, TXT_ENVIOS_CALLE);
		hTxtEnviosColonia = GetDlgItem(hwnd, TXT_ENVIOS_COLONIA);
		hTxtEnviosCiudad = GetDlgItem(hwnd, TXT_ENVIOS_CIUDAD);
		hTxtEnviosEstado = GetDlgItem(hwnd, TXT_ENVIOS_ESTADO);
		hTxtEnviosMensaje = GetDlgItem(hwnd, TXT_ENVIOS_MENSAJE);
		hTxtEnviosMonto = GetDlgItem(hwnd, TXT_ENVIOS_MONTO);
		hTxtEnviosFecha = GetDlgItem(hwnd, TXT_ENVIOS_FECHA);
		hTxtEnviosProducto = GetDlgItem(hwnd, TXT_ENVIOS_PRODUCTO);
		
		if (oProduct != NULL) {
			//bool found = true;
			while (aProduct != NULL) {//strcmp(aProduct->nombre, productName.c_str()) != 0) {
				if (strcmp(aProduct->username, userAccess->username) == 0) {
					SendDlgItemMessage(hwnd, LIST_PRODUCTOS, LB_ADDSTRING, 0, (LPARAM)aProduct->nombre);
				}
				if (aProduct->next == NULL) {
					//found = false;
					break;
				}
				aProduct = aProduct->next;
			}
			aProduct = oProduct;
			/*if (found == true) {
				MessageBox(NULL, "Nombre de producto no disponible, cambielo", "NO ALTA", MB_ICONASTERISK);
				aProduct = oProduct;
				break;
			}*/
		}

		hTxtInfoVenPersonalName = GetDlgItem(hwnd, TXT_INFOVEN_NAME);
		hTxtInfoVenAliasEmpresa = GetDlgItem(hwnd, TXT_INFOVEN_ALIAS);
		SendDlgItemMessage(hwnd, TXT_ENVIOS_VENDEDOR, WM_SETTEXT, sizeof(userAccess->personalName), (LPARAM)userAccess->personalName);
		HBITMAP hbImagenUser = (HBITMAP)LoadImage(NULL, userAccess->rutaImagenUser, IMAGE_BITMAP, 100, 100, LR_LOADFROMFILE);
		HWND hPbImagen = GetDlgItem(hwnd, PB_ENVIOS_IMAGEN);
		SendMessage(hPbImagen, STM_SETIMAGE, IMAGE_BITMAP, (LPARAM)hbImagenUser);
		////puede que aqui este el error
		if (oEnvios != NULL) {
			bool found = true;
			while (strcmp(aEnvios->mensaje, abuscar.c_str()) != 0) {
				if (aEnvios->next == NULL) {
					found = false;
					break;
				}
				aEnvios = aEnvios->next;
			}
			//aProduct = oProduct;
			if (found == true) {

				SendDlgItemMessage(hwnd, TXT_ENVIOS_CALLE, WM_SETTEXT, sizeof(aEnvios->calle), (LPARAM)aEnvios->calle);
				SendDlgItemMessage(hwnd, TXT_ENVIOS_COLONIA, WM_SETTEXT, sizeof(aEnvios->colonia), (LPARAM)aEnvios->colonia);
				SendDlgItemMessage(hwnd, TXT_ENVIOS_CIUDAD, WM_SETTEXT, sizeof(aEnvios->ciudad), (LPARAM)aEnvios->ciudad);
				SendDlgItemMessage(hwnd, TXT_ENVIOS_ESTADO, WM_SETTEXT, sizeof(aEnvios->estado), (LPARAM)aEnvios->estado);
				SendDlgItemMessage(hwnd, TXT_ENVIOS_MENSAJE, WM_SETTEXT, sizeof(aEnvios->mensaje), (LPARAM)aEnvios->mensaje);
				SendDlgItemMessage(hwnd, TXT_ENVIOS_FECHA, WM_SETTEXT, sizeof(aEnvios->fecha), (LPARAM)aEnvios->fecha);
				SendDlgItemMessage(hwnd, TXT_ENVIOS_CANTIDAD, WM_SETTEXT, sizeof(aEnvios->cantidad), (LPARAM)aEnvios->cantidad);
				SendDlgItemMessage(hwnd, TXT_ENVIOS_PRODUCTO, WM_SETTEXT, sizeof(aEnvios->producto), (LPARAM)aEnvios->producto);
				SendDlgItemMessage(hwnd, TXT_ENVIOS_MONTO, WM_SETTEXT, sizeof(aEnvios->monto), (LPARAM)aEnvios->monto);
				//producto anterior
				string aEProducto(aEnvios->producto);
				aEnvioProducto = aEProducto;


				HWND hDtpTiempo = GetDlgItem(hwnd, DTP_ENVIOS_FECHA);
				int dtpSize = GetWindowTextLength(hDtpTiempo);
				char aCadenaDelDTP[80];
				GetWindowText(hDtpTiempo, aCadenaDelDTP, ++dtpSize);
				//Debuggear
				//MessageBox(NULL, cadenaDelDTP, "Fecha", MB_OK);
				string aFechaDTP(aCadenaDelDTP);
				AFechaDTP = aFechaDTP;
				aEnvios = oEnvios;
				//encuentra el producto buscado y muestra los productos


				break;
			}
			else {
				MessageBox(NULL, "Envio no encontrado, elija otro", "No existe el producto", MB_ICONASTERISK);
			}
		}

		

	}break;
	case WM_COMMAND: {
		switch (LOWORD(wparam)) {
		case ID_ACCIONES_INFOVEN: {
			HWND hInfoVen = CreateDialog(hGlobalInst, MAKEINTRESOURCE(DLG_INFO_VEN), NULL, (DLGPROC)fInfoVendedor);
			ShowWindow(hInfoVen, SW_SHOW);
			hMenuOpciones = LoadMenu(hGlobalInst, MAKEINTRESOURCE(IDR_MENU1));
			SetMenu(hInfoVen, hMenuOpciones);
			exitProgram = false;
			DestroyWindow(hwnd);
		}break;
		case ID_ACCIONES_PRD: {
			HWND hProductos = CreateDialog(hGlobalInst, MAKEINTRESOURCE(DLG_PRODUCTOS), NULL, (DLGPROC)fProductos);
			ShowWindow(hProductos, SW_SHOW);
			hMenuOpciones = LoadMenu(hGlobalInst, MAKEINTRESOURCE(IDR_MENU1));
			SetMenu(hProductos, hMenuOpciones);
			exitProgram = false;
			DestroyWindow(hwnd);
		}break;
		case ID_ACCION_ENVIOS: {
			HWND hEnvios = CreateDialog(hGlobalInst, MAKEINTRESOURCE(DLG_ENVIOS), NULL, (DLGPROC)fEnvios);
			ShowWindow(hEnvios, SW_SHOW);
			hMenuOpciones = LoadMenu(hGlobalInst, MAKEINTRESOURCE(IDR_MENU1));
			SetMenu(hEnvios, hMenuOpciones);
			exitProgram = false;
			DestroyWindow(hwnd);
		}break;
		case ID_ACCIONES_SALIR: {
			HWND hExit = CreateDialog(hGlobalInst, MAKEINTRESOURCE(DLG_EXIT), NULL, (DLGPROC)(DLGPROC)fExit);
			ShowWindow(hExit, SW_SHOW);
		}break;
		//botones
		case BTN_ENVIOS_CREAR: {
			   
				//string envioCantidad = getText(hTxtEnviosCantidad);
				string envioCalle = getText(hTxtEnviosCalle);
				string envioColonia = getText(hTxtEnviosColonia);
				string envioCiudad = getText(hTxtEnviosCiudad);
				string envioEstado = getText(hTxtEnviosEstado);
				string envioMensaje = getText(hTxtEnviosMensaje);
				string envioFecha = getText(hTxtEnviosFecha);
				string enviosCantidad = getText(hTxtEnviosCantidad);
				string envioMonto = getText(hTxtEnviosMonto);
				string envioResumen = "Enviando";
				char envioCantidadC[sizeof(enviosCantidad)];
				strcpy_s(envioCantidadC, enviosCantidad.c_str());

				string enviosProducto = getText(hTxtEnviosProducto);
				
				//cantidad
				if (enviosCantidad.compare("") == 0) {
					MessageBox(NULL, "Agregue la cantidad para continuar", "NO ALTA", MB_ICONASTERISK);
					break;
				}
				else {
					bool digito = false;
					int i = 0;
					while (envioCantidadC[i]) {
						if (!isdigit(envioCantidadC[i]) && !isspace(envioCantidadC[i])) {
							MessageBox(NULL, "No introduzca letras o simbolos en la cantidad, cambie la cantidad", "NO ALTA", MB_ICONASTERISK);
							digito = true;
							break;
						}
						i++;
					}
					if (digito)
						break;
				}
				//calle
				if (envioCalle.compare("") == 0) {
					MessageBox(NULL, "Introduzca la calle del envio para continuar", "NO ALTA", MB_ICONASTERISK | MB_TASKMODAL);
					break;
				}

					//colonia
				if (envioColonia.compare("") == 0) {
					MessageBox(NULL, "Introduzca la colonia del envio para continuar", "NO ALTA", MB_ICONASTERISK | MB_TASKMODAL);
					break;
				}
				
				//envio
				if (envioCiudad.compare("") == 0) {
					MessageBox(NULL, "Introduzca la ciudad del envio para continuar", "NO ALTA", MB_ICONASTERISK | MB_TASKMODAL);
					break;
				}

				//estado
				if (envioEstado.compare("") == 0) {
					MessageBox(NULL, "Introduzca el estado del envio para continuar", "NO ALTA", MB_ICONASTERISK | MB_TASKMODAL);
					break;
				}
	
				//mensaje
				if (envioMensaje.compare("") == 0) {
					MessageBox(NULL, "Introduzca el mensaje del envio para continuar", "NO ALTA", MB_ICONASTERISK | MB_TASKMODAL);
					break;
				}
				//monto
				/*if (envioMonto.compare("") == 0) {
					MessageBox(NULL, "Agregue productos al envio para continuar", "NO ALTA", MB_ICONASTERISK);
					break;
				}*/

							// Do something
							const int result = MessageBox(NULL,
								"�Guardar el envio?",
								"Modificar Envio",
								MB_YESNO | MB_ICONQUESTION | MB_TASKMODAL);

							switch (result)
							{
							case IDYES: {
								//Do something
								int montoPrecio;
								if (oProduct != NULL) {
									bool found = true;
									while (strcmp(aProduct->nombre, enviosProducto.c_str()) != 0) {
										if (aProduct->next == NULL) {
											found = false;
											break;
										}
										aProduct = aProduct->next;
									}
									//aProduct = oProduct;
									if (found == true) {

										//SendDlgItemMessage(hwnd, TXT_PRODUCTO_NOMBRE_M, WM_SETTEXT, sizeof(aProduct->nombre), (LPARAM)aProduct->nombre);
										//strcpy_s(oSend->calle, aProduct->precio.c_str());
										//endDlgItemMessage(hwnd, LISTA_E_ENVIOS, LB_GETTEXT, opcion_list, (LPARAM)edit);

										string mm = (aProduct->precio);
										int mmm = stoi(mm);

										int mn = stoi(enviosCantidad);

										montoPrecio = mmm * mn;



										aProduct = oProduct;
										//encuentra el producto buscado y muestra los productos


										//break;
									}
									else {
										MessageBox(NULL, "Producto no encontrado, elija otro", "No existe el producto", MB_ICONASTERISK);
									}
								}
								envioMonto = to_string(montoPrecio);
								if (oEnvios != NULL) {
									bool found = true;
									while (strcmp(aEnvios->mensaje, productABuscarC) != 0) {
										if (aEnvios->next == NULL) {
											found = false;
											break;
										}
										aEnvios = aEnvios->next;
									}
									if (found == true) {
										strcpy_s(aEnvios->calle, envioCalle.c_str());
										strcpy_s(aEnvios->colonia, envioColonia.c_str());
										strcpy_s(aEnvios->ciudad, envioCiudad.c_str());
										strcpy_s(aEnvios->estado, envioEstado.c_str());
										strcpy_s(aEnvios->mensaje, envioMensaje.c_str());
										//strcpy_s(aSend->fecha, fechaDTP.c_str());
										strcpy_s(aEnvios->producto, enviosProducto.c_str());
										strcpy_s(aEnvios->cantidad, enviosCantidad.c_str());
										strcpy_s(aEnvios->monto, envioMonto.c_str());
										strcpy_s(aEnvios->resumen, envioResumen.c_str());
										aEnvios = oEnvios;
										//break;
									}
								}
								saveSend(aEnvios);
								//saveProduct(oProduct);
								//saveGlobalId();
								aEnvios = oEnvios;
								//freeMemoryProduct();
								HWND hEnvios = CreateDialog(hGlobalInst, MAKEINTRESOURCE(DLG_ENVIOS), NULL, (DLGPROC)(DLGPROC)fEnvios);
								ShowWindow(hEnvios, SW_SHOW);
								//hMenuOpciones = LoadMenu(hGlobalInst, MAKEINTRESOURCE(IDR_MENU1));
								//SetMenu(hProductos, hMenuOpciones);
								exitProgram = false;
								DestroyWindow(hwnd);
							}break;
							}
						


				
	
					
		}break;
	
		case BTN_ENVIOS_REGRESAR: {
				HWND hEnvios = CreateDialog(hGlobalInst, MAKEINTRESOURCE(DLG_ENVIOS), NULL, (DLGPROC)fEnvios);
				ShowWindow(hEnvios, SW_SHOW);
				/*hMenuOpciones = LoadMenu(hGlobalInst, MAKEINTRESOURCE(IDR_MENU1));
				SetMenu(hEnvios, hMenuOpciones);*/
				exitProgram = false;
				DestroyWindow(hwnd);
			}break;

		

		

		}
	}break;
	case WM_DESTROY: {
		if (exitProgram) {
			freeMemoryUser();
			PostQuitMessage(117);
		}
	}break;
	}
	return FALSE;
	//strcpy(edit, aSend->fecha);

}

BOOL CALLBACK fMostrarEnvios(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam) {
	//strcpy(edit, aSend->mensaje);
	string abuscar = edit;
	char productABuscarC[sizeof(abuscar)];
	strcpy_s(productABuscarC, abuscar.c_str());

	HWND btnAMEnvios = GetDlgItem(hwnd, BTN_ENVIOS_CREAR);

	switch (msg) {
	case WM_INITDIALOG: {


		hTxtEnviosCantidad = GetDlgItem(hwnd, TXT_ENVIOS_CANTIDAD);
		hTxtEnviosCalle = GetDlgItem(hwnd, TXT_ENVIOS_CALLE);
		hTxtEnviosColonia = GetDlgItem(hwnd, TXT_ENVIOS_COLONIA);
		hTxtEnviosCiudad = GetDlgItem(hwnd, TXT_ENVIOS_CIUDAD);
		hTxtEnviosEstado = GetDlgItem(hwnd, TXT_ENVIOS_ESTADO);
		hTxtEnviosMensaje = GetDlgItem(hwnd, TXT_ENVIOS_MENSAJE);
		hTxtEnviosMonto = GetDlgItem(hwnd, TXT_ENVIOS_MONTO);
		hTxtEnviosFecha = GetDlgItem(hwnd, TXT_ENVIOS_FECHA);
		hTxtEnviosProducto = GetDlgItem(hwnd, TXT_ENVIOS_PRODUCTO);

		EnableWindow(hTxtEnviosCantidad, FALSE);
		EnableWindow(hTxtEnviosCalle, FALSE);
		EnableWindow(hTxtEnviosColonia, FALSE);
		EnableWindow(hTxtEnviosCiudad, FALSE);
		EnableWindow(hTxtEnviosEstado, FALSE);
		EnableWindow(hTxtEnviosMensaje, FALSE);
		EnableWindow(hTxtEnviosMonto, FALSE);
		EnableWindow(hTxtEnviosFecha, FALSE);
		EnableWindow(hTxtEnviosProducto, FALSE);
		EnableWindow(btnAMEnvios, FALSE);



		if (oProduct != NULL) {
			//bool found = true;
			while (aProduct != NULL) {//strcmp(aProduct->nombre, productName.c_str()) != 0) {
				if (strcmp(aProduct->username, userAccess->username) == 0) {
					SendDlgItemMessage(hwnd, LIST_PRODUCTOS, LB_ADDSTRING, 0, (LPARAM)aProduct->nombre);
				}
				if (aProduct->next == NULL) {
					//found = false;
					break;
				}
				aProduct = aProduct->next;
			}
			aProduct = oProduct;
			/*if (found == true) {
				MessageBox(NULL, "Nombre de producto no disponible, cambielo", "NO ALTA", MB_ICONASTERISK);
				aProduct = oProduct;
				break;
			}*/
		}

		hTxtInfoVenPersonalName = GetDlgItem(hwnd, TXT_INFOVEN_NAME);
		hTxtInfoVenAliasEmpresa = GetDlgItem(hwnd, TXT_INFOVEN_ALIAS);
		SendDlgItemMessage(hwnd, TXT_ENVIOS_VENDEDOR, WM_SETTEXT, sizeof(userAccess->personalName), (LPARAM)userAccess->personalName);
		//SendDlgItemMessage(hwnd, TXT_INFOVEN_ALIAS, WM_SETTEXT, sizeof(userAccess->aliasEmpresa), (LPARAM)userAccess->aliasEmpresa);
		//SendDlgItemMessage(hwnd, TXT_INFOVEN_RUTAIMAGEN, WM_SETTEXT, sizeof(userAccess->rutaImagenUser), (LPARAM)userAccess->rutaImagenUser);
		HBITMAP hbImagenUser = (HBITMAP)LoadImage(NULL, userAccess->rutaImagenUser, IMAGE_BITMAP, 100, 100, LR_LOADFROMFILE);
		HWND hPbImagen = GetDlgItem(hwnd, PB_ENVIOS_IMAGEN);
		SendMessage(hPbImagen, STM_SETIMAGE, IMAGE_BITMAP, (LPARAM)hbImagenUser);

		if (oEnvios != NULL) {
			bool found = true;
			while (strcmp(aEnvios->mensaje, abuscar.c_str()) != 0) {
				if (aEnvios->next == NULL) {
					found = false;
					break;
				}
				aEnvios = aEnvios->next;
			}
			//aProduct = oProduct;
			if (found == true) {

				SendDlgItemMessage(hwnd, TXT_ENVIOS_CALLE, WM_SETTEXT, sizeof(aEnvios->calle), (LPARAM)aEnvios->calle);
				SendDlgItemMessage(hwnd, TXT_ENVIOS_COLONIA, WM_SETTEXT, sizeof(aEnvios->colonia), (LPARAM)aEnvios->colonia);
				SendDlgItemMessage(hwnd, TXT_ENVIOS_CIUDAD, WM_SETTEXT, sizeof(aEnvios->ciudad), (LPARAM)aEnvios->ciudad);
				SendDlgItemMessage(hwnd, TXT_ENVIOS_ESTADO, WM_SETTEXT, sizeof(aEnvios->estado), (LPARAM)aEnvios->estado);
				SendDlgItemMessage(hwnd, TXT_ENVIOS_MENSAJE, WM_SETTEXT, sizeof(aEnvios->mensaje), (LPARAM)aEnvios->mensaje);
				SendDlgItemMessage(hwnd, TXT_ENVIOS_FECHA, WM_SETTEXT, sizeof(aEnvios->fecha), (LPARAM)aEnvios->fecha);
				SendDlgItemMessage(hwnd, TXT_ENVIOS_CANTIDAD, WM_SETTEXT, sizeof(aEnvios->cantidad), (LPARAM)aEnvios->cantidad);
				SendDlgItemMessage(hwnd, TXT_ENVIOS_PRODUCTO, WM_SETTEXT, sizeof(aEnvios->producto), (LPARAM)aEnvios->producto);
				SendDlgItemMessage(hwnd, TXT_ENVIOS_MONTO, WM_SETTEXT, sizeof(aEnvios->monto), (LPARAM)aEnvios->monto);
				//producto anterior
				string aEProducto(aEnvios->producto);
				aEnvioProducto = aEProducto;


				HWND hDtpTiempo = GetDlgItem(hwnd, DTP_ENVIOS_FECHA);
				int dtpSize = GetWindowTextLength(hDtpTiempo);
				char aCadenaDelDTP[80];
				GetWindowText(hDtpTiempo, aCadenaDelDTP, ++dtpSize);
				//Debuggear
				//MessageBox(NULL, cadenaDelDTP, "Fecha", MB_OK);
				string aFechaDTP(aCadenaDelDTP);
				AFechaDTP = aFechaDTP;
				aEnvios = oEnvios;
				//encuentra el producto buscado y muestra los productos


				break;
			}
			else {
				MessageBox(NULL, "Envio no encontrado, elija otro", "No existe el producto", MB_ICONASTERISK);
			}
		}



	}break;
	case WM_COMMAND: {
		switch (LOWORD(wparam)) {
		case ID_ACCIONES_INFOVEN: {
			HWND hInfoVen = CreateDialog(hGlobalInst, MAKEINTRESOURCE(DLG_INFO_VEN), NULL, (DLGPROC)fInfoVendedor);
			ShowWindow(hInfoVen, SW_SHOW);
			hMenuOpciones = LoadMenu(hGlobalInst, MAKEINTRESOURCE(IDR_MENU1));
			SetMenu(hInfoVen, hMenuOpciones);
			exitProgram = false;
			DestroyWindow(hwnd);
		}break;
		case ID_ACCIONES_PRD: {
			HWND hProductos = CreateDialog(hGlobalInst, MAKEINTRESOURCE(DLG_PRODUCTOS), NULL, (DLGPROC)(DLGPROC)fProductos);
			ShowWindow(hProductos, SW_SHOW);
			hMenuOpciones = LoadMenu(hGlobalInst, MAKEINTRESOURCE(IDR_MENU1));
			SetMenu(hProductos, hMenuOpciones);
			exitProgram = false;
			DestroyWindow(hwnd);
		}break;
		case ID_ACCION_ENVIOS: {
			HWND hEnvios = CreateDialog(hGlobalInst, MAKEINTRESOURCE(DLG_ENVIOS), NULL, (DLGPROC)(DLGPROC)fEnvios);
			ShowWindow(hEnvios, SW_SHOW);
			hMenuOpciones = LoadMenu(hGlobalInst, MAKEINTRESOURCE(IDR_MENU1));
			SetMenu(hEnvios, hMenuOpciones);
			exitProgram = false;
			DestroyWindow(hwnd);
		}break;
		case ID_ACCIONES_SALIR: {
			HWND hExit = CreateDialog(hGlobalInst, MAKEINTRESOURCE(DLG_EXIT), NULL, (DLGPROC)(DLGPROC)fExit);
			ShowWindow(hExit, SW_SHOW);
		}break;
			//botones


		case BTN_ENVIOS_REGRESAR: {
			HWND hEnvios = CreateDialog(hGlobalInst, MAKEINTRESOURCE(DLG_ENVIOS), NULL, (DLGPROC)(DLGPROC)fEnvios);
			ShowWindow(hEnvios, SW_SHOW);
			/*hMenuOpciones = LoadMenu(hGlobalInst, MAKEINTRESOURCE(IDR_MENU1));
			SetMenu(hEnvios, hMenuOpciones);*/
			exitProgram = false;
			DestroyWindow(hwnd);
		}break;





		}
	}break;
	case WM_DESTROY: {
		if (exitProgram) {
			freeMemoryUser();
			PostQuitMessage(117);
		}
	}break;
	}
	return FALSE;
	//strcpy(edit, aSend->fecha);

}

BOOL CALLBACK fProductos(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam) {
	switch (msg) {
	case WM_INITDIALOG: {

		hTxtInfoVenPersonalName = GetDlgItem(hwnd, TXT_INFOVEN_NAME);
		hTxtInfoVenAliasEmpresa = GetDlgItem(hwnd, TXT_INFOVEN_ALIAS);
		SendDlgItemMessage(hwnd, TXT_ENVIOS_VENDEDOR, WM_SETTEXT, sizeof(userAccess->personalName), (LPARAM)userAccess->personalName);
		//SendDlgItemMessage(hwnd, TXT_INFOVEN_ALIAS, WM_SETTEXT, sizeof(userAccess->aliasEmpresa), (LPARAM)userAccess->aliasEmpresa);
		//SendDlgItemMessage(hwnd, TXT_INFOVEN_RUTAIMAGEN, WM_SETTEXT, sizeof(userAccess->rutaImagenUser), (LPARAM)userAccess->rutaImagenUser);
		HBITMAP hbImagenUser = (HBITMAP)LoadImage(NULL, userAccess->rutaImagenUser, IMAGE_BITMAP, 100, 100, LR_LOADFROMFILE);
		HWND hPbImagen = GetDlgItem(hwnd, PB_ENVIOS_IMAGEN);
		SendMessage(hPbImagen, STM_SETIMAGE, IMAGE_BITMAP, (LPARAM)hbImagenUser);

		//desplegar productos existentes
		/*SendDlgItemMessage(hwnd, LIST_PRODUCTOS, LB_ADDSTRING, 0, (LPARAM)oProduct->nombre);
		for (int i = 0; i < 2; i++) {
			SendDlgItemMessage(hwnd, LIST_PRODUCTOS, LB_ADDSTRING, 0, (LPARAM)aProduct->nombre);
		}*/

		if (oProduct != NULL) {
			//bool found = true;
			while (aProduct != NULL){//strcmp(aProduct->nombre, productName.c_str()) != 0) {

				if (strcmp(aProduct->username, userAccess->username) == 0) {
					SendDlgItemMessage(hwnd, LIST_PRODUCTOS, LB_ADDSTRING, 0, (LPARAM)aProduct->nombre);
				}

				
				if (aProduct->next == NULL) {
					//found = false;
					break;
				}
				aProduct = aProduct->next;
			}
			aProduct = oProduct;
			/*if (found == true) {
				MessageBox(NULL, "Nombre de producto no disponible, cambielo", "NO ALTA", MB_ICONASTERISK);
				aProduct = oProduct;
				break;
			}*/
		}

	}break;
	case WM_COMMAND: {
		switch (LOWORD(wparam)) {
		case ID_ACCIONES_INFOVEN: {
			HWND hInfoVen = CreateDialog(hGlobalInst, MAKEINTRESOURCE(DLG_INFO_VEN), NULL, (DLGPROC)(DLGPROC)fInfoVendedor);
			ShowWindow(hInfoVen, SW_SHOW);
			hMenuOpciones = LoadMenu(hGlobalInst, MAKEINTRESOURCE(IDR_MENU1));
			SetMenu(hInfoVen, hMenuOpciones);
			exitProgram = false;
			DestroyWindow(hwnd);
		}break;
		case ID_ACCIONES_PRD: {
			HWND hProductos = CreateDialog(hGlobalInst, MAKEINTRESOURCE(DLG_PRODUCTOS), NULL, (DLGPROC)(DLGPROC)fProductos);
			ShowWindow(hProductos, SW_SHOW);
			hMenuOpciones = LoadMenu(hGlobalInst, MAKEINTRESOURCE(IDR_MENU1));
			SetMenu(hProductos, hMenuOpciones);
			exitProgram = false;
			DestroyWindow(hwnd);
		}break;
		case ID_ACCION_ENVIOS: {
			HWND hEnvios = CreateDialog(hGlobalInst, MAKEINTRESOURCE(DLG_ENVIOS), NULL, (DLGPROC)(DLGPROC)fEnvios);
			ShowWindow(hEnvios, SW_SHOW);
			hMenuOpciones = LoadMenu(hGlobalInst, MAKEINTRESOURCE(IDR_MENU1));
			SetMenu(hEnvios, hMenuOpciones);
			exitProgram = false;
			DestroyWindow(hwnd);
		}break;
		case ID_ACCIONES_SALIR: {
			HWND hExit = CreateDialog(hGlobalInst, MAKEINTRESOURCE(DLG_EXIT), NULL, (DLGPROC)(DLGPROC)fExit);
			ShowWindow(hExit, SW_SHOW);
		}break;
		case BTN_P_NUEVO: {
			HWND hExit = CreateDialog(hGlobalInst, MAKEINTRESOURCE(DLG_ALTA_PRODUCTOS1), NULL, (DLGPROC)fAltaProductos);
			ShowWindow(hExit, SW_SHOW);
			exitProgram = false;
			DestroyWindow(hwnd);
		}break;

		case BTN_P_MODIFICAR: {
			opcion_list = SendDlgItemMessage(hwnd, LIST_PRODUCTOS, LB_GETCURSEL, 0, 0);
			if (opcion_list != -1) {
				SendDlgItemMessage(hwnd, LIST_PRODUCTOS, LB_GETTEXT, opcion_list, (LPARAM)edit);
				HWND hModificarProductos = CreateDialog(hGlobalInst, MAKEINTRESOURCE(DLG_MODIFICAR_PRODUCTOS), NULL, (DLGPROC)fModificarProductos);
				ShowWindow(hModificarProductos, SW_SHOW);
				exitProgram = false;
				DestroyWindow(hwnd);
				//for (int i = 0; edit[i]; i++)
				//	edit[i] = toupper(edit[i]);
				////SendDlgItemMessage(hDlg, IDC_LIST1, LB_DELETESTRING, opcion_list, (LPARAM)opcion_list);
			}
			else {
				MessageBox(hwnd, "No seleccionaste nada, selecciona un producto para modicarlo", "No seleccionaste nada", MB_OK | MB_ICONERROR);
			}
		}break;

		case BTN_PMOSTRAR: {
			opcion_list = SendDlgItemMessage(hwnd, LIST_PRODUCTOS, LB_GETCURSEL, 0, 0);
			if (opcion_list != -1) {
				SendDlgItemMessage(hwnd, LIST_PRODUCTOS, LB_GETTEXT, opcion_list, (LPARAM)edit);
				HWND hMostrarProductos = CreateDialog(hGlobalInst, MAKEINTRESOURCE(DLG_MODIFICAR_PRODUCTOS), NULL, (DLGPROC)fMostrarProductos);
				ShowWindow(hMostrarProductos, SW_SHOW);
				exitProgram = false;
				DestroyWindow(hwnd);
				//for (int i = 0; edit[i]; i++)
				//	edit[i] = toupper(edit[i]);
				////SendDlgItemMessage(hDlg, IDC_LIST1, LB_DELETESTRING, opcion_list, (LPARAM)opcion_list);
			}
			else {
				MessageBox(hwnd, "No seleccionaste nada, selecciona un producto para modicarlo", "No seleccionaste nada", MB_OK | MB_ICONERROR);
			}
		}break;
			 
		case BTN_P_ELIMINAR: {

			opcion_list = SendDlgItemMessage(hwnd, LIST_PRODUCTOS, LB_GETCURSEL, 0, 0);
			if (opcion_list != -1) {
				SendDlgItemMessage(hwnd, LIST_PRODUCTOS, LB_GETTEXT, opcion_list, (LPARAM)edit);
				string abuscar = edit;

				if (oProduct != NULL) {
					bool found = true;
					while (strcmp(aProduct->nombre, abuscar.c_str()) != 0) {
						if (aProduct->next == NULL) {
							found = false;
							break;
						}
						aProduct = aProduct->next;
					}
					//aProduct = oProduct;
					if (found == true) {

						//elimina si  el producto no est� en un envio no enviado

						bool noEncontrado = false;
						if (oEnvios == NULL) {
						}
						else {
							aEnvios = oEnvios;
							while (aEnvios != NULL) {
								if (strcmp(aEnvios->producto, aProduct->nombre) == 0) {

									if (strcmp(aEnvios->resumen, "Enviando") == 0) {
										MessageBox(NULL, "El producto se encuentra en un envio aun no enviado", "NO BAJA", MB_ICONASTERISK | MB_TASKMODAL);
										aProduct = oProduct;
										aEnvios = oEnvios;
										noEncontrado = false;
										break;
									}
									else {
										if (aProduct->prev == NULL && aProduct->next == NULL) { //El unico

											delete aProduct; //Borramos el unico elemento
											aProduct = oProduct = NULL; //Regresamos todo a NULL para que se cumpla el primer if de ALTA

										}
										else if (aProduct->prev == NULL) { //Primero
											oProduct = oProduct->next; //Movemos origen al siguiente elemento que ahora se convertira en el nuevo origen
											oProduct->prev = NULL; //El previo de este nuevo origen es null para indicarnos que es el primer elemento
											delete aProduct; //Borramos aux
											aProduct = oProduct; //Lo regresamos al nuevo origen
										}
										else if (aProduct->next == NULL) { //Ultimo
											aProduct->prev->next = NULL; // De aux (Ultimo) viajo a prev (Elemento anterior) y su sig lo apunto a NULL para indicar que ese es el nuevo ultimo elemento
											delete aProduct; //Borro aux
											aProduct = oProduct; //Lo regresamos a origen
										}
										else { //Cualquier otro
											//Santiago->sig = Carlos ?
											aProduct->prev->next = aProduct->next;
											//Carlos->prev = Santiago ?
											aProduct->next->prev = aProduct->prev;
											delete aProduct;
											aProduct = oProduct;
										}
										if (aEnvios->prev == NULL && aEnvios->next == NULL) { //El unico

											delete aEnvios; //Borramos el unico elemento
											aEnvios = oEnvios = NULL; //Regresamos todo a NULL para que se cumpla el primer if de ALTA

										}
										else if (aEnvios->prev == NULL) { //Primero
											oEnvios = oEnvios->next; //Movemos origen al siguiente elemento que ahora se convertira en el nuevo origen
											oEnvios->prev = NULL; //El previo de este nuevo origen es null para indicarnos que es el primer elemento
											delete aEnvios; //Borramos aux
											aEnvios = oEnvios; //Lo regresamos al nuevo origen
										}
										else if (aEnvios->next == NULL) { //Ultimo
											aEnvios->prev->next = NULL; // De aux (Ultimo) viajo a prev (Elemento anterior) y su sig lo apunto a NULL para indicar que ese es el nuevo ultimo elemento
											delete aEnvios; //Borro aux
											aEnvios = oEnvios; //Lo regresamos a origen
										}
										else { //Cualquier otro
											//Santiago->sig = Carlos ?
											aEnvios->prev->next = aEnvios->next;
											//Carlos->prev = Santiago ?
											aEnvios->next->prev = aEnvios->prev;
											delete aEnvios;
											aEnvios = oEnvios;
										}
										MessageBox(NULL, "El producto se ha eliminado correctamente", "BAJA DE PRODUCTO", MB_ICONASTERISK | MB_TASKMODAL);
										saveProduct(aProduct);
										saveSend(aEnvios);
										aProduct = oProduct;
										noEncontrado = false;
										aEnvios = oEnvios;
										HWND hProductos = CreateDialog(hGlobalInst, MAKEINTRESOURCE(DLG_PRODUCTOS), NULL, (DLGPROC)fProductos);
										ShowWindow(hProductos, SW_SHOW);
										/*hMenuOpciones = LoadMenu(hGlobalInst, MAKEINTRESOURCE(IDR_MENU1));
										SetMenu(hProductos, hMenuOpciones);*/
										exitProgram = false;
										DestroyWindow(hwnd);
										break;
									}

									//SendDlgItemMessage(hwnd, LB_ENV_ENVIOS, LB_ADDSTRING, 0, (LPARAM)aEnv->productName);
								}
								else if(strcmp(aEnvios->producto, aProduct->nombre) != 0){
									noEncontrado = true;
								}
								aEnvios= aEnvios->next;
							}
						}

						if (noEncontrado) {
							if (aProduct->prev == NULL && aProduct->next == NULL) { //El unico

								delete aProduct; //Borramos el unico elemento
								aProduct = oProduct = NULL; //Regresamos todo a NULL para que se cumpla el primer if de ALTA

							}
							else if (aProduct->prev == NULL) { //Primero
								oProduct = oProduct->next; //Movemos origen al siguiente elemento que ahora se convertira en el nuevo origen
								oProduct->prev = NULL; //El previo de este nuevo origen es null para indicarnos que es el primer elemento
								delete aProduct; //Borramos aux
								aProduct = oProduct; //Lo regresamos al nuevo origen
							}
							else if (aProduct->next == NULL) { //Ultimo
								aProduct->prev->next = NULL; // De aux (Ultimo) viajo a prev (Elemento anterior) y su sig lo apunto a NULL para indicar que ese es el nuevo ultimo elemento
								delete aProduct; //Borro aux
								aProduct = oProduct; //Lo regresamos a origen
							}
							else { //Cualquier otro
								//Santiago->sig = Carlos ?
								aProduct->prev->next = aProduct->next;
								//Carlos->prev = Santiago ?
								aProduct->next->prev = aProduct->prev;
								delete aProduct;
								aProduct = oProduct;
							}
							MessageBox(NULL, "El producto se ha eliminado correctamente", "BAJA DE PRODUCTO", MB_ICONASTERISK | MB_TASKMODAL);
							saveProduct(aProduct);
							aProduct = oProduct;
							aEnvios = oEnvios;
							HWND hProductos = CreateDialog(hGlobalInst, MAKEINTRESOURCE(DLG_PRODUCTOS), NULL, (DLGPROC)(DLGPROC)fProductos);
							ShowWindow(hProductos, SW_SHOW);
							hMenuOpciones = LoadMenu(hGlobalInst, MAKEINTRESOURCE(IDR_MENU1));
							SetMenu(hProductos, hMenuOpciones);
							exitProgram = false;
							DestroyWindow(hwnd);
							break;

						}


						

							
						
						//termina de eliminar
						
						
						//encuentra el producto buscado y muestra los productos


						//break;
					}
					else {
						MessageBox(NULL, "Producto no encontrado, elija otro", "No existe el producto", MB_ICONASTERISK | MB_TASKMODAL);
					}
				}
				
				HWND hProductos = CreateDialog(hGlobalInst, MAKEINTRESOURCE(DLG_PRODUCTOS), NULL, (DLGPROC)(DLGPROC)fProductos);
				ShowWindow(hProductos, SW_SHOW);
				/*hMenuOpciones = LoadMenu(hGlobalInst, MAKEINTRESOURCE(IDR_MENU1));
				SetMenu(hProductos, hMenuOpciones);*/
				exitProgram = false;
				DestroyWindow(hwnd);

				
				//if (aux->prev == NULL && aux->sig == NULL) { //El unico
				//	delete aux; //Borramos el unico elemento
				//	aux = origen = NULL; //Regresamos todo a NULL para que se cumpla el primer if de ALTA
				//}
				//else if (aux->prev == NULL) { //Primero
				//	origen = origen->sig; //Movemos origen al siguiente elemento que ahora se convertira en el nuevo origen
				//	origen->prev = NULL; //El previo de este nuevo origen es null para indicarnos que es el primer elemento
				//	delete aux; //Borramos aux
				//	aux = origen; //Lo regresamos al nuevo origen
				//}
				//else if (aux->sig == NULL) { //Ultimo
				//	aux->prev->sig = NULL; // De aux (Ultimo) viajo a prev (Elemento anterior) y su sig lo apunto a NULL para indicar que ese es el nuevo ultimo elemento
				//	delete aux; //Borro aux
				//	aux = origen; //Lo regresamos a origen
				//}
				//else { //Cualquier otro
				//	//Santiago->sig = Carlos ?
				//	aux->prev->sig = aux->sig;
				//	//Carlos->prev = Santiago ?
				//	aux->sig->prev = aux->prev;
				//	delete aux;
				//	aux = origen;
				//}

				//HWND hModificarProductos = CreateDialog(hGlobalInst, MAKEINTRESOURCE(DLG_MODIFICAR_PRODUCTOS), NULL, fModificarProductos);
				//ShowWindow(hModificarProductos, SW_SHOW);
				//exitProgram = false;
				//DestroyWindow(hwnd);
				////for (int i = 0; edit[i]; i++)
				//	edit[i] = toupper(edit[i]);
				////SendDlgItemMessage(hDlg, IDC_LIST1, LB_DELETESTRING, opcion_list, (LPARAM)opcion_list);
			}
			else {
				MessageBox(hwnd, "No seleccionaste nada, selecciona un producto para eliminarlo", "No seleccionaste nada", MB_OK | MB_ICONERROR);
				break;
			}
			
		}

		}
	}break;
	case WM_DESTROY: {
		if (exitProgram) {
			freeMemoryUser();
			PostQuitMessage(117);
		}
	}break;
	}
	return FALSE;

}

BOOL CALLBACK fAltaProductos(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam) {

	string imagenProduct1 = "";
	string imagenProduct2 = "";
	switch (msg) {

	case WM_INITDIALOG: {

		hTxtProductNombre = GetDlgItem(hwnd, TXT_PRODUCTO_NOMBRE);
		hTxtProductMarca = GetDlgItem(hwnd, TXT_PRODUCTO_MARCA);
		hTxtProductCantidad = GetDlgItem(hwnd, TXT_PRODUCTO_CANTIDAD);
		hTxtProductCodigo = GetDlgItem(hwnd, TXT_PRODUCTO_CODIGO);
		hTxtProductPrecio = GetDlgItem(hwnd, TXT_PRODUCTO_PRECIO);
		hTxtProductDescripcion = GetDlgItem(hwnd, TXT_PRODUCTO_DESCRIPCION);
		hTxtProductIma1 = GetDlgItem(hwnd, TXT_PRODUCTO_IMAGEN1);
		hTxtProductIma2 = GetDlgItem(hwnd, TXT_PRODUCTO_IMAGEN2);

		hTxtInfoVenPersonalName = GetDlgItem(hwnd, TXT_INFOVEN_NAME);
		hTxtInfoVenAliasEmpresa = GetDlgItem(hwnd, TXT_INFOVEN_ALIAS);
		SendDlgItemMessage(hwnd, TXT_ENVIOS_VENDEDOR, WM_SETTEXT, sizeof(userAccess->personalName), (LPARAM)userAccess->personalName);
		//SendDlgItemMessage(hwnd, TXT_INFOVEN_ALIAS, WM_SETTEXT, sizeof(userAccess->aliasEmpresa), (LPARAM)userAccess->aliasEmpresa);
		//SendDlgItemMessage(hwnd, TXT_INFOVEN_RUTAIMAGEN, WM_SETTEXT, sizeof(userAccess->rutaImagenUser), (LPARAM)userAccess->rutaImagenUser);
		HBITMAP hbImagenUser = (HBITMAP)LoadImage(NULL, userAccess->rutaImagenUser, IMAGE_BITMAP, 100, 100, LR_LOADFROMFILE);
		HWND hPbImagen = GetDlgItem(hwnd, PB_ENVIOS_IMAGEN);
		SendMessage(hPbImagen, STM_SETIMAGE, IMAGE_BITMAP, (LPARAM)hbImagenUser);

		
	}break;
	case WM_COMMAND: {
		switch (LOWORD(wparam)) {
		case ID_ACCIONES_INFOVEN: {
			HWND hInfoVen = CreateDialog(hGlobalInst, MAKEINTRESOURCE(DLG_INFO_VEN), NULL, (DLGPROC)(DLGPROC)fInfoVendedor);
			ShowWindow(hInfoVen, SW_SHOW);
			hMenuOpciones = LoadMenu(hGlobalInst, MAKEINTRESOURCE(IDR_MENU1));
			SetMenu(hInfoVen, hMenuOpciones);
			exitProgram = false;
			DestroyWindow(hwnd);
		}break;
		case ID_ACCIONES_PRD: {
			HWND hProductos = CreateDialog(hGlobalInst, MAKEINTRESOURCE(DLG_PRODUCTOS), NULL, (DLGPROC)(DLGPROC)fProductos);
			ShowWindow(hProductos, SW_SHOW);
			hMenuOpciones = LoadMenu(hGlobalInst, MAKEINTRESOURCE(IDR_MENU1));
			SetMenu(hProductos, hMenuOpciones);
			exitProgram = false;
			DestroyWindow(hwnd);
		}break;
		case ID_ACCION_ENVIOS: {
			HWND hEnvios = CreateDialog(hGlobalInst, MAKEINTRESOURCE(DLG_ENVIOS), NULL, (DLGPROC)(DLGPROC)fEnvios);
			ShowWindow(hEnvios, SW_SHOW);
			hMenuOpciones = LoadMenu(hGlobalInst, MAKEINTRESOURCE(IDR_MENU1));
			SetMenu(hEnvios, hMenuOpciones);
			exitProgram = false;
			DestroyWindow(hwnd);
		}break;
		case ID_ACCIONES_SALIR: {
			HWND hExit = CreateDialog(hGlobalInst, MAKEINTRESOURCE(DLG_EXIT), NULL, (DLGPROC)(DLGPROC)fExit);
			ShowWindow(hExit, SW_SHOW);
		}break;
		case BTN_PRODUCTOS_GUARDAR: {


			string productName = getText(hTxtProductNombre);
			string productCantidad = getText(hTxtProductCantidad);
			string productMarca = getText(hTxtProductMarca);
			string productCodigo = getText(hTxtProductCodigo);
			string productPrecio = getText(hTxtProductPrecio);
			string productDescrip = getText(hTxtProductDescripcion);
			string proim1 = getText(hTxtProductIma1);
			string proim2 = getText(hTxtProductIma2);
			//string productImagen1 = getT
			char productCantidadC[sizeof(productCantidad)];
			strcpy_s(productCantidadC, productCantidad.c_str());
			char productCodigoC[sizeof(productCodigo)];
			strcpy_s(productCodigoC, productCodigo.c_str());
			char productPrecioC[sizeof(productPrecio)];
			strcpy_s(productPrecioC, productPrecio.c_str());

			//nombre
			if (productName.compare("") == 0) {
				MessageBox(NULL, "Introduzca el nombre del producto para continuar", "NO ALTA", MB_ICONASTERISK);
				break;
			}
			if (oProduct != NULL) {
				bool found = true;
				while (strcmp(aProduct->nombre, productName.c_str()) != 0) {
					if (aProduct->next == NULL) {
						found = false;
						break;
					}
					aProduct = aProduct->next;
				}
				aProduct = oProduct;
				if (found == true) {
					MessageBox(NULL, "Nombre de producto no disponible, cambielo", "NO ALTA", MB_ICONASTERISK);
					aProduct = oProduct;
					break;
				}
			}
			//cantidad
			if (productCantidad.compare("") == 0) {
				MessageBox(NULL, "Introduzca la cantidad en inventario para continuar", "NO ALTA", MB_ICONASTERISK);
				break;
			}
			else {
				bool digito = false;
				int i = 0;
				while (productCantidadC[i]) {
					if (!isdigit(productCantidadC[i]) && !isspace(productCantidadC[i])) {
						MessageBox(NULL, "No introduzca letras o simbolos en la cantidad, cambie la cantidad", "NO ALTA", MB_ICONASTERISK);
						digito = true;
						break;
					}
					i++;
				}
				if (digito)
					break;
			}
			//codigo
			if (productCodigo.compare("") == 0) {
				MessageBox(NULL, "Introduzca el codigo del producto para continuar", "NO ALTA", MB_ICONASTERISK);
				break;
			}
			else {
				bool digito = false;
				int i = 0;
				while (productCodigoC[i]) {
					if (!isdigit(productCodigoC[i]) && !isspace(productCodigoC[i])) {
						MessageBox(NULL, "No introduzca letras o simbolos en el codigo, cambie el codigo", "NO ALTA", MB_ICONASTERISK);
						digito = true;
						break;
					}
					i++;
				}
				if (digito)
					break;
			}
			//precio
			if (productPrecio.compare("") == 0) {
				MessageBox(NULL, "Introduzca el precio del producto para continuar", "NO ALTA", MB_ICONASTERISK);
				break;
			}
			else {
				bool digito = false;
				int i = 0;
				while (productPrecioC[i]) {
					if (!isdigit(productPrecioC[i]) && !isspace(productPrecioC[i])) {
						MessageBox(NULL, "No introduzca letras o simbolos en el precio, cambie el precio", "NO ALTA", MB_ICONASTERISK);
						digito = true;
						break;
					}
					i++;
				}
				if (digito)
					break;
			}
			//marca
			if (productMarca.compare("") == 0) {
				MessageBox(NULL, "Introduzca la marca del producto para continuar", "NO ALTA", MB_ICONASTERISK);
				break;
			}
			//descripcion
			if (productDescrip.compare("") == 0) {
				MessageBox(NULL, "Introduzca la descripcion del producto para continuar", "NO ALTA", MB_ICONASTERISK);
				break;
			}
			//imagen 1
			if (proim1.compare("") == 0) {
				MessageBox(NULL, "Seleccione 2 im�genes para continuar", "NO ALTA", MB_ICONASTERISK);
				break;
			}
			//imagen 2
			if (proim2.compare("") == 0) {
				MessageBox(NULL, "Falta seleccionar 1 imagen para continuar", "NO ALTA", MB_ICONASTERISK);
				break;
			}



			//strcpy_s(uProduct->nombre, productName.c_str());

			if (oProduct != NULL) {
				bool found = true;
				while (strcmp(aProduct->nombre, productName.c_str()) != 0) {
					if (aProduct->next == NULL) {
						found = false;
						break;
					}
					aProduct = aProduct->next;
				}
				aProduct = oProduct;
				if (found == true) {
					MessageBox(NULL, "Nombre de producto no disponible, cambielo", "NO ALTA", MB_ICONASTERISK);
					aProduct = oProduct;
					break;
				}
			}

			if (oProduct == NULL) {
				oProduct = new Product;
				//oProduct->IDUser = GLOBAL_USER_ID;
				strcpy_s(oProduct->nombre, productName.c_str());
				strcpy_s(oProduct->cantidad, productCantidad.c_str());
				strcpy_s(oProduct->marca, productMarca.c_str());
				strcpy_s(oProduct->codigo, productCodigo.c_str());
				strcpy_s(oProduct->precio, productPrecio.c_str());
				strcpy_s(oProduct->descripcion, productDescrip.c_str());
				strcpy_s(oProduct->imaruta1, proim1.c_str());
				strcpy_s(oProduct->imaruta2, proim2.c_str());
				strcpy_s(oProduct->username, userAccess->username);
				oProduct->next = NULL;
				oProduct->prev = NULL;
				aProduct = oProduct;
				//GLOBAL_USER_ID++;
			}
			else {
				while (aProduct->next != NULL)
					aProduct = aProduct->next;
				aProduct->next = new Product;
				aProduct->next->prev = aProduct;
				aProduct = aProduct->next;
				//aProduct->IDUser = GLOBAL_USER_ID;
				strcpy_s(aProduct->nombre, productName.c_str());
				strcpy_s(aProduct->cantidad, productCantidad.c_str());
				strcpy_s(aProduct->marca, productMarca.c_str());
				strcpy_s(aProduct->codigo, productCodigo.c_str());
				strcpy_s(aProduct->precio, productPrecio.c_str());
				strcpy_s(aProduct->descripcion, productDescrip.c_str());
				strcpy_s(aProduct->imaruta1, proim1.c_str());
				strcpy_s(aProduct->imaruta2, proim2.c_str());
				strcpy_s(aProduct->username, userAccess->username);
				aProduct->next = NULL;
				aProduct = oProduct;
				//GLOBAL_USER_ID++;
			}
			//saveProduct(aProduct);
			saveProduct(oProduct);
			//saveGlobalId();
			aProduct = oProduct;
			//freeMemoryProduct();
			HWND hProductos = CreateDialog(hGlobalInst, MAKEINTRESOURCE(DLG_PRODUCTOS), NULL, (DLGPROC)(DLGPROC)fProductos);
			ShowWindow(hProductos, SW_SHOW);
			//hMenuOpciones = LoadMenu(hGlobalInst, MAKEINTRESOURCE(IDR_MENU1));
			//SetMenu(hProductos, hMenuOpciones);
			exitProgram = false;
			DestroyWindow(hwnd);

		} break;

		case BTN_PRODUCTOS_IMAGEN: {
			
			OPENFILENAME ofn; //Explorador de archivos
			ZeroMemory(&ofn, sizeof(OPENFILENAME));
			char rutaImagen[MAX_PATH] = ""; //Almacenara la ruta del archivo

			ofn.hwndOwner = hwnd; //Ventana padre del ofn
			ofn.lStructSize = sizeof(OPENFILENAME); // Tamanio total del ofn
			ofn.lpstrFile = rutaImagen; // DOnde almacenara la ruta del archivo
			ofn.nMaxFile = MAX_PATH; //Limite de caracteres en la ruta, en caso de exceder no abre el archivo
			ofn.lpstrDefExt = "txt"; //En caso de que el archivo no tenga extension, adjuntar esta
			ofn.Flags = OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_HIDEREADONLY;
			ofn.lpstrFilter = "Imagenes bmp\0*.bmp\0";

			if (GetOpenFileName(&ofn)) { //TRUE si selecciono un archivo, FALSE si le dio cancelar
				HBITMAP hbImagenUser = (HBITMAP)LoadImage(NULL, rutaImagen, IMAGE_BITMAP, 100, 100, LR_LOADFROMFILE);

				if (pasa) {
					HWND hPbImagen = GetDlgItem(hwnd, PB_PRODUCTOS_IMG1);
					pasa = false;
					for (int i = 0; i < sizeof(rutaImagen); i++) {
						imagenProduct1 += rutaImagen[i];
					}
					SendMessage(hPbImagen, STM_SETIMAGE, IMAGE_BITMAP, (LPARAM)hbImagenUser);
					SendDlgItemMessage(hwnd, TXT_PRODUCTO_IMAGEN1, WM_SETTEXT, sizeof(imagenProduct1), (LPARAM)imagenProduct1.c_str());
					/*string rutaImage;
					rutaImage.append(imagenProduct);
					strcpy_s(userAccess->rutaImagenUser, rutaImage.c_str());*/
					
				}
				else {
					HWND hPbImagen = GetDlgItem(hwnd, PB_PRODUCTOS_IMG2);
					pasa = true;
					for (int i = 0; i < sizeof(rutaImagen); i++) {
						imagenProduct2 += rutaImagen[i];
					}
					SendMessage(hPbImagen, STM_SETIMAGE, IMAGE_BITMAP, (LPARAM)hbImagenUser);
					SendDlgItemMessage(hwnd, TXT_PRODUCTO_IMAGEN2, WM_SETTEXT, sizeof(imagenProduct2), (LPARAM)imagenProduct2.c_str());
					
				}
				
				
				
				//SendDlgItemMessage(hwnd, TXT_INFOVEN_RUTAIMAGEN, WM_SETTEXT, sizeof(imagenProduct), (LPARAM)imagenProduct.c_str());
				//MessageBox(NULL, rutaImagen, "NO REGISTRO INFORMACION", MB_ICONASTERISK);
			}

		}break;

		case BTN_PRODUCTOS_BACK: {
			HWND hProductos = CreateDialog(hGlobalInst, MAKEINTRESOURCE(DLG_PRODUCTOS), NULL, (DLGPROC)(DLGPROC)fProductos);
			ShowWindow(hProductos, SW_SHOW);
			//hMenuOpciones = LoadMenu(hGlobalInst, MAKEINTRESOURCE(IDR_MENU1));
			//SetMenu(hProductos, hMenuOpciones);
			exitProgram = false;
			DestroyWindow(hwnd);
			
		}
		}
	}break;
	case WM_DESTROY: {
		if (exitProgram) {
			freeMemoryUser();
			PostQuitMessage(117);
		}
	}break;
	}
	return FALSE;

}

BOOL CALLBACK fModificarProductos(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam) {
	string imagenProduct1 = "";
	string imagenProduct2 = "";

	string abuscar = edit;
	char productABuscarC[sizeof(abuscar)];
	strcpy_s(productABuscarC, abuscar.c_str());
	switch (msg) {
	case WM_INITDIALOG: {
		//TODO


		hTxtProductNombre = GetDlgItem(hwnd, TXT_PRODUCTO_NOMBRE_M);
		hTxtProductMarca = GetDlgItem(hwnd, TXT_PRODUCTO_MARCA);
		hTxtProductCantidad = GetDlgItem(hwnd, TXT_PRODUCTO_CANTIDAD);
		hTxtProductCodigo = GetDlgItem(hwnd, TXT_PRODUCTO_CODIGO);
		hTxtProductPrecio = GetDlgItem(hwnd, TXT_PRODUCTO_PRECIO);
		hTxtProductDescripcion = GetDlgItem(hwnd, TXT_PRODUCTO_DESCRIPCION);
		hTxtProductIma1 = GetDlgItem(hwnd, TXT_PRODUCTO_IMAGEN1);
		hTxtProductIma2 = GetDlgItem(hwnd, TXT_PRODUCTO_IMAGEN2);

		hTxtInfoVenPersonalName = GetDlgItem(hwnd, TXT_INFOVEN_NAME);
		hTxtInfoVenAliasEmpresa = GetDlgItem(hwnd, TXT_INFOVEN_ALIAS);
		SendDlgItemMessage(hwnd, TXT_ENVIOS_VENDEDOR, WM_SETTEXT, sizeof(userAccess->personalName), (LPARAM)userAccess->personalName);
		//SendDlgItemMessage(hwnd, TXT_INFOVEN_ALIAS, WM_SETTEXT, sizeof(userAccess->aliasEmpresa), (LPARAM)userAccess->aliasEmpresa);
		//SendDlgItemMessage(hwnd, TXT_INFOVEN_RUTAIMAGEN, WM_SETTEXT, sizeof(userAccess->rutaImagenUser), (LPARAM)userAccess->rutaImagenUser);
		HBITMAP hbImagenUser = (HBITMAP)LoadImage(NULL, userAccess->rutaImagenUser, IMAGE_BITMAP, 100, 100, LR_LOADFROMFILE);
		HWND hPbImagen = GetDlgItem(hwnd, PB_ENVIOS_IMAGEN);
		SendMessage(hPbImagen, STM_SETIMAGE, IMAGE_BITMAP, (LPARAM)hbImagenUser);

		 
		if (oProduct != NULL) {
			bool found = true;
			while (strcmp(aProduct->nombre, abuscar.c_str()) != 0) {
				if (aProduct->next == NULL) {
					found = false;
					break;
				}
				aProduct = aProduct->next;
			}
			//aProduct = oProduct;
			if (found == true) {

				SendDlgItemMessage(hwnd, TXT_PRODUCTO_NOMBRE_M, WM_SETTEXT, sizeof(aProduct->nombre), (LPARAM)aProduct->nombre);
				SendDlgItemMessage(hwnd, TXT_PRODUCTO_MARCA, WM_SETTEXT, sizeof(aProduct->marca), (LPARAM)aProduct->marca);
				SendDlgItemMessage(hwnd, TXT_PRODUCTO_CANTIDAD, WM_SETTEXT, sizeof(aProduct->cantidad), (LPARAM)aProduct->cantidad);
				SendDlgItemMessage(hwnd, TXT_PRODUCTO_CODIGO, WM_SETTEXT, sizeof(aProduct->codigo), (LPARAM)aProduct->codigo);
				SendDlgItemMessage(hwnd, TXT_PRODUCTO_PRECIO, WM_SETTEXT, sizeof(aProduct->precio), (LPARAM)aProduct->precio);
				SendDlgItemMessage(hwnd, TXT_PRODUCTO_DESCRIPCION, WM_SETTEXT, sizeof(aProduct->descripcion), (LPARAM)aProduct->descripcion);

				SendDlgItemMessage(hwnd, TXT_PRODUCTO_IMAGEN1, WM_SETTEXT, sizeof(aProduct->imaruta1), (LPARAM)aProduct->imaruta1);
				HBITMAP hbImagenUser = (HBITMAP)LoadImage(NULL, aProduct->imaruta1, IMAGE_BITMAP, 100, 100, LR_LOADFROMFILE);
				HWND hPbImagen = GetDlgItem(hwnd, PB_PRODUCTOS_IMG1);
				SendMessage(hPbImagen, STM_SETIMAGE, IMAGE_BITMAP, (LPARAM)hbImagenUser);

				SendDlgItemMessage(hwnd, TXT_PRODUCTO_IMAGEN2, WM_SETTEXT, sizeof(aProduct->imaruta2), (LPARAM)aProduct->imaruta2);
				HBITMAP hbImagenUser2 = (HBITMAP)LoadImage(NULL, aProduct->imaruta2, IMAGE_BITMAP, 100, 100, LR_LOADFROMFILE);
				HWND hPbImagen2 = GetDlgItem(hwnd, PB_PRODUCTOS_IMG2);
				SendMessage(hPbImagen2, STM_SETIMAGE, IMAGE_BITMAP, (LPARAM)hbImagenUser2);
				//SendDlgItemMessage(hwnd, TXT_PRODUCTO_NOMBRE, WM_SETTEXT, sizeof(aProduct->nombre), (LPARAM)aProduct->nombre);

				aProduct = oProduct;
				//encuentra el producto buscado y muestra los productos
				

				break;
			}
			else {
				MessageBox(NULL, "Producto no encontrado, elija otro", "No existe el producto", MB_ICONASTERISK);
			}
		}

	}break;
	case WM_COMMAND: {
		
		switch (LOWORD(wparam)) {
		case ID_ACCIONES_INFOVEN: {
			HWND hInfoVen = CreateDialog(hGlobalInst, MAKEINTRESOURCE(DLG_INFO_VEN), NULL, (DLGPROC)(DLGPROC)fInfoVendedor);
			ShowWindow(hInfoVen, SW_SHOW);
			hMenuOpciones = LoadMenu(hGlobalInst, MAKEINTRESOURCE(IDR_MENU1));
			SetMenu(hInfoVen, hMenuOpciones);
			exitProgram = false;
			DestroyWindow(hwnd);
		}break;
		case ID_ACCIONES_PRD: {
			HWND hProductos = CreateDialog(hGlobalInst, MAKEINTRESOURCE(DLG_PRODUCTOS), NULL, (DLGPROC)(DLGPROC)fProductos);
			ShowWindow(hProductos, SW_SHOW);
			hMenuOpciones = LoadMenu(hGlobalInst, MAKEINTRESOURCE(IDR_MENU1));
			SetMenu(hProductos, hMenuOpciones);
			exitProgram = false;
			DestroyWindow(hwnd);
		}break;
		case ID_ACCION_ENVIOS: {
			HWND hEnvios = CreateDialog(hGlobalInst, MAKEINTRESOURCE(DLG_ENVIOS), NULL, (DLGPROC)(DLGPROC)fEnvios);
			ShowWindow(hEnvios, SW_SHOW);
			hMenuOpciones = LoadMenu(hGlobalInst, MAKEINTRESOURCE(IDR_MENU1));
			SetMenu(hEnvios, hMenuOpciones);
			exitProgram = false;
			DestroyWindow(hwnd);
		}break;
		case ID_ACCIONES_SALIR: {
			HWND hExit = CreateDialog(hGlobalInst, MAKEINTRESOURCE(DLG_EXIT), NULL, (DLGPROC)(DLGPROC)fExit);
			ShowWindow(hExit, SW_SHOW);
		}break;

		case BTN_PRODUCTOS_GUARDAR: {


			string productName = getText(hTxtProductNombre);
			string productCantidad = getText(hTxtProductCantidad);
			string productMarca = getText(hTxtProductMarca);
			string productCodigo = getText(hTxtProductCodigo);
			string productPrecio = getText(hTxtProductPrecio);
			string productDescrip = getText(hTxtProductDescripcion);
			string proim1 = getText(hTxtProductIma1);
			string proim2 = getText(hTxtProductIma2);
			//string productImagen1 = getT
			char productCantidadC[sizeof(productCantidad)];
			strcpy_s(productCantidadC, productCantidad.c_str());
			char productCodigoC[sizeof(productCodigo)];
			strcpy_s(productCodigoC, productCodigo.c_str());
			char productPrecioC[sizeof(productPrecio)];
			strcpy_s(productPrecioC, productPrecio.c_str());

			char productNameC[sizeof(productName)];
			strcpy_s(productNameC, productName.c_str());

			//nombre
			if (productName.compare("") == 0) {
				MessageBox(NULL, "Introduzca el nombre del producto para continuar", "NO ALTA", MB_ICONASTERISK);
				break;
			}

			if (productName.compare(productABuscarC) == 0 ) {
				//MessageBox(NULL, "S�", "ALTA", MB_ICONASTERISK);
				
				//break;
			}
			else {
				if (oProduct != NULL) {
					bool found = true;
					while (strcmp(aProduct->nombre, productName.c_str()) != 0) {
						if (aProduct->next == NULL) {
							found = false;
							break;
						}
						aProduct = aProduct->next;
					}
					aProduct = oProduct;
					if (found == true) {
						MessageBox(NULL, "Nombre de producto no disponible, cambielo", "NO ALTA", MB_ICONASTERISK);
						aProduct = oProduct;
						break;
					}
				}
			}

			
			//cantidad
			if (productCantidad.compare("") == 0) {
				MessageBox(NULL, "Introduzca la cantidad en inventario para continuar", "NO ALTA", MB_ICONASTERISK);
				break;
			}
			else {
				bool digito = false;
				int i = 0;
				while (productCantidadC[i]) {
					if (!isdigit(productCantidadC[i]) && !isspace(productCantidadC[i])) {
						MessageBox(NULL, "No introduzca letras o simbolos en la cantidad, cambie la cantidad", "NO ALTA", MB_ICONASTERISK);
						digito = true;
						break;
					}
					i++;
				}
				if (digito)
					break;
			}
			//codigo
			if (productCodigo.compare("") == 0) {
				MessageBox(NULL, "Introduzca el codigo del producto para continuar", "NO ALTA", MB_ICONASTERISK);
				break;
			}
			else {
				bool digito = false;
				int i = 0;
				while (productCodigoC[i]) {
					if (!isdigit(productCodigoC[i]) && !isspace(productCodigoC[i])) {
						MessageBox(NULL, "No introduzca letras o simbolos en el codigo, cambie el codigo", "NO ALTA", MB_ICONASTERISK);
						digito = true;
						break;
					}
					i++;
				}
				if (digito)
					break;
			}
			//precio
			if (productPrecio.compare("") == 0) {
				MessageBox(NULL, "Introduzca el precio del producto para continuar", "NO ALTA", MB_ICONASTERISK);
				break;
			}
			else {
				bool digito = false;
				int i = 0;
				while (productPrecioC[i]) {
					if (!isdigit(productPrecioC[i]) && !isspace(productPrecioC[i])) {
						MessageBox(NULL, "No introduzca letras o simbolos en el precio, cambie el precio", "NO ALTA", MB_ICONASTERISK);
						digito = true;
						break;
					}
					i++;
				}
				if (digito)
					break;
			}
			//marca
			if (productMarca.compare("") == 0) {
				MessageBox(NULL, "Introduzca la marca del producto para continuar", "NO ALTA", MB_ICONASTERISK);
				break;
			}
			//descripcion
			if (productDescrip.compare("") == 0) {
				MessageBox(NULL, "Introduzca la descripcion del producto para continuar", "NO ALTA", MB_ICONASTERISK);
				break;
			}
			//imagen 1
			if (proim1.compare("") == 0) {
				MessageBox(NULL, "Seleccione 2 im�genes para continuar", "NO ALTA", MB_ICONASTERISK);
				break;
			}
			//imagen 2
			if (proim2.compare("") == 0) {
				MessageBox(NULL, "Falta seleccionar 1 imagen para continuar", "NO ALTA", MB_ICONASTERISK);
				break;
			}
			
				if (oProduct != NULL) {
					bool found = true;
					while (strcmp(aProduct->nombre, productABuscarC) != 0) {
						if (aProduct->next == NULL) {
							found = false;
							break;
						}
						aProduct = aProduct->next;
					}
					if (found == true) {
						strcpy_s(aProduct->nombre, productName.c_str());
						strcpy_s(aProduct->cantidad, productCantidad.c_str());
						strcpy_s(aProduct->marca, productMarca.c_str());
						strcpy_s(aProduct->codigo, productCodigo.c_str());
						strcpy_s(aProduct->precio, productPrecio.c_str());
						strcpy_s(aProduct->descripcion, productDescrip.c_str());
						strcpy_s(aProduct->imaruta1, proim1.c_str());
						strcpy_s(aProduct->imaruta2, proim2.c_str());
						aProduct = oProduct;
						//break;
					}
				}
			
	
			saveProduct(aProduct);
			//saveGlobalId();
			aProduct = oProduct;
			//freeMemoryProduct();
			HWND hProductos = CreateDialog(hGlobalInst, MAKEINTRESOURCE(DLG_PRODUCTOS), NULL, (DLGPROC)(DLGPROC)fProductos);
			ShowWindow(hProductos, SW_SHOW);
			//hMenuOpciones = LoadMenu(hGlobalInst, MAKEINTRESOURCE(IDR_MENU1));
			//SetMenu(hProductos, hMenuOpciones);
			exitProgram = false;
			DestroyWindow(hwnd);

		} break;

		case BTN_PRODUCTOS_IMAGEN: {

			OPENFILENAME ofn; //Explorador de archivos
			ZeroMemory(&ofn, sizeof(OPENFILENAME));
			char rutaImagen[MAX_PATH] = ""; //Almacenara la ruta del archivo

			ofn.hwndOwner = hwnd; //Ventana padre del ofn
			ofn.lStructSize = sizeof(OPENFILENAME); // Tamanio total del ofn
			ofn.lpstrFile = rutaImagen; // DOnde almacenara la ruta del archivo
			ofn.nMaxFile = MAX_PATH; //Limite de caracteres en la ruta, en caso de exceder no abre el archivo
			ofn.lpstrDefExt = "txt"; //En caso de que el archivo no tenga extension, adjuntar esta
			ofn.Flags = OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_HIDEREADONLY;
			ofn.lpstrFilter = "Imagenes bmp\0*.bmp\0";

			if (GetOpenFileName(&ofn)) { //TRUE si selecciono un archivo, FALSE si le dio cancelar
				HBITMAP hbImagenUser = (HBITMAP)LoadImage(NULL, rutaImagen, IMAGE_BITMAP, 100, 100, LR_LOADFROMFILE);

				if (pasa) {
					HWND hPbImagen = GetDlgItem(hwnd, PB_PRODUCTOS_IMG1);
					pasa = false;
					for (int i = 0; i < sizeof(rutaImagen); i++) {
						imagenProduct1 += rutaImagen[i];
					}
					SendMessage(hPbImagen, STM_SETIMAGE, IMAGE_BITMAP, (LPARAM)hbImagenUser);
					SendDlgItemMessage(hwnd, TXT_PRODUCTO_IMAGEN1, WM_SETTEXT, sizeof(imagenProduct1), (LPARAM)imagenProduct1.c_str());
					/*string rutaImage;
					rutaImage.append(imagenProduct);
					strcpy_s(userAccess->rutaImagenUser, rutaImage.c_str());*/

				}
				else {
					HWND hPbImagen = GetDlgItem(hwnd, PB_PRODUCTOS_IMG2);
					pasa = true;
					for (int i = 0; i < sizeof(rutaImagen); i++) {
						imagenProduct2 += rutaImagen[i];
					}
					SendMessage(hPbImagen, STM_SETIMAGE, IMAGE_BITMAP, (LPARAM)hbImagenUser);
					SendDlgItemMessage(hwnd, TXT_PRODUCTO_IMAGEN2, WM_SETTEXT, sizeof(imagenProduct2), (LPARAM)imagenProduct2.c_str());

				}



				//SendDlgItemMessage(hwnd, TXT_INFOVEN_RUTAIMAGEN, WM_SETTEXT, sizeof(imagenProduct), (LPARAM)imagenProduct.c_str());
				//MessageBox(NULL, rutaImagen, "NO REGISTRO INFORMACION", MB_ICONASTERISK);
			}

		}break;

		case BTN_PRODUCTOS_BACK: {
			HWND hProductos = CreateDialog(hGlobalInst, MAKEINTRESOURCE(DLG_PRODUCTOS), NULL, (DLGPROC)(DLGPROC)fProductos);
			ShowWindow(hProductos, SW_SHOW);
			//hMenuOpciones = LoadMenu(hGlobalInst, MAKEINTRESOURCE(IDR_MENU1));
			//SetMenu(hProductos, hMenuOpciones);
			exitProgram = false;
			DestroyWindow(hwnd);

		}

		}
	}break;
	case WM_DESTROY: {
		if (exitProgram) {
			freeMemoryUser();
			PostQuitMessage(117);
		}
	}break;
	}
	return FALSE;


}

BOOL CALLBACK fMostrarProductos(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam) {
	string imagenProduct1 = "";
	string imagenProduct2 = "";

	string abuscar = edit;
	char productABuscarC[sizeof(abuscar)];
	strcpy_s(productABuscarC, abuscar.c_str());

	HWND btnGMProd = GetDlgItem(hwnd, BTN_PRODUCTOS_GUARDAR);
	HWND btnIMProd = GetDlgItem(hwnd, BTN_PRODUCTOS_IMAGEN);

	switch (msg) {
	case WM_INITDIALOG: {
		//TODO


		hTxtProductNombre = GetDlgItem(hwnd, TXT_PRODUCTO_NOMBRE_M);
		hTxtProductMarca = GetDlgItem(hwnd, TXT_PRODUCTO_MARCA);
		hTxtProductCantidad = GetDlgItem(hwnd, TXT_PRODUCTO_CANTIDAD);
		hTxtProductCodigo = GetDlgItem(hwnd, TXT_PRODUCTO_CODIGO);
		hTxtProductPrecio = GetDlgItem(hwnd, TXT_PRODUCTO_PRECIO);
		hTxtProductDescripcion = GetDlgItem(hwnd, TXT_PRODUCTO_DESCRIPCION);
		hTxtProductIma1 = GetDlgItem(hwnd, TXT_PRODUCTO_IMAGEN1);
		hTxtProductIma2 = GetDlgItem(hwnd, TXT_PRODUCTO_IMAGEN2);

		hTxtInfoVenPersonalName = GetDlgItem(hwnd, TXT_INFOVEN_NAME);
		hTxtInfoVenAliasEmpresa = GetDlgItem(hwnd, TXT_INFOVEN_ALIAS);

		EnableWindow(hTxtProductNombre, FALSE);
		EnableWindow(hTxtProductMarca, FALSE);
		EnableWindow(hTxtProductCantidad, FALSE);
		EnableWindow(hTxtProductCodigo, FALSE);
		EnableWindow(hTxtProductPrecio, FALSE);
		EnableWindow(hTxtProductDescripcion, FALSE);
		EnableWindow(hTxtProductIma1, FALSE);
		EnableWindow(hTxtProductIma2, FALSE);
		EnableWindow(hTxtEnviosProducto, FALSE);
		EnableWindow(btnGMProd, FALSE);
		EnableWindow(btnIMProd, FALSE);




		SendDlgItemMessage(hwnd, TXT_ENVIOS_VENDEDOR, WM_SETTEXT, sizeof(userAccess->personalName), (LPARAM)userAccess->personalName);
		//SendDlgItemMessage(hwnd, TXT_INFOVEN_ALIAS, WM_SETTEXT, sizeof(userAccess->aliasEmpresa), (LPARAM)userAccess->aliasEmpresa);
		//SendDlgItemMessage(hwnd, TXT_INFOVEN_RUTAIMAGEN, WM_SETTEXT, sizeof(userAccess->rutaImagenUser), (LPARAM)userAccess->rutaImagenUser);
		HBITMAP hbImagenUser = (HBITMAP)LoadImage(NULL, userAccess->rutaImagenUser, IMAGE_BITMAP, 100, 100, LR_LOADFROMFILE);
		HWND hPbImagen = GetDlgItem(hwnd, PB_ENVIOS_IMAGEN);
		SendMessage(hPbImagen, STM_SETIMAGE, IMAGE_BITMAP, (LPARAM)hbImagenUser);


		if (oProduct != NULL) {
			bool found = true;
			while (strcmp(aProduct->nombre, abuscar.c_str()) != 0) {
				if (aProduct->next == NULL) {
					found = false;
					break;
				}
				aProduct = aProduct->next;
			}
			//aProduct = oProduct;
			if (found == true) {

				SendDlgItemMessage(hwnd, TXT_PRODUCTO_NOMBRE_M, WM_SETTEXT, sizeof(aProduct->nombre), (LPARAM)aProduct->nombre);
				SendDlgItemMessage(hwnd, TXT_PRODUCTO_MARCA, WM_SETTEXT, sizeof(aProduct->marca), (LPARAM)aProduct->marca);
				SendDlgItemMessage(hwnd, TXT_PRODUCTO_CANTIDAD, WM_SETTEXT, sizeof(aProduct->cantidad), (LPARAM)aProduct->cantidad);
				SendDlgItemMessage(hwnd, TXT_PRODUCTO_CODIGO, WM_SETTEXT, sizeof(aProduct->codigo), (LPARAM)aProduct->codigo);
				SendDlgItemMessage(hwnd, TXT_PRODUCTO_PRECIO, WM_SETTEXT, sizeof(aProduct->precio), (LPARAM)aProduct->precio);
				SendDlgItemMessage(hwnd, TXT_PRODUCTO_DESCRIPCION, WM_SETTEXT, sizeof(aProduct->descripcion), (LPARAM)aProduct->descripcion);

				SendDlgItemMessage(hwnd, TXT_PRODUCTO_IMAGEN1, WM_SETTEXT, sizeof(aProduct->imaruta1), (LPARAM)aProduct->imaruta1);
				HBITMAP hbImagenUser = (HBITMAP)LoadImage(NULL, aProduct->imaruta1, IMAGE_BITMAP, 100, 100, LR_LOADFROMFILE);
				HWND hPbImagen = GetDlgItem(hwnd, PB_PRODUCTOS_IMG1);
				SendMessage(hPbImagen, STM_SETIMAGE, IMAGE_BITMAP, (LPARAM)hbImagenUser);

				SendDlgItemMessage(hwnd, TXT_PRODUCTO_IMAGEN2, WM_SETTEXT, sizeof(aProduct->imaruta2), (LPARAM)aProduct->imaruta2);
				HBITMAP hbImagenUser2 = (HBITMAP)LoadImage(NULL, aProduct->imaruta2, IMAGE_BITMAP, 100, 100, LR_LOADFROMFILE);
				HWND hPbImagen2 = GetDlgItem(hwnd, PB_PRODUCTOS_IMG2);
				SendMessage(hPbImagen2, STM_SETIMAGE, IMAGE_BITMAP, (LPARAM)hbImagenUser2);
				//SendDlgItemMessage(hwnd, TXT_PRODUCTO_NOMBRE, WM_SETTEXT, sizeof(aProduct->nombre), (LPARAM)aProduct->nombre);

				aProduct = oProduct;
				//encuentra el producto buscado y muestra los productos


				break;
			}
			else {
				MessageBox(NULL, "Producto no encontrado, elija otro", "No existe el producto", MB_ICONASTERISK);
			}
		}

	}break;
	case WM_COMMAND: {

		switch (LOWORD(wparam)) {
		case ID_ACCIONES_INFOVEN: {
			HWND hInfoVen = CreateDialog(hGlobalInst, MAKEINTRESOURCE(DLG_INFO_VEN), NULL, (DLGPROC)(DLGPROC)fInfoVendedor);
			ShowWindow(hInfoVen, SW_SHOW);
			hMenuOpciones = LoadMenu(hGlobalInst, MAKEINTRESOURCE(IDR_MENU1));
			SetMenu(hInfoVen, hMenuOpciones);
			exitProgram = false;
			DestroyWindow(hwnd);
		}break;
		case ID_ACCIONES_PRD: {
			HWND hProductos = CreateDialog(hGlobalInst, MAKEINTRESOURCE(DLG_PRODUCTOS), NULL, (DLGPROC)(DLGPROC)fProductos);
			ShowWindow(hProductos, SW_SHOW);
			hMenuOpciones = LoadMenu(hGlobalInst, MAKEINTRESOURCE(IDR_MENU1));
			SetMenu(hProductos, hMenuOpciones);
			exitProgram = false;
			DestroyWindow(hwnd);
		}break;
		case ID_ACCION_ENVIOS: {
			HWND hEnvios = CreateDialog(hGlobalInst, MAKEINTRESOURCE(DLG_ENVIOS), NULL, (DLGPROC)(DLGPROC)fEnvios);
			ShowWindow(hEnvios, SW_SHOW);
			hMenuOpciones = LoadMenu(hGlobalInst, MAKEINTRESOURCE(IDR_MENU1));
			SetMenu(hEnvios, hMenuOpciones);
			exitProgram = false;
			DestroyWindow(hwnd);
		}break;
		case ID_ACCIONES_SALIR: {
			HWND hExit = CreateDialog(hGlobalInst, MAKEINTRESOURCE(DLG_EXIT), NULL, (DLGPROC)(DLGPROC)fExit);
			ShowWindow(hExit, SW_SHOW);
		}break;

		

		case BTN_PRODUCTOS_BACK: {
			HWND hProductos = CreateDialog(hGlobalInst, MAKEINTRESOURCE(DLG_PRODUCTOS), NULL, (DLGPROC)(DLGPROC)fProductos);
			ShowWindow(hProductos, SW_SHOW);
			//hMenuOpciones = LoadMenu(hGlobalInst, MAKEINTRESOURCE(IDR_MENU1));
			//SetMenu(hProductos, hMenuOpciones);
			exitProgram = false;
			DestroyWindow(hwnd);

		}

		}
	}break;
	case WM_DESTROY: {
		if (exitProgram) {
			freeMemoryUser();
			PostQuitMessage(117);
		}
	}break;
	}
	
	
	
	
	return FALSE;
}


//Ventana de confirmacion de salida
BOOL CALLBACK fExit(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam) {
	switch (msg) {
	case WM_COMMAND: {
		switch (LOWORD(wparam)) {
		case BTN_EXIT_EXIT:
			saveSend(oEnvios);
			saveProduct(oProduct);
			save(oUser);
			saveGlobalId();
			EndDialog(hwnd, 14);
			exitProgram = true;
			DestroyWindow(hwnd);
			break;
		case BTN_EXIT_CANCEL:
			EndDialog(hwnd, 15);
			exitProgram = false;
			break;
		}
	case WM_DESTROY: {
		if (exitProgram) {
			freeMemoryUser();
			freeMemoryProduct();
			PostQuitMessage(117);
		}
	}break;
	}break;
	}
	return FALSE;
}

string getText(HWND hwnd) {
	//Obtener la longitud del texto de la ventana donde queremos obtener el texto.
	int length = GetWindowTextLength(hwnd);
	if (length < 1)
		return "";
	char cText[70];
	GetWindowText(hwnd, cText, ++length);
	string sText(cText);
	return sText;
}

void getGlobalId() {
	lectorEscritor.open("C:\\Users\\User\\source\\repos\\Demo\\winapo\\GlobalId.txt", ios::in);
	if (lectorEscritor.is_open()) {
		lectorEscritor >> GLOBAL_USER_ID;
		lectorEscritor.close();
		MessageBox(NULL, "Captura de GlobalId exitoso", "CAPTURA", MB_ICONASTERISK | MB_TASKMODAL);
		return;
	}
	else {
		MessageBox(NULL, "No se pudo abrir el archivo de GlobalId", "NO CAPTURA", MB_ICONASTERISK | MB_TASKMODAL);
		return;
	}
}

void saveGlobalId() {
	lectorEscritor.open("C:\\Users\\User\\source\\repos\\Demo\\winapo\\GlobalId.txt", ios::out | ios::trunc);
	if (lectorEscritor.is_open()) {
		lectorEscritor << GLOBAL_USER_ID;
		lectorEscritor.close();
		MessageBox(NULL, "Guardado de GlobalId exitoso", "GUARDAR", MB_ICONASTERISK | MB_TASKMODAL);
		return;
	}
	else {
		MessageBox(NULL, "No se pudo abrir el archivo de GlobalId", "NO GUARDAR", MB_ICONASTERISK | MB_TASKMODAL);
		return;
	}
}

void save(User* pOrigen) {
	lectorEscritor.open("C:\\Users\\User\\source\\repos\\Demo\\winapo\\Usuario.bin", ios::out | ios::trunc | ios::binary);
	if (lectorEscritor.is_open()) {

		while (pOrigen != NULL) {
			lectorEscritor.write(reinterpret_cast<char*>(pOrigen), sizeof(User));
			pOrigen = pOrigen->next;
		}
		lectorEscritor.close();
		MessageBox(NULL, "Guardado de usuarios exitoso", "GUARDAR", MB_ICONASTERISK | MB_TASKMODAL);
		return;
	}
	else {
		MessageBox(NULL, "No se pudo abrir el archivo de usuarios", "NO GUARDAR", MB_ICONASTERISK | MB_TASKMODAL);
		return;
	}
}

void loadUser() {
	lectorEscritor.open("C:\\Users\\User\\source\\repos\\Demo\\winapo\\Usuario.bin", ios::binary | ios::in | ios::ate);
	if (lectorEscritor.is_open()) {
		int totalCharactersUsers = lectorEscritor.tellg();
		if (totalCharactersUsers < 1) {
			MessageBox(NULL, "Archivo de usuarios no encontrado, se creara una nuevo", "NO CARGA", MB_ICONASTERISK | MB_TASKMODAL);
			return;
		}
		for (int i = 0; i < totalCharactersUsers / sizeof(User); i++) {
			if (oUser == NULL) {
				User* temp = new User;
				oUser = new User;
				lectorEscritor.seekg(i * sizeof(User));
				lectorEscritor.read(reinterpret_cast<char*>(temp), sizeof(User));
				oUser->IDUser = temp->IDUser;
				strcpy_s(oUser->username, temp->username);
				strcpy_s(oUser->password, temp->password);
				strcpy_s(oUser->personalName, temp->personalName);
				strcpy_s(oUser->aliasEmpresa, temp->aliasEmpresa);
				strcpy_s(oUser->rutaImagenUser, temp->rutaImagenUser);
				oUser->next = NULL;
				oUser->prev = NULL;
				aUser = oUser;
				delete reinterpret_cast<char*>(temp);
				continue;
			}
			else {
				while (aUser->next != NULL) {
					aUser = aUser->next;
				}
				User* temp = new User;
				aUser->next = new User;
				lectorEscritor.seekg(i * sizeof(User));
				lectorEscritor.read(reinterpret_cast<char*>(temp), sizeof(User));
				aUser->next->prev = aUser;
				aUser = aUser->next;
				aUser->IDUser = temp->IDUser;
				strcpy_s(aUser->username, temp->username);
				strcpy_s(aUser->password, temp->password);
				strcpy_s(aUser->personalName, temp->personalName);
				strcpy_s(aUser->aliasEmpresa, temp->aliasEmpresa);
				strcpy_s(aUser->rutaImagenUser, temp->rutaImagenUser);
				aUser->next = NULL;
				aUser = oUser;
				delete reinterpret_cast<char*>(temp);
				continue;
			}
		}
		lectorEscritor.close();
		MessageBox(NULL, "Carga exitosa", "CARGAR", MB_ICONASTERISK | MB_TASKMODAL);
		return;
	}
	else {
		MessageBox(NULL, "No se pudo abrir el archivo Usuarios", "NO CARGAR", MB_ICONASTERISK | MB_TASKMODAL);
		return;
	}
}

void freeMemoryUser() {
	if (oUser != NULL) { //Revisar el origen es null ? NO, liberamos la memoria
		while (aUser != NULL) { //Mientras aux NO sea NULL ? avanzamos
			User* temp = aUser; //Guardamos en un temporal aux
			aUser = aUser->next; //Avanzamos
			delete temp; //Borramos el temporal
		}
	}
	else //Origen si fue null, no hacemos nada
		return;
	aUser = oUser = NULL;
}

void saveProduct(Product* pOrigen) {
	lectorEscritor.open("C:\\Users\\User\\source\\repos\\Demo\\winapo\\Productos.bin", ios::out | ios::trunc | ios::binary);
	if (lectorEscritor.is_open()) {

		while (pOrigen != NULL) {
			lectorEscritor.write(reinterpret_cast<char*>(pOrigen), sizeof(Product));
			pOrigen = pOrigen->next;
		}
		lectorEscritor.close();
		MessageBox(NULL, "Guardado de productos exitoso", "GUARDAR", MB_ICONASTERISK | MB_TASKMODAL);
		return;
	}
	else {
		MessageBox(NULL, "No se pudo abrir el archivo de productos", "NO GUARDAR", MB_ICONASTERISK | MB_TASKMODAL);
		return;
	}
}

void loadProduct() {
	lectorEscritor.open("C:\\Users\\User\\source\\repos\\Demo\\winapo\\Productos.bin", ios::binary | ios::in | ios::ate);
	if (lectorEscritor.is_open()) {
		int totalCharactersUsers = lectorEscritor.tellg();
		if (totalCharactersUsers < 1) {
			MessageBox(NULL, "Archivo de productos no encontrado, se creara una nuevo", "NO CARGA", MB_ICONASTERISK | MB_TASKMODAL);
			return;
		}
		for (int i = 0; i < totalCharactersUsers / sizeof(Product); i++) {
			if (oProduct == NULL) {
				Product* temp = new Product;
				oProduct = new Product;
				lectorEscritor.seekg(i * sizeof(Product));
				lectorEscritor.read(reinterpret_cast<char*>(temp), sizeof(Product));
				oProduct->IDUser = temp->IDUser;
				strcpy_s(oProduct->nombre, temp->nombre);
				strcpy_s(oProduct->cantidad, temp->cantidad);
				strcpy_s(oProduct->marca, temp->marca);
				strcpy_s(oProduct->codigo, temp->codigo);
				strcpy_s(oProduct->precio, temp->precio);
				strcpy_s(oProduct->descripcion, temp->descripcion);
				strcpy_s(oProduct->imaruta1, temp->imaruta1);
				strcpy_s(oProduct->imaruta2, temp->imaruta2);
				strcpy_s(oProduct->username, temp->username);
				oProduct->next = NULL;
				oProduct->prev = NULL;
				aProduct = oProduct;
				delete reinterpret_cast<char*>(temp);
				continue;
			}
			else {
				while (aProduct->next != NULL) {
					aProduct = aProduct->next;
				}
				Product* temp = new Product;
				aProduct->next = new Product;
				lectorEscritor.seekg(i * sizeof(Product));
				lectorEscritor.read(reinterpret_cast<char*>(temp), sizeof(Product));
				aProduct->next->prev = aProduct;
				aProduct = aProduct->next;
				aProduct->IDUser = temp->IDUser;
				strcpy_s(aProduct->nombre, temp->nombre);
				strcpy_s(aProduct->cantidad, temp->cantidad);
				strcpy_s(aProduct->marca, temp->marca);
				strcpy_s(aProduct->codigo, temp->codigo);
				strcpy_s(aProduct->precio, temp->precio);
				strcpy_s(aProduct->descripcion, temp->descripcion);
				strcpy_s(aProduct->imaruta1, temp->imaruta1);
				strcpy_s(aProduct->imaruta2, temp->imaruta2);
				strcpy_s(aProduct->username, temp->username);
				aProduct->next = NULL;
				aProduct = oProduct;
				delete reinterpret_cast<char*>(temp);
				continue;
			}
		}
		lectorEscritor.close();
		MessageBox(NULL, "Carga exitosa de productos", "CARGAR", MB_ICONASTERISK | MB_TASKMODAL);
		return;
	}
	else {
		MessageBox(NULL, "No se pudo abrir el archivo Productos", "NO CARGAR", MB_ICONASTERISK | MB_TASKMODAL);
		return;
	}
}

void freeMemoryProduct() {
	if (oProduct != NULL) { //Revisar el origen es null ? NO, liberamos la memoria
		while (aProduct != NULL) { //Mientras aux NO sea NULL ? avanzamos
			Product* temp = aProduct; //Guardamos en un temporal aux
			aProduct = aProduct->next; //Avanzamos
			delete temp; //Borramos el temporal
		}
	}
	else //Origen si fue null, no hacemos nada
		return;
	aProduct = oProduct = NULL;
}

void saveSend(Envios* pOrigen) {
	lectorEscritor.open("C:\\Users\\User\\source\\repos\\Demo\\winapo\\Envios.bin", ios::out | ios::trunc | ios::binary);
	if (lectorEscritor.is_open()) {

		while (pOrigen != NULL) {
			lectorEscritor.write(reinterpret_cast<char*>(pOrigen), sizeof(Envios));
			pOrigen = pOrigen->next;
		}
		lectorEscritor.close();
		MessageBox(NULL, "Guardado de envios exitoso", "GUARDAR", MB_ICONASTERISK | MB_TASKMODAL);
		return;
	}
	else {
		MessageBox(NULL, "No se pudo abrir el archivo de envios", "NO GUARDAR", MB_ICONASTERISK | MB_TASKMODAL);
		return;
	}
}

void loadSend() {
	lectorEscritor.open("C:\\Users\\User\\source\\repos\\Demo\\winapo\\Envios.bin", ios::binary | ios::in | ios::ate);
	if (lectorEscritor.is_open()) {
		int totalCharactersUsers = lectorEscritor.tellg();
		if (totalCharactersUsers < 1) {
			MessageBox(NULL, "Archivo de envios no encontrado, se creara una nuevo", "NO CARGA", MB_ICONASTERISK | MB_TASKMODAL);
			return;
		}
		for (int i = 0; i < totalCharactersUsers / sizeof(Envios); i++) {
			if (oEnvios == NULL) {
				Envios* temp = new Envios;
				oEnvios = new Envios;
				lectorEscritor.seekg(i * sizeof(Envios));
				lectorEscritor.read(reinterpret_cast<char*>(temp), sizeof(Envios));
				//oProduct->IDUser = temp->IDUser;
				strcpy_s(oEnvios->calle, temp->calle);
				strcpy_s(oEnvios->colonia, temp->colonia);
				strcpy_s(oEnvios->ciudad, temp->ciudad);
				strcpy_s(oEnvios->estado, temp->estado);
				strcpy_s(oEnvios->mensaje, temp->mensaje);
				strcpy_s(oEnvios->monto, temp->monto);
				strcpy_s(oEnvios->fecha, temp->fecha);
				strcpy_s(oEnvios->producto, temp->producto);
				strcpy_s(oEnvios->cantidad, temp->cantidad);
				strcpy_s(oEnvios->username, temp->username);
				strcpy_s(oEnvios->resumen, temp->resumen);


				oEnvios->next = NULL;
				oEnvios->prev = NULL;
				aEnvios = oEnvios;
				delete reinterpret_cast<char*>(temp);
				continue;
			}
			else {
				while (aEnvios->next != NULL) {
					aEnvios = aEnvios->next;
				}
				Envios* temp = new Envios;
				aEnvios->next = new Envios;
				lectorEscritor.seekg(i * sizeof(Envios));
				lectorEscritor.read(reinterpret_cast<char*>(temp), sizeof(Envios));
				aEnvios->next->prev = aEnvios;
				aEnvios = aEnvios->next;
				//aSend->IDUser = temp->IDUser;
				strcpy_s(aEnvios->calle, temp->calle);
				strcpy_s(aEnvios->colonia, temp->colonia);
				strcpy_s(aEnvios->ciudad, temp->ciudad);
				strcpy_s(aEnvios->estado, temp->estado);
				strcpy_s(aEnvios->mensaje, temp->mensaje);
				strcpy_s(aEnvios->monto, temp->monto);
				strcpy_s(aEnvios->fecha, temp->fecha);
				strcpy_s(aEnvios->producto, temp->producto);
				strcpy_s(aEnvios->cantidad, temp->cantidad);
				strcpy_s(aEnvios->username, temp->username);
				strcpy_s(aEnvios->resumen, temp->resumen);

				aEnvios->next = NULL;
				aEnvios = oEnvios;
				delete reinterpret_cast<char*>(temp);
				continue;
			}
		}
		lectorEscritor.close();
		MessageBox(NULL, "Carga exitosa de envios", "CARGAR", MB_ICONASTERISK | MB_TASKMODAL);
		return;
	}
	else {
		MessageBox(NULL, "No se pudo abrir el archivo envios", "NO CARGAR", MB_ICONASTERISK | MB_TASKMODAL);
		return;
	}
}

void freeMemorySend() {
	if (oEnvios != NULL) { //Revisar el origen es null ? NO, liberamos la memoria
		while (aEnvios != NULL) { //Mientras aux NO sea NULL ? avanzamos
			Envios* temp = aEnvios; //Guardamos en un temporal aux
			aEnvios = aEnvios->next; //Avanzamos
			delete temp; //Borramos el temporal
		}
	}
	else //Origen si fue null, no hacemos nada
		return;
	aEnvios = oEnvios = NULL;
}
// ConsoleApplication9.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>

using namespace std;

struct ALUMNOS{
	string nombre;
	int edad;
	float peso;
	ALUMNOS* anterior;
	ALUMNOS* siguiente;
}*ORIGEN;

void agregarAListaAlumnos(ALUMNOS* persona);
ALUMNOS* crearAlumno(string nombre, int edad, float peso);
void borrarListaAlumnos();

int main(int numeroDeParametros, char** arregloDeParametros) { //char** -> string []

//	int arr[10];
	int* arr = new int[10];
	int impar = 1;
	for (int i = 0; i < 10; i++) {
		arr[i] = impar;
		impar = impar + 2;
		cout << arr[i] << ", ";
	}
	cout << endl;
	int* pArr = arr; // &arr[0]
	int* finArr = pArr + 10;
	while (pArr != finArr) {
		cout << *pArr << ", "; 
		//pArr = 0x000002acb9ff4da4 {1} 
		pArr = pArr + 1;	// 4 bytes = int
		//pArr = 0x000002acb9ff4da8 {3}
	}
	cout << endl;
	pArr = &arr[0];
	for (int i = 0; i < 10; i++) {
		cout << pArr[i] << ", "; // *pArr
								//	pArr++;
	}
	delete []arr;
	cout << endl;
	ORIGEN = NULL;
	ALUMNOS* persona = crearAlumno("Gabriel", 18, 60);
	agregarAListaAlumnos(persona);
	persona = crearAlumno("Marco", 17, 60);
	agregarAListaAlumnos(persona);
	persona = crearAlumno("Jose", 17, 60);
	agregarAListaAlumnos(persona);

	borrarListaAlumnos();
	return 0;
}

void borrarListaAlumnos(){
	ALUMNOS* indice = ORIGEN;
	while (indice != NULL) {
		ALUMNOS* borrar = indice;
		indice = indice->siguiente;
		delete borrar;
	}
	ORIGEN = NULL;
	indice = NULL;
}

ALUMNOS * crearAlumno(string nombre, int edad, float peso){
	ALUMNOS *persona = new ALUMNOS;//persona = 0x00000254bcc54da0 {nombre="" edad=-842150451 peso=-431602080. ...}
	persona->nombre = nombre;
	persona->edad = edad;
	persona->peso = peso;
	persona->siguiente = NULL;
	persona->anterior = NULL;
	return persona;
}

void agregarAListaAlumnos(ALUMNOS *persona) {
	if (ORIGEN == NULL) {
		ORIGEN = persona;
	}
	else {
		ALUMNOS* indice = ORIGEN;
		while (indice->siguiente != NULL) {
			indice = indice->siguiente;
		}
		indice->siguiente = persona;
		persona->anterior = indice;
	}
}

















/*
//	int* arreglo = new int[10] { 8,7,5,6,3,4,0,2,1,9 };
	int arreglo[10] = {8,7,5,6,3,4,0,2,1,9};

	int impar = 0;
	for (int i = 0; i < 10; i++) {
		if (impar == 0) {
			arreglo[i] = impar;
			impar++;
		}
		else {
			arreglo[i] = impar;
			impar = impar + 2;
		}
//		cout << arreglo[i] << ", ";
	}
	cout << endl;
	int* apuntadorArreglo = &arreglo[0];
	for (int i = 0; i < 10; i++) {
		cout << *apuntadorArreglo << ", ";
		apuntadorArreglo++; // apuntadorArreglo = apuntadorArreglo + 1
	}
	cout << endl;
	for (apuntadorArreglo = &arreglo[0]; apuntadorArreglo < &arreglo[0] + 10; apuntadorArreglo++) {
		cout << *apuntadorArreglo << ", ";
	}

	int* apuntadorFinal = apuntadorArreglo + 10;
	apuntadorArreglo = &arreglo[0];
	while (apuntadorFinal != apuntadorArreglo) {
		cout << *apuntadorArreglo << ", ";
		apuntadorArreglo++; // apuntadorArreglo = apuntadorArreglo + 1
	}


*/